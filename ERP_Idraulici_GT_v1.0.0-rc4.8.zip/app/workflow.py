"""Delivery notes, work progress and source allocations for invoice drafts."""
from datetime import date, time
from calendar import monthrange
from decimal import Decimal, ROUND_HALF_UP
import json
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from app.auth import allowed
from app.catalog import audit
from app.db import connect
from app.domain import quantity
from app.quotes import decimal, money, details as quote_details, linked_invoice_for_quote
from app.stock import move, consume_any, automatic_warehouse
from app.numbering import next_document_number, proposed_number, assert_free_number
from app.fiscal_years import assert_open

router=APIRouter()


@router.get('/document-number/preview')
def number_preview(kind:str,issued_on:date,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        return {'number':proposed_number(conn,kind,issued_on),'provisional':True}


class DeliveryIn(BaseModel):
    customer_id: int
    quote_id: int | None = None
    number: str = ''
    issued_on: date
    warehouse_id: int | None = None
    shipping_address: str = ''
    project_id: int | None = None
    transport_reason_id: int | None = None
    goods_appearance_id: int | None = None
    port_term_id: int | None = None
    transport_mode_id: int | None = None
    carrier_id: int | None = None
    transport_date: date | None = None
    transport_time: time | None = None
    package_count: int = 0
    gross_weight: str = '0'
    net_weight: str = '0'
    weight_unit: str = 'kg'
    return_due_date: date | None = None
    billing_destination: str = 'DIRECT_INVOICE'
    global_labor: str = '0'
    global_labor_vat: str = '22'
    global_travel: str = '0'
    global_travel_vat: str = '22'
    global_service: str = '0'
    global_service_vat: str = '22'
    global_discount: str = '0'
    global_discount_vat: str = '22'
    notes: str = ''


class DeliveryLineIn(BaseModel):
    product_id: int | None = None
    quote_line_id: int | None = None
    kind: str = 'PRODUCT'
    code: str = ''
    description: str = ''
    unit_code: str = 'PZ'
    quantity: str = '1'
    unit_price: str = '0'
    discount_percent: str = '0'
    vat_rate: str = '22'
    calculation_mode: str = 'MANUAL'
    work_minutes: str = '0'
    workers: int = 1
    hourly_rate: str = '0'
    kilometers: str = '0'
    kilometer_rate: str = '0'


class DeliveryFullLineIn(DeliveryLineIn):
    id: int | None = None


class DeliveryFullIn(BaseModel):
    header: DeliveryIn
    lines: list[DeliveryFullLineIn]


class SalIn(BaseModel):
    customer_id: int
    quote_id: int | None = None
    project_id: int | None = None
    number: str = ''
    issued_on: date
    description: str = ''
    percent: str = ''
    amount: str = ''
    vat_rate: str = '22'
    status: str = 'PARTIAL'
    sequence_no: int = 1
    period_from: date | None = None
    period_to: date | None = None
    approval_status: str = 'DRAFT'
    retention_amount: str = '0'
    advance_recovery: str = '0'
    variation_amount: str = '0'
    approved_on: date | None = None
    certificate_number: str = ''
    certificate_date: date | None = None
    works_director: str = ''
    rup: str = ''
    notes: str = ''


class SourceIn(BaseModel):
    kind: str
    source_id: int
    amount: str | None = None


def check_name(number):
    if not number.strip() or len(number)>80:
        raise HTTPException(400,'Numero documento richiesto (massimo 80 caratteri)')


def customer(conn,customer_id):
    row=conn.execute('SELECT name FROM customers WHERE id=%s AND active=true',(customer_id,)).fetchone()
    if not row:raise HTTPException(400,'Cliente non trovato')
    return row['name']


def delivery_detail(conn,delivery_id):
    doc=conn.execute('SELECT d.*,w.name AS warehouse_name,ps.code AS project_code,ps.name AS project_name,'
                     'q.number AS quote_number,q.title AS quote_title,q.issue_date AS quote_date,'
                     'r.name AS transport_reason_name,a.name AS goods_appearance_name,p.name AS port_term_name,'
                     't.name AS transport_mode_name,c.name AS carrier_name '
                     'FROM delivery_notes d JOIN warehouses w ON w.id=d.warehouse_id '
                     'LEFT JOIN project_sites ps ON ps.id=d.project_id '
                     'LEFT JOIN quotes q ON q.id=d.quote_id '
                     'LEFT JOIN transport_reasons r ON r.id=d.transport_reason_id '
                     'LEFT JOIN goods_appearances a ON a.id=d.goods_appearance_id '
                     'LEFT JOIN port_terms p ON p.id=d.port_term_id '
                     'LEFT JOIN transport_modes t ON t.id=d.transport_mode_id '
                     'LEFT JOIN carriers c ON c.id=d.carrier_id '
                     'WHERE d.id=%s AND d.active=true',(delivery_id,)).fetchone()
    if not doc:raise HTTPException(404,'DDT non trovato')
    lines=conn.execute('SELECT * FROM delivery_lines WHERE delivery_id=%s ORDER BY id',(delivery_id,)).fetchall()
    result=dict(doc);result['lines']=[]
    for row in lines:
        line=dict(row);line['quantity']=str(line['quantity']);line['unit_price']=str(line['unit_price']);line['discount_percent']=str(line['discount_percent']);line['vat_rate']=str(line['vat_rate']);line['total']=str(delivery_line_total(row))
        result['lines'].append(line)
    totals={'materials':Decimal('0'),'labor':Decimal('0'),'travel':Decimal('0'),'service':Decimal('0'),'discounts':Decimal('0'),'taxable':Decimal('0'),'vat':Decimal('0')}
    for row in lines:
        total=delivery_line_total(row);totals['taxable']+=total;totals['vat']+=money(total*row['vat_rate']/100)
        if row.get('kind')=='DISCOUNT':totals['discounts']+=total
        elif row.get('kind')=='TRAVEL' or row.get('calculation_mode')=='TRAVEL':totals['travel']+=total
        elif row.get('calculation_mode')=='LABOR':totals['labor']+=total
        elif row.get('kind')=='SERVICE':totals['service']+=total
        else:totals['materials']+=total
    for bucket,amount_key,vat_key,sign in (('labor','global_labor','global_labor_vat',1),('travel','global_travel','global_travel_vat',1),('service','global_service','global_service_vat',1),('discounts','global_discount','global_discount_vat',-1)):
        amount=money(doc.get(amount_key) or Decimal('0'))*sign
        totals[bucket]+=amount;totals['taxable']+=amount;totals['vat']+=money(amount*(doc.get(vat_key) or Decimal('0'))/Decimal('100'))
    result['totals']={key:str(money(value)) for key,value in totals.items()}
    result['totals']['total']=str(money(totals['taxable']+totals['vat']))
    linked=conn.execute('SELECT i.id,i.number,i.document_status FROM invoice_sources s JOIN invoice_register i ON i.id=s.invoice_id AND i.active=true WHERE s.delivery_id=%s ORDER BY i.id DESC LIMIT 1',(delivery_id,)).fetchone()
    result['linked_invoice']=dict(linked) if linked else None
    return result


def delivery_line_total(line):
    value=money(line['quantity'] * line['unit_price'] *
                (Decimal(1) - line['discount_percent'] / Decimal(100)))
    return -value if line.get('kind')=='DISCOUNT' else value


def first_movement_id(movements):
    if not movements or not movements[0].get('id'):
        raise HTTPException(409,'Lo scarico di magazzino non ha prodotto un movimento: controlla giacenze e magazzini')
    return movements[0]['id']


@router.get('/delivery-notes')
def deliveries(user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        ids=conn.execute('SELECT id FROM delivery_notes WHERE active=true AND fiscal_year=%s ORDER BY issued_on DESC,id DESC LIMIT 500',(user['selected_fiscal_year'],)).fetchall()
        return [delivery_detail(conn,row['id']) for row in ids]


def save_delivery_record(conn,data,user,delivery_id=None):
        existing_quote_id=None
        if delivery_id:
            original=conn.execute('SELECT issued_on,quote_id FROM delivery_notes WHERE id=%s FOR UPDATE',(delivery_id,)).fetchone()
            if original:
                assert_open(conn,original['issued_on']);existing_quote_id=original['quote_id']
        assert_open(conn,data.issued_on)
        number=next_document_number(conn,'DDT',data.issued_on) if delivery_id is None and not data.number.strip() else data.number
        check_name(number)
        assert_free_number(conn,'DDT',number,delivery_id)
        name=customer(conn,data.customer_id)
        if data.quote_id:
            quote=conn.execute("SELECT customer_id,status FROM quotes WHERE id=%s AND active=true FOR UPDATE",(data.quote_id,)).fetchone()
            if not quote or quote['customer_id']!=data.customer_id or quote['status']=='REJECTED':
                raise HTTPException(400,'Preventivo non valido oppure appartenente a un altro cliente')
            if data.quote_id!=existing_quote_id and linked_invoice_for_quote(conn,data.quote_id):
                raise HTTPException(409,'Preventivo già fatturato: non può essere associato a un nuovo DDT')
            if conn.execute('SELECT 1 FROM project_quote_links l JOIN project_sites p ON p.id=l.project_id AND p.active=true WHERE l.quote_id=%s',(data.quote_id,)).fetchone():
                raise HTTPException(409,'Preventivo associato a un cantiere: seleziona il cantiere oppure dissocia prima il preventivo')
        shipping=data.shipping_address.strip()
        if delivery_id is None and not shipping:
            saved=conn.execute('SELECT label,address,postal_code,city,province FROM customer_addresses '
                               'WHERE customer_id=%s AND active=true ORDER BY is_default DESC,id LIMIT 1',(data.customer_id,)).fetchone()
            if saved:
                shipping=', '.join(part for part in (saved['label'],saved['address'],
                    (saved['postal_code']+' '+saved['city']+' '+saved['province']).strip()) if part)
        try:warehouse_id=data.warehouse_id or automatic_warehouse(conn)
        except ValueError as exc:raise HTTPException(400,str(exc)) from exc
        if not conn.execute('SELECT 1 FROM warehouses WHERE id=%s AND active=true',(warehouse_id,)).fetchone():raise HTTPException(400,'Magazzino non attivo')
        if data.project_id:
            project=conn.execute('SELECT customer_id FROM project_sites WHERE id=%s AND active=true',(data.project_id,)).fetchone()
            if not project or project['customer_id']!=data.customer_id:raise HTTPException(400,'Cantiere non valido per il cliente')
        if data.billing_destination not in ('DIRECT_INVOICE','PROJECT_COST','NON_BILLABLE'):
            raise HTTPException(400,'Destinazione contabile DDT non valida')
        for table,value,label in [('transport_reasons',data.transport_reason_id,'causale'),('goods_appearances',data.goods_appearance_id,'aspetto beni'),('port_terms',data.port_term_id,'porto'),('transport_modes',data.transport_mode_id,'modalità trasporto'),('carriers',data.carrier_id,'vettore')]:
            if value and not conn.execute(f'SELECT 1 FROM {table} WHERE id=%s AND active=true',(value,)).fetchone():raise HTTPException(400,f'{label.capitalize()} non valido')
        gross=decimal(data.gross_weight,places=3);net=decimal(data.net_weight,places=3)
        if net>gross and gross>0:raise HTTPException(400,'Il peso netto non può superare il peso lordo')
        if data.package_count<0 or data.package_count>1000000 or not data.weight_unit.strip():raise HTTPException(400,'Colli o unità di peso non validi')
        values=data.model_dump(exclude={'number','customer_id'});values.update(customer_id=data.customer_id,customer_name=name,number=number,warehouse_id=warehouse_id,shipping_address=shipping,gross_weight=gross,net_weight=net,fiscal_year=data.issued_on.year)
        for key in ('global_labor','global_labor_vat','global_travel','global_travel_vat','global_service','global_service_vat','global_discount','global_discount_vat'):
            values[key]=decimal(getattr(data,key),minimum='0',maximum='100' if key.endswith('_vat') else '99999999999.99',places=2)
        if delivery_id is None:
            if data.number.strip() and user['role']!='ADMIN':raise HTTPException(403,'Solo l’amministratore può forzare il numero')
            cols=list(values);row=conn.execute('INSERT INTO delivery_notes('+','.join(cols)+') VALUES ('+','.join(['%s']*len(cols))+') RETURNING id',tuple(values.values())).fetchone()
        else:
            old=conn.execute('SELECT customer_id,status FROM delivery_notes WHERE id=%s AND active=true FOR UPDATE',(delivery_id,)).fetchone()
            if not old:raise HTTPException(404,'DDT non trovato')
            if old['status']!='DRAFT':raise HTTPException(409,'DDT confermato: crea una rettifica separata')
            if user['role']!='ADMIN' and conn.execute('SELECT 1 FROM delivery_notes WHERE id=%s AND number<>%s',(delivery_id,number)).fetchone():
                raise HTTPException(403,'Solo l’amministratore può cambiare il numero')
            cols=list(values);row=conn.execute('UPDATE delivery_notes SET '+','.join(c+'=%s' for c in cols)+' WHERE id=%s RETURNING id',(*values.values(),delivery_id)).fetchone()
        audit(conn,user,'CREATE' if delivery_id is None else 'UPDATE','delivery_notes',row['id'])
        return delivery_detail(conn,row['id'])


def save_delivery(data,user,delivery_id=None):
    with connect() as conn:return save_delivery_record(conn,data,user,delivery_id)


@router.post('/delivery-notes',status_code=201)
def add_delivery(data:DeliveryIn,user=Depends(allowed('ADMIN','OFFICE'))):return save_delivery(data,user)


@router.put('/delivery-notes/{delivery_id}')
def edit_delivery(delivery_id:int,data:DeliveryIn,user=Depends(allowed('ADMIN','OFFICE'))):return save_delivery(data,user,delivery_id)


def delivery_line_values(conn,delivery_id,data):
    try:qty=quantity(data.quantity)
    except ValueError as exc:raise HTTPException(400,str(exc)) from exc
    price=decimal(data.unit_price,minimum='0',places=4)
    discount=decimal(data.discount_percent,maximum='100',places=2)
    vat=decimal(data.vat_rate,maximum='100',places=2)
    work_minutes=decimal(data.work_minutes,minimum='0',places=2)
    hourly_rate=decimal(data.hourly_rate,minimum='0',places=4)
    kilometers=decimal(data.kilometers,minimum='0',places=3)
    kilometer_rate=decimal(data.kilometer_rate,minimum='0',places=4)
    if data.kind not in ('PRODUCT','SERVICE','TRAVEL','DISCOUNT') or data.calculation_mode not in ('MANUAL','LABOR','TRAVEL'):
        raise HTTPException(400,'Tipo riga o modalità di calcolo non valida')
    if not 1<=data.workers<=1000:raise HTTPException(400,'Numero addetti non valido')
    if data.calculation_mode=='LABOR':
        if work_minutes<=0:raise HTTPException(400,'Indica i minuti della manodopera')
        data.kind='SERVICE';qty=Decimal('1');price=money(work_minutes/60*data.workers*hourly_rate)
    elif data.calculation_mode=='TRAVEL':
        if kilometers<=0:raise HTTPException(400,'Indica i chilometri della trasferta')
        data.kind='TRAVEL';qty=Decimal('1');price=money(kilometers*kilometer_rate)
    if data.kind=='PRODUCT':
        if not data.product_id:raise HTTPException(400,'Seleziona l’articolo di magazzino')
        product=conn.execute('SELECT p.code,p.description,u.code AS unit_code FROM products p JOIN units u ON u.id=p.unit_id WHERE p.id=%s AND p.active=true',(data.product_id,)).fetchone()
        if not product:raise HTTPException(400,'Articolo non trovato')
        code,description,unit_code=product['code'],product['description'],product['unit_code']
    else:
        if data.product_id:raise HTTPException(400,'Manodopera, trasferta e sconto non richiedono un articolo')
        code=data.code.strip();description=data.description.strip();unit_code=data.unit_code.strip() or 'NR'
    document=conn.execute('SELECT quote_id,project_id FROM delivery_notes WHERE id=%s',(delivery_id,)).fetchone()
    if data.quote_line_id:
        quote_line=conn.execute('SELECT quote_id,product_id,kind FROM quote_lines WHERE id=%s',(data.quote_line_id,)).fetchone()
        linked=bool(document and quote_line and (quote_line['quote_id']==document['quote_id'] or
            document['project_id'] and conn.execute('SELECT 1 FROM project_quote_links WHERE project_id=%s AND quote_id=%s',(document['project_id'],quote_line['quote_id'])).fetchone()))
        if not linked:
            raise HTTPException(400,'Riga preventivo non coerente con il DDT')
        if quote_line['product_id']!=data.product_id:raise HTTPException(400,'Articolo diverso dalla riga del preventivo')
    return dict(product_id=data.product_id,quote_line_id=data.quote_line_id,kind=data.kind,
                product_code=code,description=description,unit_code=unit_code,quantity=qty,unit_price=price,
                discount_percent=discount,vat_rate=vat,calculation_mode=data.calculation_mode,
                work_minutes=work_minutes,workers=data.workers,hourly_rate=hourly_rate,
                kilometers=kilometers,kilometer_rate=kilometer_rate)


def validate_quote_delivery_quantities(conn,delivery_id):
    document=conn.execute('SELECT quote_id,project_id FROM delivery_notes WHERE id=%s',(delivery_id,)).fetchone()
    if not document or (not document['quote_id'] and not document['project_id']):return
    invalid=conn.execute('SELECT ql.description,ql.quantity,'
                         '(SELECT COALESCE(sum(dl.quantity),0) FROM delivery_lines dl JOIN delivery_notes d ON d.id=dl.delivery_id '
                         ' WHERE dl.quote_line_id=ql.id AND d.active=true) delivered '
                         'FROM quote_lines ql WHERE EXISTS (SELECT 1 FROM delivery_lines current '
                         ' WHERE current.quote_line_id=ql.id AND current.delivery_id=%s) '
                         'AND (SELECT COALESCE(sum(dl.quantity),0) FROM delivery_lines dl JOIN delivery_notes d ON d.id=dl.delivery_id '
                         ' WHERE dl.quote_line_id=ql.id AND d.active=true)>ql.quantity LIMIT 1',(delivery_id,)).fetchone()
    if invalid:raise HTTPException(409,f"Quantità DDT superiore al preventivo per: {invalid['description']}")


def save_delivery_line_record(conn,delivery_id,data,user,line_id=None):
    d=conn.execute('SELECT d.status,f.status fiscal_status FROM delivery_notes d JOIN fiscal_years f ON f.year=d.fiscal_year WHERE d.id=%s AND d.active=true FOR UPDATE',(delivery_id,)).fetchone()
    if not d:raise HTTPException(404,'DDT non trovato')
    if d['status']!='DRAFT':raise HTTPException(409,'DDT già confermato')
    if d['fiscal_status']!='OPEN':raise HTTPException(409,'Esercizio chiuso: DDT in sola lettura')
    values=delivery_line_values(conn,delivery_id,data);cols=list(values)
    if line_id:
        row=conn.execute('UPDATE delivery_lines SET '+','.join(c+'=%s' for c in cols)+' WHERE id=%s AND delivery_id=%s RETURNING id',(*values.values(),line_id,delivery_id)).fetchone()
    else:
        row=conn.execute('INSERT INTO delivery_lines(delivery_id,'+','.join(cols)+') VALUES (%s,'+','.join(['%s']*len(cols))+') RETURNING id',(delivery_id,*values.values())).fetchone()
    if not row:raise HTTPException(404,'Riga DDT non trovata')
    validate_quote_delivery_quantities(conn,delivery_id)
    audit(conn,user,'UPDATE' if line_id else 'CREATE','delivery_lines',row['id'])
    return row['id']


@router.post('/delivery-notes/{delivery_id}/lines',status_code=201)
def add_delivery_line(delivery_id:int,data:DeliveryLineIn,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        save_delivery_line_record(conn,delivery_id,data,user)
        return delivery_detail(conn,delivery_id)


@router.put('/delivery-notes/{delivery_id}/lines/{line_id}')
def edit_delivery_line(delivery_id:int,line_id:int,data:DeliveryLineIn,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        save_delivery_line_record(conn,delivery_id,data,user,line_id)
        return delivery_detail(conn,delivery_id)


def save_full_delivery(data,user,delivery_id=None):
    if len(data.lines)>300:raise HTTPException(400,'Puoi inserire al massimo 300 righe nel DDT')
    with connect() as conn:
        document=save_delivery_record(conn,data.header,user,delivery_id);document_id=document['id']
        existing={r['id'] for r in conn.execute('SELECT id FROM delivery_lines WHERE delivery_id=%s FOR UPDATE',(document_id,)).fetchall()}
        kept=set()
        for item in data.lines:
            line_id=item.id
            if line_id is not None and line_id not in existing:raise HTTPException(400,'Riga DDT non appartenente al documento')
            payload=DeliveryLineIn(**item.model_dump(exclude={'id'}))
            saved_id=save_delivery_line_record(conn,document_id,payload,user,line_id);kept.add(saved_id)
        for removed_id in existing-kept:
            conn.execute('DELETE FROM delivery_lines WHERE id=%s AND delivery_id=%s',(removed_id,document_id))
            audit(conn,user,'DELETE','delivery_lines',removed_id)
        validate_quote_delivery_quantities(conn,document_id)
        result=delivery_detail(conn,document_id)
        if Decimal(result['totals']['taxable'])<0:raise HTTPException(400,'Gli sconti superano il valore del DDT')
        return result


@router.post('/delivery-notes/full',status_code=201)
def add_full_delivery(data:DeliveryFullIn,user=Depends(allowed('ADMIN','OFFICE'))):
    return save_full_delivery(data,user)


@router.put('/delivery-notes/{delivery_id}/full')
def edit_full_delivery(delivery_id:int,data:DeliveryFullIn,user=Depends(allowed('ADMIN','OFFICE'))):
    return save_full_delivery(data,user,delivery_id)


@router.delete('/delivery-notes/{delivery_id}/lines/{line_id}')
def delete_delivery_line(delivery_id:int,line_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        d=conn.execute('SELECT d.status,f.status fiscal_status FROM delivery_notes d JOIN fiscal_years f ON f.year=d.fiscal_year WHERE d.id=%s AND d.active=true FOR UPDATE',(delivery_id,)).fetchone()
        if not d:raise HTTPException(404,'DDT non trovato')
        if d['status']!='DRAFT':raise HTTPException(409,'DDT già confermato')
        if d['fiscal_status']!='OPEN':raise HTTPException(409,'Esercizio chiuso: DDT in sola lettura')
        row=conn.execute('DELETE FROM delivery_lines WHERE id=%s AND delivery_id=%s RETURNING id',(line_id,delivery_id)).fetchone()
        if not row:raise HTTPException(404,'Riga DDT non trovata')
        audit(conn,user,'DELETE','delivery_lines',line_id)
        return delivery_detail(conn,delivery_id)


@router.post('/delivery-notes/{delivery_id}/confirm')
def confirm_delivery(delivery_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        d=conn.execute('SELECT d.*,r.name reason_name,r.invoiceable,r.stock_action,r.requires_return,a.name appearance_name,p.name port_name,t.name mode_name,c.name carrier_name,c.vat_number carrier_vat,c.address carrier_address,c.postal_code carrier_postal,c.city carrier_city,c.province carrier_province,c.driver_name,c.vehicle_plate FROM delivery_notes d LEFT JOIN transport_reasons r ON r.id=d.transport_reason_id LEFT JOIN goods_appearances a ON a.id=d.goods_appearance_id LEFT JOIN port_terms p ON p.id=d.port_term_id LEFT JOIN transport_modes t ON t.id=d.transport_mode_id LEFT JOIN carriers c ON c.id=d.carrier_id WHERE d.id=%s AND d.active=true FOR UPDATE',(delivery_id,)).fetchone()
        if not d:raise HTTPException(404,'DDT non trovato')
        assert_open(conn,d['issued_on'])
        if d['status']!='DRAFT':raise HTTPException(409,'DDT già confermato')
        if not all((d['transport_reason_id'],d['goods_appearance_id'],d['port_term_id'],d['transport_mode_id'])):
            raise HTTPException(400,'Completa causale, aspetto dei beni, porto e modalità di trasporto')
        if d['mode_name']=='Vettore' and not d['carrier_id']:raise HTTPException(400,'Seleziona il vettore')
        if d['package_count']<=0:raise HTTPException(400,'Indica il numero dei colli')
        if d['requires_return'] and not d['return_due_date']:raise HTTPException(400,'Per questa causale indica la data prevista di rientro')
        lines=conn.execute('SELECT * FROM delivery_lines WHERE delivery_id=%s ORDER BY product_id,id',(delivery_id,)).fetchall()
        if not lines:raise HTTPException(400,'Aggiungi almeno una riga al DDT')
        for line in lines:
            if d['stock_action']=='NONE' or not line['product_id']:continue
            try:
                if d['stock_action']=='CONSUME':movements=consume_any(conn,product_id=line['product_id'],amount=str(line['quantity']),actor=user['username'],reason=f"DDT {d['number']} · {d['reason_name']} · riga {line['id']}")
                else:movements=[move(conn,product_id=line['product_id'],source_id=None,destination_id=automatic_warehouse(conn,line['product_id']),amount=str(line['quantity']),kind='LOAD',actor=user['username'],reason=f"DDT {d['number']} · {d['reason_name']} · riga {line['id']}")]
            except ValueError as exc:raise HTTPException(409,str(exc)) from exc
            conn.execute('UPDATE delivery_lines SET movement_id=%s WHERE id=%s',(first_movement_id(movements),line['id']))
        snapshot={k:d[k] for k in ('reason_name','invoiceable','stock_action','requires_return','appearance_name','port_name','mode_name','carrier_name','carrier_vat','carrier_address','carrier_postal','carrier_city','carrier_province','driver_name','vehicle_plate')}
        conn.execute("UPDATE delivery_notes SET status='CONFIRMED',transport_date=COALESCE(transport_date,issued_on),transport_snapshot=%s::jsonb WHERE id=%s",(json.dumps(snapshot),delivery_id))
        audit(conn,user,'CONFIRM','delivery_notes',delivery_id)
        return delivery_detail(conn,delivery_id)


@router.delete('/delivery-notes/{delivery_id}')
def archive_delivery(delivery_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        current=conn.execute('SELECT f.status FROM delivery_notes d JOIN fiscal_years f ON f.year=d.fiscal_year WHERE d.id=%s AND d.active=true FOR UPDATE',(delivery_id,)).fetchone()
        if current and current['status']!='OPEN':raise HTTPException(409,'Esercizio chiuso: DDT in sola lettura')
        row=conn.execute("UPDATE delivery_notes SET active=false WHERE id=%s AND active=true AND status='DRAFT' RETURNING id",(delivery_id,)).fetchone()
        if not row:raise HTTPException(409,'Solo i DDT in bozza possono essere archiviati')
        audit(conn,user,'ARCHIVE','delivery_notes',delivery_id)
    return {'ok':True}


def sal_values(conn,data):
    approval_status=getattr(data,'approval_status','DRAFT');sequence_no=getattr(data,'sequence_no',1)
    if (data.status not in ('PARTIAL','COMPLETED') or
            approval_status not in ('DRAFT','ISSUED','APPROVED','DISPUTED','INVOICED') or sequence_no<1):
        raise HTTPException(400,'Stato SAL non valido')
    period_from=getattr(data,'period_from',None);period_to=getattr(data,'period_to',None)
    if period_from and period_to and period_from>period_to:raise HTTPException(400,'Periodo SAL non valido')
    if data.quote_id:
        linked=conn.execute('SELECT customer_id FROM quotes WHERE id=%s AND active=true',(data.quote_id,)).fetchone()
        if not linked or linked['customer_id']!=data.customer_id:
            raise HTTPException(400,'Preventivo non disponibile per il cliente')
    values=data.model_dump()
    percent=data.percent.strip();amount=data.amount.strip()
    if approval_status=='DRAFT' and not data.quote_id:
        percent=percent or '0';amount=amount or '0'
    if not percent or not amount:
        if not data.quote_id:raise HTTPException(400,'Per il SAL senza preventivo indica percentuale e importo')
        total=Decimal(quote_details(conn,data.quote_id)['subtotal'])
        if total<=0:raise HTTPException(400,'Preventivo senza imponibile: inserisci importo e percentuale')
        if percent and not amount:
            amount=str(money(total*decimal(percent,maximum='100',minimum='0.01',places=2)/100))
        elif amount and not percent:
            percent=str((decimal(amount,minimum='0.01',places=2)/total*100).quantize(Decimal('.01'),rounding=ROUND_HALF_UP))
        else:raise HTTPException(400,'Indica la percentuale o l’importo del SAL')
    minimum='0' if approval_status=='DRAFT' else '0.01'
    values['percent']=decimal(percent,maximum='100',minimum=minimum,places=2)
    values['amount']=decimal(amount,maximum='99999999999.99',minimum=minimum,places=2)
    values['vat_rate']=decimal(data.vat_rate,maximum='100',places=2)
    values['retention_amount']=decimal(getattr(data,'retention_amount','0'),maximum='99999999999.99',places=2)
    values['advance_recovery']=decimal(getattr(data,'advance_recovery','0'),maximum='99999999999.99',places=2)
    values['variation_amount']=decimal(getattr(data,'variation_amount','0'),maximum='99999999999.99',minimum='-99999999999.99',places=2)
    if values['retention_amount']+values['advance_recovery']>values['amount']+max(values['variation_amount'],Decimal(0)):
        raise HTTPException(400,'Ritenuta e recupero anticipo superano il SAL')
    project_id=getattr(data,'project_id',None)
    if project_id:
        project=conn.execute('SELECT customer_id,quote_id,contract_value,variation_value FROM project_sites WHERE id=%s AND active=true',(project_id,)).fetchone()
        if not project or project['customer_id']!=data.customer_id:raise HTTPException(400,'Cantiere non valido per il cliente')
        if data.quote_id and not conn.execute('SELECT 1 FROM project_quote_links WHERE project_id=%s AND quote_id=%s',(project_id,data.quote_id)).fetchone():raise HTTPException(400,'Preventivo non associato al cantiere')
    elif data.quote_id:
        locked=conn.execute('SELECT true AS linked FROM project_quote_links l JOIN project_sites p ON p.id=l.project_id AND p.active=true WHERE l.quote_id=%s',(data.quote_id,)).fetchone()
        if locked and locked.get('linked'):raise HTTPException(409,'Il preventivo appartiene a un cantiere: seleziona anche il cantiere oppure dissocialo')
    return values


@router.get('/progress-certificates')
def sal_list(user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        rows=conn.execute('SELECT s.*,p.code AS project_code,p.name AS project_name,'
                          '(SELECT i.id FROM invoice_sources x JOIN invoice_register i ON i.id=x.invoice_id AND i.active=true WHERE x.sal_id=s.id ORDER BY i.id DESC LIMIT 1) AS linked_invoice_id,'
                          '(SELECT i.number FROM invoice_sources x JOIN invoice_register i ON i.id=x.invoice_id AND i.active=true WHERE x.sal_id=s.id ORDER BY i.id DESC LIMIT 1) AS linked_invoice_number,'
                          'COALESCE((SELECT sum(x.percent) FROM progress_certificates x WHERE x.project_id=s.project_id AND x.active=true AND (x.sequence_no<s.sequence_no OR x.sequence_no=s.sequence_no AND x.id<s.id)),0) AS previous_percent,'
                          'COALESCE((SELECT sum(x.amount+x.variation_amount-x.retention_amount-x.advance_recovery) FROM progress_certificates x WHERE x.project_id=s.project_id AND x.active=true AND (x.sequence_no<s.sequence_no OR x.sequence_no=s.sequence_no AND x.id<s.id)),0) AS previous_amount '
                          'FROM progress_certificates s LEFT JOIN project_sites p ON p.id=s.project_id WHERE s.active=true AND s.fiscal_year=%s ORDER BY s.issued_on DESC,s.id DESC LIMIT 500',(user['selected_fiscal_year'],)).fetchall()
    return [{**r,**{k:str(r[k]) for k in ('percent','amount','vat_rate','retention_amount','advance_recovery','variation_amount','previous_percent','previous_amount')}} for r in rows]


def save_sal(data,user,sal_id=None):
    with connect() as conn:
        existing_quote_id=None
        if sal_id:
            original=conn.execute('SELECT issued_on,quote_id FROM progress_certificates WHERE id=%s FOR UPDATE',(sal_id,)).fetchone()
            if original:
                assert_open(conn,original['issued_on']);existing_quote_id=original['quote_id']
        assert_open(conn,data.issued_on)
        if data.quote_id and data.quote_id!=existing_quote_id and linked_invoice_for_quote(conn,data.quote_id):
            raise HTTPException(409,'Preventivo già fatturato: non può essere associato a un nuovo SAL')
        values=sal_values(conn,data)
        values['fiscal_year']=data.issued_on.year
        values['number']=next_document_number(conn,'SAL',data.issued_on) if sal_id is None and not data.number.strip() else data.number
        check_name(values['number'])
        assert_free_number(conn,'SAL',values['number'],sal_id)
        if data.number.strip() and user['role']!='ADMIN':
            old_number=conn.execute('SELECT number FROM progress_certificates WHERE id=%s',(sal_id,)).fetchone() if sal_id else None
            if not old_number or old_number['number']!=values['number']:
                raise HTTPException(403,'Solo l’amministratore può forzare il numero')
        name=customer(conn,data.customer_id)
        if data.quote_id:
            conn.execute('SELECT id FROM quotes WHERE id=%s FOR UPDATE',(data.quote_id,))
            cumulative=conn.execute('SELECT COALESCE(sum(percent),0) AS percent FROM progress_certificates WHERE quote_id=%s AND active=true AND id<>%s',(data.quote_id,sal_id or 0)).fetchone()['percent']+values['percent']
            if cumulative>100 or data.status=='COMPLETED' and cumulative!=100:
                raise HTTPException(409,'SAL del preventivo oltre il 100%, oppure completato prima del 100%')
        if data.project_id:
            project=conn.execute('SELECT contract_value+variation_value AS total FROM project_sites WHERE id=%s FOR UPDATE',(data.project_id,)).fetchone()
            prior=conn.execute('SELECT COALESCE(sum(amount+variation_amount-retention_amount-advance_recovery),0) total FROM progress_certificates WHERE project_id=%s AND active=true AND id<>%s',(data.project_id,sal_id or 0)).fetchone()['total']
            current=values['amount']+values['variation_amount']-values['retention_amount']-values['advance_recovery']
            validate_project_sal(current,prior,project['total'],values['approval_status'])
            if conn.execute('SELECT 1 FROM progress_certificates WHERE project_id=%s AND sequence_no=%s AND active=true AND id<>%s',(data.project_id,data.sequence_no,sal_id or 0)).fetchone():raise HTTPException(409,'Numero SAL già presente nel cantiere')
        old=conn.execute('SELECT customer_id FROM progress_certificates WHERE id=%s AND active=true FOR UPDATE',(sal_id,)).fetchone() if sal_id else None
        if sal_id and not old:raise HTTPException(404,'SAL non trovato')
        if sal_id and conn.execute('SELECT 1 FROM invoice_sources WHERE sal_id=%s',(sal_id,)).fetchone():
            raise HTTPException(409,'SAL già collegato a una fattura: modifica prima i collegamenti')
        if not old or old['customer_id']!=data.customer_id:values['customer_name']=name
        cols=list(values)
        if sal_id:
            row=conn.execute(f"UPDATE progress_certificates SET {','.join(c+'=%s' for c in cols)} WHERE id=%s RETURNING id",(*values.values(),sal_id)).fetchone()
        else:
            row=conn.execute(f"INSERT INTO progress_certificates ({','.join(cols)}) VALUES ({','.join(['%s']*len(cols))}) RETURNING id",tuple(values.values())).fetchone()
        audit(conn,user,'UPDATE' if sal_id else 'CREATE','progress_certificates',row['id'])
        return {'id':row['id']}


def validate_project_sal(current,prior,total,approval_status):
    if (approval_status!='DRAFT' and current<=0) or prior+current>total:
        raise HTTPException(409,'SAL oltre il residuo economico del cantiere')


@router.post('/progress-certificates',status_code=201)
def add_sal(data:SalIn,user=Depends(allowed('ADMIN','OFFICE'))):return save_sal(data,user)


@router.put('/progress-certificates/{sal_id}')
def edit_sal(sal_id:int,data:SalIn,user=Depends(allowed('ADMIN','OFFICE'))):return save_sal(data,user,sal_id)


@router.delete('/progress-certificates/{sal_id}')
def archive_sal(sal_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        current=conn.execute('SELECT f.status FROM progress_certificates s JOIN fiscal_years f ON f.year=s.fiscal_year WHERE s.id=%s AND s.active=true FOR UPDATE',(sal_id,)).fetchone()
        if current and current['status']!='OPEN':raise HTTPException(409,'Esercizio chiuso: SAL in sola lettura')
        conn.execute('SELECT id FROM progress_certificates WHERE id=%s AND active=true FOR UPDATE',(sal_id,))
        if conn.execute('SELECT 1 FROM invoice_sources WHERE sal_id=%s',(sal_id,)).fetchone():
            raise HTTPException(409,'SAL già collegato a una fattura')
        if conn.execute('SELECT 1 FROM progress_certificates current JOIN progress_certificates later ON later.project_id=current.project_id AND later.active=true AND (later.sequence_no>current.sequence_no OR later.sequence_no=current.sequence_no AND later.id>current.id) WHERE current.id=%s AND current.project_id IS NOT NULL',(sal_id,)).fetchone():
            raise HTTPException(409,'Esiste un SAL successivo dello stesso cantiere: non puoi eliminare questo SAL')
        row=conn.execute('UPDATE progress_certificates SET active=false WHERE id=%s AND active=true RETURNING id',(sal_id,)).fetchone()
        if not row:raise HTTPException(404,'SAL non trovato')
        audit(conn,user,'ARCHIVE','progress_certificates',sal_id)
    return {'ok':True}


def delivery_amount(conn,delivery_id):
    rows=conn.execute('SELECT quantity,unit_price,discount_percent,vat_rate FROM delivery_lines WHERE delivery_id=%s',(delivery_id,)).fetchall()
    net=sum((delivery_line_total(r) for r in rows),Decimal(0))
    vat=sum((money(delivery_line_total(r)*r['vat_rate']/100) for r in rows),Decimal(0))
    try:doc=conn.execute('SELECT global_labor,global_labor_vat,global_travel,global_travel_vat,global_service,global_service_vat,global_discount,global_discount_vat FROM delivery_notes WHERE id=%s',(delivery_id,)).fetchone()
    except (AssertionError,AttributeError):doc=None # Lightweight unit-test connections may expose only line rows.
    if not doc:return money(net),money(vat)
    for amount_key,vat_key,sign in (('global_labor','global_labor_vat',1),('global_travel','global_travel_vat',1),('global_service','global_service_vat',1),('global_discount','global_discount_vat',-1)):
        value=money(doc[amount_key])*sign;net+=value;vat+=money(value*doc[vat_key]/100)
    return money(net),money(vat)


def candidate_period(month=None,date_from=None,date_to=None):
    if month:
        try:
            year,month_num=map(int,month.split('-'))
            assert len(month)==7 and 1<=month_num<=12 and 2000<=year<=2100
            return date(year,month_num,1),date(year,month_num,monthrange(year,month_num)[1])
        except (ValueError,AssertionError):raise HTTPException(400,'Mese non valido: AAAA-MM')
    if date_from and date_to and date_from>date_to:
        raise HTTPException(400,'La data iniziale è successiva alla data finale')
    return date_from,date_to


@router.get('/invoice-sources/candidates')
def candidates(customer_id:int,month:str|None=None,date_from:date|None=None,date_to:date|None=None,user=Depends(allowed('ADMIN','OFFICE'))):
    start,end=candidate_period(month,date_from,date_to)
    fiscal_year=user['selected_fiscal_year']
    with connect() as conn:
        ddt=conn.execute("SELECT d.id,d.number,d.issued_on FROM delivery_notes d JOIN transport_reasons r ON r.id=d.transport_reason_id WHERE d.customer_id=%s AND d.fiscal_year=%s AND d.status='CONFIRMED' AND d.active=true AND d.project_id IS NULL AND d.billing_destination='DIRECT_INVOICE' AND r.invoiceable=true AND (%s::date IS NULL OR d.issued_on >= %s::date) AND (%s::date IS NULL OR d.issued_on <= %s::date) AND NOT EXISTS(SELECT 1 FROM invoice_sources s WHERE s.delivery_id=d.id) ORDER BY d.issued_on,d.id",(customer_id,fiscal_year,start,start,end,end)).fetchall()
        sal=conn.execute("SELECT s.id,s.number,s.issued_on,(s.amount+s.variation_amount-s.retention_amount-s.advance_recovery) amount,s.vat_rate,s.status,COALESCE((SELECT sum(i.taxable) FROM invoice_sources i WHERE i.sal_id=s.id),0) AS invoiced FROM progress_certificates s WHERE s.customer_id=%s AND s.fiscal_year=%s AND s.active=true AND s.project_id IS NULL AND s.approval_status='APPROVED' AND (%s::date IS NULL OR s.issued_on >= %s::date) AND (%s::date IS NULL OR s.issued_on <= %s::date) ORDER BY s.issued_on,s.id",(customer_id,fiscal_year,start,start,end,end)).fetchall()
        ddt_result=[]
        for row in ddt:
            net,vat=delivery_amount(conn,row['id'])
            if net>0:ddt_result.append({**row,'kind':'DDT','available':str(net),'vat':str(vat)})
        sal_result=[{**r,'kind':'SAL','available':str(money(r['amount']-r['invoiced']))} for r in sal if r['amount']>r['invoiced']]
    return {'ddt':ddt_result,'sal':sal_result}


def refresh_invoice(conn,invoice_id):
    from app.billing import refresh
    refresh(conn,invoice_id)


@router.get('/invoice-register/{invoice_id}/sources')
def sources(invoice_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        if not conn.execute('SELECT 1 FROM invoice_register WHERE id=%s AND active=true',(invoice_id,)).fetchone():
            raise HTTPException(404,'Fattura non trovata')
        rows=conn.execute('SELECT s.id,s.delivery_id,s.sal_id,s.taxable,s.vat_amount,d.number AS delivery_number,p.number AS sal_number FROM invoice_sources s LEFT JOIN delivery_notes d ON d.id=s.delivery_id LEFT JOIN progress_certificates p ON p.id=s.sal_id WHERE s.invoice_id=%s ORDER BY s.id',(invoice_id,)).fetchall()
        return [{**r,'taxable':str(r['taxable']),'vat_amount':str(r['vat_amount'])} for r in rows]


@router.post('/invoice-register/{invoice_id}/sources',status_code=201)
def link_source(invoice_id:int,data:SourceIn,user=Depends(allowed('ADMIN','OFFICE'))):
    if data.kind not in ('DDT','SAL'):raise HTTPException(400,'Fonte non valida')
    with connect() as conn:
        inv=conn.execute('SELECT customer_id,status,document_status FROM invoice_register WHERE id=%s AND active=true FOR UPDATE',(invoice_id,)).fetchone()
        if not inv:raise HTTPException(404,'Fattura non trovata')
        if inv['status']!='OPEN' or inv['document_status']!='DRAFT':raise HTTPException(409,'Solo le fatture in bozza possono cambiare i DDT e SAL collegati')
        if data.kind=='DDT':
            row=conn.execute("SELECT d.customer_id,d.status,d.billing_destination,r.invoiceable FROM delivery_notes d LEFT JOIN transport_reasons r ON r.id=d.transport_reason_id WHERE d.id=%s AND d.active=true FOR UPDATE",(data.source_id,)).fetchone()
            if not row or row['customer_id']!=inv['customer_id'] or row['status']!='CONFIRMED' or not row['invoiceable'] or row['billing_destination']!='DIRECT_INVOICE':
                raise HTTPException(400,'DDT non fatturabile, non confermato o cliente diverso')
            if conn.execute('SELECT 1 FROM invoice_sources WHERE delivery_id=%s',(data.source_id,)).fetchone():
                raise HTTPException(409,'DDT già fatturato')
            if conn.execute('SELECT 1 FROM invoice_lines l JOIN delivery_lines d ON d.product_id=l.product_id '
                            'WHERE d.delivery_id=%s AND l.invoice_id=%s AND length(trim(l.duplicate_reason))<8 LIMIT 1',
                            (data.source_id,invoice_id)).fetchone():
                raise HTTPException(409,'Un articolo del DDT è già in fattura: indica il motivo sulla riga manuale prima di collegare il DDT')
            net,vat=delivery_amount(conn,data.source_id)
            if net<=0:raise HTTPException(400,'DDT senza importi fatturabili')
            conn.execute('INSERT INTO invoice_sources(invoice_id,delivery_id,taxable,vat_amount) VALUES (%s,%s,%s,%s)',(invoice_id,data.source_id,net,vat))
        else:
            sal=conn.execute("SELECT customer_id,(amount+variation_amount-retention_amount-advance_recovery) amount,vat_rate,approval_status FROM progress_certificates WHERE id=%s AND active=true FOR UPDATE",(data.source_id,)).fetchone()
            if not sal or sal['customer_id']!=inv['customer_id'] or sal['approval_status']!='APPROVED':
                raise HTTPException(400,'SAL non approvato o non disponibile per il cliente')
            used=conn.execute('SELECT COALESCE(sum(taxable),0) AS used FROM invoice_sources WHERE sal_id=%s',(data.source_id,)).fetchone()['used']
            amount=decimal(data.amount or str(sal['amount']-used),maximum='99999999999.99',minimum='0.01',places=2)
            if amount+used>sal['amount']:raise HTTPException(409,'Importo superiore al residuo SAL')
            if conn.execute('SELECT 1 FROM invoice_sources WHERE invoice_id=%s AND sal_id=%s',(invoice_id,data.source_id)).fetchone():
                raise HTTPException(409,'SAL già presente nella fattura')
            conn.execute('INSERT INTO invoice_sources(invoice_id,sal_id,taxable,vat_amount) VALUES (%s,%s,%s,%s)',(invoice_id,data.source_id,amount,money(amount*sal['vat_rate']/100)))
        refresh_invoice(conn,invoice_id)
        audit(conn,user,'LINK','invoice_sources',invoice_id,{'kind':data.kind,'source_id':data.source_id})
    return {'ok':True}


@router.delete('/invoice-register/{invoice_id}/sources/{source_id}')
def unlink_source(invoice_id:int,source_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        invoice=conn.execute('SELECT status,document_status FROM invoice_register WHERE id=%s AND active=true FOR UPDATE',(invoice_id,)).fetchone()
        if not invoice:
            raise HTTPException(404,'Fattura non trovata')
        if invoice['status']!='OPEN' or invoice['document_status']!='DRAFT':raise HTTPException(409,'Fattura confermata: non modificabile')
        row=conn.execute('DELETE FROM invoice_sources WHERE id=%s AND invoice_id=%s RETURNING id',(source_id,invoice_id)).fetchone()
        if not row:raise HTTPException(404,'Collegamento non trovato')
        refresh_invoice(conn,invoice_id)
        audit(conn,user,'UNLINK','invoice_sources',source_id)
    return {'ok':True}
