"""Readable audit register for commercial documents."""
from datetime import date
from fastapi import APIRouter, Depends, HTTPException
from app.auth import allowed
from app.db import connect

router = APIRouter()

DOCUMENTS = {
    'quotes': 'Preventivo', 'quote_lines': 'Riga preventivo',
    'delivery_notes': 'DDT', 'delivery_lines': 'Riga DDT',
    'progress_certificates': 'SAL', 'invoice_register': 'Fattura',
    'invoice_lines': 'Riga fattura', 'invoice_sources': 'Collegamento fattura',
    'payment_due': 'Scadenza', 'payment_methods': 'Modalità di pagamento',
    'project_sites':'Cantiere','credit_notes':'Nota di credito','credit_note_lines':'Riga nota di credito'
}
ACTIONS = {'CREATE':'Creazione','UPDATE':'Modifica','DELETE':'Eliminazione','ARCHIVE':'Archiviazione',
           'CONFIRM':'Conferma','LINK':'Collegamento','UNLINK':'Scollegamento'}


def query_document_events(*, entity=None, action=None, actor=None, date_from=None, date_to=None, limit=500):
    where=['a.entity = ANY(%s)'];values=[list(DOCUMENTS)]
    if entity:
        if entity not in DOCUMENTS:raise HTTPException(400,'Tipo documento non valido')
        where.append('a.entity=%s');values.append(entity)
    if action:where.append('a.action=%s');values.append(action)
    if actor:where.append('u.username ILIKE %s');values.append('%'+actor+'%')
    if date_from:where.append('a.created_at >= %s');values.append(date_from)
    if date_to:where.append("a.created_at < (%s::date + INTERVAL '1 day')");values.append(date_to)
    sql=('SELECT a.id,a.created_at,a.action,a.entity,a.entity_id,a.details,u.username '
         'FROM audit_events a LEFT JOIN users u ON u.id=a.user_id WHERE '+' AND '.join(where)+
         ' ORDER BY a.created_at DESC,a.id DESC LIMIT %s')
    with connect() as conn:rows=conn.execute(sql,(*values,limit+1)).fetchall()
    if len(rows)>limit:raise HTTPException(413,f'Troppi eventi: restringi i filtri (massimo {limit})')
    return [{**r,'entity_label':DOCUMENTS.get(r['entity'],r['entity']),
             'action_label':ACTIONS.get(r['action'],r['action'])} for r in rows]


@router.get('/document-events')
def document_events(entity:str|None=None,action:str|None=None,actor:str|None=None,
                    date_from:date|None=None,date_to:date|None=None,
                    user=Depends(allowed('ADMIN','OFFICE','WAREHOUSE'))):
    return query_document_events(entity=entity,action=action,actor=actor,date_from=date_from,date_to=date_to)
