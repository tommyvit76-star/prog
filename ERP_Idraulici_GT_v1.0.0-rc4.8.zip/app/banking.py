"""Bank identifiers for invoices and future collections."""
import re
from fastapi import HTTPException


def clean_iban(value: str) -> str:
    iban = re.sub(r'\s+', '', value or '').upper()
    if not iban:
        return ''
    if not re.fullmatch(r'[A-Z]{2}[0-9]{2}[A-Z0-9]{11,30}', iban):
        raise HTTPException(400, 'IBAN non valido: controlla paese, lunghezza e caratteri')
    lengths = {'IT': 27, 'DE': 22, 'FR': 27, 'ES': 24, 'GB': 22}
    if len(iban) != lengths.get(iban[:2], len(iban)):
        raise HTTPException(400, 'Lunghezza IBAN non valida')
    rearranged = iban[4:] + iban[:4]
    remainder = 0
    for character in rearranged:
        for digit in (character if character.isdigit() else str(ord(character)-55)):
            remainder = (remainder*10 + int(digit)) % 97
    if remainder != 1:
        raise HTTPException(400, 'IBAN non valido: cifra di controllo errata')
    return iban
