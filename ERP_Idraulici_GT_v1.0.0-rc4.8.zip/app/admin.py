"""Administrator-only account and company management."""
import base64
import binascii
import re
from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel, Field
from app.auth import allowed, hash_password, verify_password, ROLES
from app.db import connect
from app.catalog import audit
from app.banking import clean_iban
from app.numbering import SOURCES, number_settings, formatted_number, current_last

router = APIRouter()
MODULES = ('customers','suppliers','units','products','warehouses','balances','movements','reports',
           'price-lists','quotes','payments','jobs','sal','ddt','invoices','credit-notes')


class Grant(BaseModel):
    module: str
    view: bool = False
    edit: bool = False


class UserEdit(BaseModel):
    username: str
    role: str = 'OFFICE'
    password: str | None = None
    permissions: list[Grant] = Field(default_factory=list)


class CompanyEdit(BaseModel):
    name: str
    vat_number: str = ''
    address: str = ''
    postal_code: str = ''
    city: str = ''
    province: str = ''
    phone: str = ''
    email: str = ''
    fiscal_regime: str = ''
    tax_code: str = ''
    country: str = 'IT'


class LogoEdit(BaseModel):
    mime_type: str
    data: str


class BankAccountEdit(BaseModel):
    label: str
    bank_name: str = ''
    holder: str = ''
    iban: str


class NumberSettingEdit(BaseModel):
    prefix: str
    separator: str = '-'
    sequence_digits: int = 6
    year_position: str = 'SUFFIX'
    reset_yearly: bool = True
    next_number: int = 1


class TestResetIn(BaseModel):
    password: str
    confirmation: str
    scope: str = 'OPERATIONS'


@router.get('/company-bank-accounts')
def bank_accounts(user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        return conn.execute('SELECT id,label,bank_name,holder,iban FROM company_bank_accounts WHERE active=true ORDER BY label').fetchall()


def save_bank(data, user, account_id=None):
    iban=clean_iban(data.iban)
    if not data.label.strip() or not iban or not data.holder.strip():
        raise HTTPException(400,'Nome conto, intestatario e IBAN obbligatori')
    with connect() as conn:
        if account_id is None:
            row=conn.execute('INSERT INTO company_bank_accounts(label,bank_name,holder,iban) VALUES (%s,%s,%s,%s) RETURNING id',
                             (data.label.strip(),data.bank_name.strip(),data.holder.strip(),iban)).fetchone()
        else:
            row=conn.execute('UPDATE company_bank_accounts SET label=%s,bank_name=%s,holder=%s,iban=%s WHERE id=%s AND active=true RETURNING id',
                             (data.label.strip(),data.bank_name.strip(),data.holder.strip(),iban,account_id)).fetchone()
            if not row:raise HTTPException(404,'Conto aziendale non trovato')
        audit(conn,user,'CREATE' if account_id is None else 'UPDATE','company_bank_accounts',row['id'])
        return {'id':row['id']}


@router.post('/company-bank-accounts',status_code=201)
def add_bank(data:BankAccountEdit,user=Depends(allowed('ADMIN'))):
    return save_bank(data,user)


@router.put('/company-bank-accounts/{account_id}')
def edit_bank(account_id:int,data:BankAccountEdit,user=Depends(allowed('ADMIN'))):
    return save_bank(data,user,account_id)


@router.delete('/company-bank-accounts/{account_id}')
def archive_bank(account_id:int,user=Depends(allowed('ADMIN'))):
    with connect() as conn:
        if conn.execute('SELECT 1 FROM payment_methods WHERE bank_account_id=%s AND active=true LIMIT 1',(account_id,)).fetchone():
            raise HTTPException(409,'Conto associato a una modalità attiva: modifica prima la modalità')
        row=conn.execute('UPDATE company_bank_accounts SET active=false WHERE id=%s AND active=true RETURNING id',(account_id,)).fetchone()
        if not row:raise HTTPException(404,'Conto aziendale non trovato')
        audit(conn,user,'ARCHIVE','company_bank_accounts',account_id)
    return {'ok':True}


def validate_user(data, creating=False):
    if not re.fullmatch(r'[\w.@-]{2,80}', data.username, re.UNICODE):
        raise HTTPException(400,'Nome utente non valido (2-80 caratteri)')
    if data.role not in ROLES:
        raise HTTPException(400,'Ruolo non valido')
    if creating and not data.password:
        raise HTTPException(400,'Password richiesta')
    names = [p.module for p in data.permissions]
    if len(names) != len(set(names)) or any(name not in MODULES for name in names):
        raise HTTPException(400,'Permessi duplicati o sconosciuti')
    if data.password is not None:
        try:
            return hash_password(data.password)
        except ValueError as exc:
            raise HTTPException(400,str(exc)) from exc
    return None


def set_grants(conn, user_id, grants):
    conn.execute('DELETE FROM user_modules WHERE user_id=%s',(user_id,))
    for grant in grants:
        if grant.view or grant.edit:
            conn.execute('INSERT INTO user_modules(user_id,module,can_view,can_edit) VALUES (%s,%s,%s,%s)',
                         (user_id,grant.module,grant.view or grant.edit,grant.edit))


@router.get('/admin/modules')
def modules(user=Depends(allowed('ADMIN'))):
    return list(MODULES[:11])+['invoices','ddt','sal']


@router.get('/admin/users')
def users(user=Depends(allowed('ADMIN'))):
    with connect() as conn:
        rows = conn.execute('SELECT id,username,role,active,created_at FROM users ORDER BY username').fetchall()
        grants = conn.execute('SELECT user_id,module,can_view,can_edit FROM user_modules').fetchall()
    return [{**row,'permissions':[{'module':g['module'],'view':g['can_view'],'edit':g['can_edit']}
             for g in grants if g['user_id']==row['id']]} for row in rows]


@router.post('/admin/users', status_code=201)
def create_user(data: UserEdit, user=Depends(allowed('ADMIN'))):
    hashed = validate_user(data,True)
    with connect() as conn:
        if conn.execute('SELECT 1 FROM users WHERE lower(username)=lower(%s)',(data.username,)).fetchone():
            raise HTTPException(409,'Nome utente già utilizzato')
        row = conn.execute('INSERT INTO users(username,password_hash,role) VALUES (%s,%s,%s) RETURNING id',
                           (data.username,hashed,data.role)).fetchone()
        set_grants(conn,row['id'],data.permissions)
        audit(conn,user,'CREATE','users',row['id'])
        return {'id':row['id']}


@router.put('/admin/users/{user_id}')
def update_user(user_id: int, data: UserEdit, user=Depends(allowed('ADMIN'))):
    hashed = validate_user(data)
    with connect() as conn:
        conn.execute('SELECT pg_advisory_xact_lock(783453)')
        old = conn.execute('SELECT role,active FROM users WHERE id=%s FOR UPDATE',(user_id,)).fetchone()
        if not old or not old['active']:
            raise HTTPException(404,'Utente non trovato')
        if old['role']=='ADMIN' and data.role!='ADMIN':
            count=conn.execute("SELECT count(*) AS n FROM users WHERE role='ADMIN' AND active=true").fetchone()['n']
            if count <= 1 or user_id==user['id']:
                raise HTTPException(409,'Non puoi rimuovere il tuo ruolo admin o l’ultimo amministratore')
        if conn.execute('SELECT 1 FROM users WHERE lower(username)=lower(%s) AND id<>%s',(data.username,user_id)).fetchone():
            raise HTTPException(409,'Nome utente già utilizzato')
        if hashed:
            conn.execute('UPDATE users SET username=%s,role=%s,password_hash=%s WHERE id=%s',
                         (data.username,data.role,hashed,user_id))
        else:
            conn.execute('UPDATE users SET username=%s,role=%s WHERE id=%s',(data.username,data.role,user_id))
        set_grants(conn,user_id,data.permissions)
        if hashed or old['role']!=data.role:
            conn.execute('DELETE FROM sessions WHERE user_id=%s',(user_id,))
        audit(conn,user,'UPDATE','users',user_id)
        return {'id':user_id}


@router.delete('/admin/users/{user_id}')
def disable_user(user_id: int, user=Depends(allowed('ADMIN'))):
    if user_id==user['id']:
        raise HTTPException(409,'Non puoi disattivare il tuo account')
    with connect() as conn:
        conn.execute('SELECT pg_advisory_xact_lock(783453)')
        old=conn.execute('SELECT role FROM users WHERE id=%s AND active=true FOR UPDATE',(user_id,)).fetchone()
        if not old:raise HTTPException(404,'Utente non trovato')
        if old['role']=='ADMIN' and conn.execute("SELECT count(*) AS n FROM users WHERE role='ADMIN' AND active=true").fetchone()['n']<=1:
            raise HTTPException(409,'È necessario almeno un amministratore attivo')
        conn.execute('UPDATE users SET active=false WHERE id=%s',(user_id,))
        conn.execute('DELETE FROM sessions WHERE user_id=%s',(user_id,))
        audit(conn,user,'DISABLE','users',user_id)
        return {'ok':True}


@router.get('/company')
def company():
    with connect() as conn:
        return conn.execute('SELECT name,vat_number,address,postal_code,city,province,phone,email,fiscal_regime,tax_code,country,logo_data IS NOT NULL AS has_logo FROM company_settings WHERE id=1').fetchone()


@router.put('/admin/company')
def update_company(data: CompanyEdit,user=Depends(allowed('ADMIN'))):
    if not data.name.strip() or len(data.name)>160:
        raise HTTPException(400,'Nome azienda richiesto (massimo 160 caratteri)')
    if data.country!='IT' or data.fiscal_regime and not re.fullmatch(r'RF\d{2}',data.fiscal_regime):
        raise HTTPException(400,'Paese o regime fiscale non valido')
    with connect() as conn:
        values=data.model_dump()
        conn.execute('UPDATE company_settings SET name=%s,vat_number=%s,address=%s,postal_code=%s,city=%s,province=%s,phone=%s,email=%s,fiscal_regime=%s,tax_code=%s,country=%s,updated_at=now() WHERE id=1',tuple(values.values()))
        audit(conn,user,'UPDATE','company',1)
    return {'ok':True}


@router.post('/admin/users/{user_id}/restore')
def restore_user(user_id: int, user=Depends(allowed('ADMIN'))):
    with connect() as conn:
        row=conn.execute('UPDATE users SET active=true WHERE id=%s AND active=false RETURNING id',(user_id,)).fetchone()
        if not row:raise HTTPException(404,'Utente non disattivato')
        audit(conn,user,'RESTORE','users',user_id)
    return {'ok':True}


@router.get('/company/logo')
def get_company_logo():
    with connect() as conn:
        row=conn.execute('SELECT logo_data,logo_mime FROM company_settings WHERE id=1').fetchone()
    if not row or row['logo_data'] is None:raise HTTPException(404,'Logo non caricato')
    return Response(bytes(row['logo_data']),media_type=row['logo_mime'],headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})


@router.put('/admin/company/logo')
def put_company_logo(data:LogoEdit,user=Depends(allowed('ADMIN'))):
    try:
        raw=base64.b64decode(data.data,validate=True)
    except (ValueError,binascii.Error) as exc:
        raise HTTPException(400,'Immagine non valida') from exc
    valid={'image/png':raw.startswith(b'\x89PNG\r\n\x1a\n'),
           'image/jpeg':raw.startswith(b'\xff\xd8\xff'),
           'image/webp':raw[:4]==b'RIFF' and raw[8:12]==b'WEBP'}
    if not valid.get(data.mime_type,False) or len(raw)>2097152 or not raw:
        raise HTTPException(400,'Logo PNG, JPEG o WebP fino a 2 MB')
    with connect() as conn:
        conn.execute('UPDATE company_settings SET logo_data=%s,logo_mime=%s,updated_at=now() WHERE id=1',(raw,data.mime_type))
        audit(conn,user,'UPDATE','company_logo',1)
    return {'ok':True}


@router.delete('/admin/company/logo')
def delete_company_logo(user=Depends(allowed('ADMIN'))):
    with connect() as conn:
        conn.execute('UPDATE company_settings SET logo_data=NULL,logo_mime=NULL,updated_at=now() WHERE id=1')
        audit(conn,user,'DELETE','company_logo',1)
    return {'ok':True}


@router.get('/admin/document-number-settings')
def document_number_settings(year:int,user=Depends(allowed('ADMIN'))):
    if not 2000<=year<=2100:raise HTTPException(400,'Anno non valido')
    result=[]
    with connect() as conn:
        for kind in SOURCES:
            settings=dict(number_settings(conn,kind));last=current_last(conn,kind,year,settings)
            result.append({'document_type':kind,**settings,'last_number':last,'next_number':last+1,
                           'preview':formatted_number(settings,year,last+1)})
    return result


@router.put('/admin/document-number-settings/{kind}')
def update_document_number_settings(kind:str,year:int,data:NumberSettingEdit,user=Depends(allowed('ADMIN'))):
    if kind not in SOURCES or not 2000<=year<=2100:raise HTTPException(400,'Tipo documento o anno non valido')
    prefix=data.prefix.strip().upper();separator=data.separator
    if not re.fullmatch(r'[A-Z0-9]{1,12}',prefix) or separator not in ('-','/','.') or not 3<=data.sequence_digits<=10 or data.year_position not in ('PREFIX','SUFFIX') or data.next_number<1:
        raise HTTPException(400,'Formato progressivo non valido')
    with connect() as conn:
        conn.execute('SELECT pg_advisory_xact_lock(783461,hashtext(%s))',(kind,))
        settings={'prefix':prefix,'separator':separator,'sequence_digits':data.sequence_digits,'year_position':data.year_position,'reset_yearly':data.reset_yearly}
        tables=SOURCES[kind]
        has_documents=bool(conn.execute(f'SELECT 1 FROM {tables} WHERE fiscal_year=%s LIMIT 1',(year,)).fetchone())
        old=number_settings(conn,kind);last=current_last(conn,kind,year,old)
        if has_documents and data.next_number<=last:
            raise HTTPException(409,f'Il prossimo numero deve essere maggiore di {last}; i numeri già usati non possono essere riutilizzati')
        conn.execute('INSERT INTO document_number_settings(document_type,prefix,separator,sequence_digits,year_position,reset_yearly,updated_at) VALUES (%s,%s,%s,%s,%s,%s,now()) ON CONFLICT(document_type) DO UPDATE SET prefix=EXCLUDED.prefix,separator=EXCLUDED.separator,sequence_digits=EXCLUDED.sequence_digits,year_position=EXCLUDED.year_position,reset_yearly=EXCLUDED.reset_yearly,updated_at=now()',(kind,prefix,separator,data.sequence_digits,data.year_position,data.reset_yearly))
        conn.execute('INSERT INTO document_sequences(document_type,document_year,last_number) VALUES (%s,%s,%s) ON CONFLICT(document_type,document_year) DO UPDATE SET last_number=EXCLUDED.last_number',(kind,year,data.next_number-1))
        audit(conn,user,'UPDATE','document_number_settings',year,{'kind':kind,'next_number':data.next_number})
    return {'ok':True,'preview':formatted_number(settings,year,data.next_number)}


@router.post('/admin/reset-test-data')
def reset_test_data(data:TestResetIn,user=Depends(allowed('ADMIN'))):
    if data.scope not in ('OPERATIONS','ALL_MASTER'):
        raise HTTPException(400,'Tipo di azzeramento non valido')
    expected='AZZERA TUTTO' if data.scope=='ALL_MASTER' else 'AZZERA DATI DI PROVA'
    if data.confirmation!=expected:
        raise HTTPException(400,f'Scrivi esattamente: {expected}')
    with connect() as conn:
        account=conn.execute('SELECT password_hash FROM users WHERE id=%s AND active=true',(user['id'],)).fetchone()
    if not account or not verify_password(data.password,account['password_hash']):
        raise HTTPException(401,'Password amministratore non corretta')
    from app.backups import create_backup, exclusive
    with exclusive():
        try:backup=create_backup()
        except Exception as exc:raise HTTPException(500,'Azzeramento annullato: backup non riuscito') from exc
        try:
            with connect() as conn:
                conn.execute('SELECT pg_advisory_xact_lock(783469)')
                operational=['customer_credits','credit_note_lines','credit_notes','payment_due','invoice_references','invoice_sources','invoice_lines','invoice_register','delivery_lines','delivery_notes','progress_certificates','project_quote_links','project_sites','quote_lines','quotes','balances','movements','document_sequences','audit_events']
                master=['product_photos','bom_lines','product_list_prices','customer_addresses','supplier_addresses','products','product_categories','customers','purchase_discount_profiles','suppliers','warehouses','price_lists'] if data.scope=='ALL_MASTER' else []
                tables=operational+master
                counts={table:conn.execute(f'SELECT count(*) AS n FROM {table}').fetchone()['n'] for table in tables}
                # One PostgreSQL statement makes the reset atomic, observes all
                # foreign keys together and restarts every owned identity.
                conn.execute('TRUNCATE TABLE '+','.join(tables)+' RESTART IDENTITY')
                if data.scope=='ALL_MASTER':
                    conn.execute("INSERT INTO price_lists(code,name,active) VALUES ('BASE','Listino base',true)")
                audit(conn,user,'RESET','test_data',user['id'],{'backup':backup.name,'scope':data.scope,'counts':counts})
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(500,'Azzeramento non riuscito. Il database non è stato modificato; il backup è stato conservato.') from exc
    return {'ok':True,'backup':backup.name,'scope':data.scope,'counts':counts}

