import os
from contextlib import contextmanager, nullcontext
from contextvars import ContextVar
import psycopg
from psycopg.rows import dict_row


_document_connection = ContextVar('document_connection', default=None)


def connect():
    shared = _document_connection.get()
    if shared is not None:
        return nullcontext(shared)
    return psycopg.connect(os.environ['DATABASE_URL'], row_factory=dict_row)


@contextmanager
def atomic_document():
    """Compose existing document services in one transaction, isolated per request."""
    with connect() as conn:
        marker = _document_connection.set(conn)
        try:
            with conn.transaction():
                yield conn
        finally:
            _document_connection.reset(marker)
