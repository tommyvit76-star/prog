"""Payment method registry, invoice references and due dates."""
import json
from datetime import date, timedelta
from calendar import monthrange
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from app.auth import allowed
from app.catalog import audit
from app.db import connect
from app.quotes import decimal
from app.numbering import next_document_number, assert_free_number
from app.fiscal_years import assert_open

router=APIRouter()


class MethodIn(BaseModel):
    name: str
    description: str = ''
    default_days: int = 0
    end_of_month: bool = False
    extra_days: int = 0
    payment_type: str = 'OTHER'
    bank_account_id: int | None = None
    show_iban: bool = True


class DueIn(BaseModel):
    invoice_id: int
    payment_method_id: int | None = None
    due_date: date | None = None
    amount: str
    status: str = 'OPEN'
    paid_at: date | None = None
    notes: str = ''


class InvoiceIn(BaseModel):
    customer_id: int | None = None
    casual_customer: dict | None = None
    number: str = ''
    issue_date: date
    taxable: str = '0'
    vat_amount: str = '0'
    total: str = '0'
    payment_method_id: int | None = None
    bank_account_id: int | None = None
    quote_id: int | None = None
    project_id: int | None = None
    status: str = 'OPEN'
    notes: str = ''
    fiscal_document_type: str = 'TD01'


def checked_method(data):
    if not data.name.strip() or len(data.name)>120 or not 0<=data.default_days<=3650 or not 0<=data.extra_days<=3650 or data.payment_type not in ('OTHER','TRANSFER','RIBA'):
        raise HTTPException(400,'Nome o giorni di pagamento non validi')
    return data.model_dump()


def suggested_due_date(issue_date, default_days=0, end_of_month=False, extra_days=0):
    calculated=issue_date+timedelta(days=default_days)
    if end_of_month:
        calculated=calculated.replace(day=monthrange(calculated.year,calculated.month)[1])
    return calculated+timedelta(days=extra_days)


@router.get('/payment-methods')
def methods(user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        return conn.execute('SELECT id,name,description,default_days,end_of_month,extra_days,payment_type,bank_account_id,show_iban FROM payment_methods WHERE active=true ORDER BY name').fetchall()


@router.post('/payment-methods',status_code=201)
def add_method(data:MethodIn,user=Depends(allowed('ADMIN','OFFICE'))):
    values=checked_method(data)
    with connect() as conn:
        if data.bank_account_id and not conn.execute('SELECT 1 FROM company_bank_accounts WHERE id=%s AND active=true',(data.bank_account_id,)).fetchone():
            raise HTTPException(400,'Conto aziendale non trovato')
        if conn.execute('SELECT 1 FROM payment_methods WHERE lower(name)=lower(%s)',(data.name,)).fetchone():
            raise HTTPException(409,'Nome modalità già presente')
        row=conn.execute('INSERT INTO payment_methods(name,description,default_days,end_of_month,extra_days,payment_type,bank_account_id,show_iban) VALUES (%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id',tuple(values.values())).fetchone()
        audit(conn,user,'CREATE','payment_methods',row['id'])
        return {'id':row['id']}


@router.put('/payment-methods/{method_id}')
def edit_method(method_id:int,data:MethodIn,user=Depends(allowed('ADMIN','OFFICE'))):
    values=checked_method(data)
    with connect() as conn:
        if data.bank_account_id and not conn.execute('SELECT 1 FROM company_bank_accounts WHERE id=%s AND active=true',(data.bank_account_id,)).fetchone():
            raise HTTPException(400,'Conto aziendale non trovato')
        if conn.execute('SELECT 1 FROM payment_methods WHERE lower(name)=lower(%s) AND id<>%s',(data.name,method_id)).fetchone():
            raise HTTPException(409,'Nome modalità già presente')
        row=conn.execute('UPDATE payment_methods SET name=%s,description=%s,default_days=%s,end_of_month=%s,extra_days=%s,payment_type=%s,bank_account_id=%s,show_iban=%s WHERE id=%s AND active=true RETURNING id',(*values.values(),method_id)).fetchone()
        if not row:raise HTTPException(404,'Modalità non trovata')
        audit(conn,user,'UPDATE','payment_methods',method_id)
        return {'id':method_id}


@router.delete('/payment-methods/{method_id}')
def archive_method(method_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        row=conn.execute('UPDATE payment_methods SET active=false WHERE id=%s AND active=true RETURNING id',(method_id,)).fetchone()
        if not row:raise HTTPException(404,'Modalità non trovata')
        audit(conn,user,'ARCHIVE','payment_methods',method_id)
    return {'ok':True}


@router.get('/invoice-register')
def invoices(user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        rows=conn.execute('SELECT i.*,m.name AS payment_method_name FROM invoice_register i '
                          'LEFT JOIN payment_methods m ON m.id=i.payment_method_id '
                          'WHERE i.active=true AND i.fiscal_year=%s ORDER BY i.issue_date DESC,i.id DESC LIMIT 1000',(user['selected_fiscal_year'],)).fetchall()
    return [{**r, 'total':str(r['total']), 'taxable':str(r['taxable']), 'vat_amount':str(r['vat_amount'])} for r in rows]


def save_invoice(data,user,invoice_id=None):
    values=data.model_dump()
    if len(data.number)>80 or data.status not in ('OPEN','PAID','CANCELLED') or data.fiscal_document_type not in ('TD01','TD24'):
        raise HTTPException(400,'Numero o stato fattura non valido')
    for key,minimum in [('taxable','0'),('vat_amount','0'),('total','0')]:
        values[key]=decimal(values[key],maximum='99999999999.99',minimum=minimum,places=2)
    with connect() as conn:
        if invoice_id:
            original_date=conn.execute('SELECT issue_date FROM invoice_register WHERE id=%s FOR UPDATE',(invoice_id,)).fetchone()
            if original_date:assert_open(conn,original_date['issue_date'])
        assert_open(conn,data.issue_date)
        values['fiscal_year']=data.issue_date.year
        old=conn.execute('SELECT customer_id,bank_account_id,bank_name,bank_holder,bank_iban,customer_bank_name,customer_iban,payment_method_id,payment_type,show_iban,document_status FROM invoice_register WHERE id=%s AND active=true FOR UPDATE',(invoice_id,)).fetchone() if invoice_id else None
        if invoice_id and not old:raise HTTPException(404,'Fattura non trovata')
        if old and old['document_status']=='CONFIRMED':raise HTTPException(409,'Fattura confermata: usa un documento di rettifica')
        if invoice_id is None and not values['number'].strip():
            values['number']=next_document_number(conn,'FT',data.issue_date)
        elif not values['number'].strip():
            raise HTTPException(400,'Numero fattura richiesto in modifica')
        assert_free_number(conn,'FT',values['number'],invoice_id)
        if data.number.strip() and user['role']!='ADMIN':
            old_number=conn.execute('SELECT number FROM invoice_register WHERE id=%s',(invoice_id,)).fetchone() if invoice_id else None
            if not old_number or old_number['number']!=values['number']:
                raise HTTPException(403,'Solo l’amministratore può forzare il numero')
        casual=data.casual_customer
        if bool(data.customer_id)==bool(casual):raise HTTPException(400,'Scegli un cliente registrato oppure compila il cliente occasionale')
        if data.customer_id:
            customer=conn.execute('SELECT name FROM customers WHERE id=%s AND active=true',(data.customer_id,)).fetchone()
            if not customer:raise HTTPException(400,'Cliente non trovato')
            values['casual_customer']=None
        else:
            required=('name','address','postal_code','city','province','vat_number')
            casual={key:str((casual or {}).get(key,'')).strip() for key in ('name','address','postal_code','city','province','vat_number','tax_code','sdi_code','pec')}
            missing=[key for key in required if not casual[key]]
            if missing:raise HTTPException(400,'Cliente occasionale incompleto: '+', '.join(missing))
            casual['id']=0;customer={'name':casual['name']};values['casual_customer']=json.dumps(casual)
        method_record=conn.execute('SELECT payment_type,bank_account_id,show_iban FROM payment_methods WHERE id=%s',(data.payment_method_id,)).fetchone() if data.payment_method_id else None
        if data.payment_method_id and not method_record:
            raise HTTPException(400,'Modalità di pagamento non trovata')
        values['payment_type']=method_record['payment_type'] if method_record else 'OTHER'
        values['show_iban']=method_record['show_iban'] if method_record else False
        chosen_account_id=data.bank_account_id
        if chosen_account_id is None and method_record:
            chosen_account_id=method_record['bank_account_id']
        account=conn.execute('SELECT bank_name,holder,iban FROM company_bank_accounts WHERE id=%s AND active=true',(chosen_account_id,)).fetchone() if chosen_account_id else None
        if chosen_account_id and not account and not (old and old['bank_account_id']==chosen_account_id):
            raise HTTPException(400,'Conto aziendale non trovato o archiviato')
        values['bank_account_id']=chosen_account_id
        if old and old['bank_account_id']==chosen_account_id and old['payment_method_id']==data.payment_method_id:
            values.update(bank_name=old['bank_name'],bank_holder=old['bank_holder'],bank_iban=old['bank_iban'],payment_type=old['payment_type'],show_iban=old['show_iban'])
        else:
            values.update(bank_name=account['bank_name'] if account else '',bank_holder=account['holder'] if account else '',
                          bank_iban=account['iban'] if account else '')
        customer_bank=conn.execute('SELECT bank_name,iban FROM customers WHERE id=%s',(data.customer_id,)).fetchone() if data.customer_id else {'bank_name':'','iban':''}
        if old and old['customer_id']==data.customer_id:
            values.update(customer_bank_name=old['customer_bank_name'],customer_iban=old['customer_iban'])
        else:
            values.update(customer_bank_name=customer_bank['bank_name'],customer_iban=customer_bank['iban'])
        if data.quote_id and not conn.execute('SELECT 1 FROM quotes WHERE id=%s',(data.quote_id,)).fetchone():
            raise HTTPException(400,'Preventivo non trovato')
        if data.quote_id and conn.execute('SELECT 1 FROM delivery_notes WHERE quote_id=%s AND active=true',(data.quote_id,)).fetchone():
            raise HTTPException(409,'Il preventivo è già passato da un DDT: crea la fattura richiamando quel DDT')
        if data.project_id:
            if not data.customer_id:raise HTTPException(400,'Per collegare un cantiere seleziona un cliente registrato')
            project=conn.execute('SELECT customer_id FROM project_sites WHERE id=%s AND active=true',(data.project_id,)).fetchone()
            if not project or project['customer_id']!=data.customer_id:raise HTTPException(400,'Cantiere non valido per il cliente')
        if invoice_id:
            existing_sources=conn.execute('SELECT 1 FROM invoice_sources WHERE invoice_id=%s LIMIT 1',(invoice_id,)).fetchone()
            existing_lines=conn.execute('SELECT 1 FROM invoice_lines WHERE invoice_id=%s LIMIT 1',(invoice_id,)).fetchone()
            if existing_sources or existing_lines:
                if old['customer_id']!=data.customer_id:
                    raise HTTPException(409,'Prima rimuovi righe e documenti collegati alla fattura')
                previous=conn.execute('SELECT taxable,vat_amount,total FROM invoice_register WHERE id=%s',(invoice_id,)).fetchone()
                if any(k in data.model_fields_set and values[k]!=previous[k] for k in ('taxable','vat_amount','total')):
                    raise HTTPException(409,'Importi calcolati dalle righe e dai DDT/SAL: modifica le fonti')
                values.update({k:previous[k] for k in ('taxable','vat_amount','total')})
            due=conn.execute("SELECT COALESCE(sum(amount),0) AS total FROM payment_due WHERE invoice_id=%s AND active=true AND status<>'CANCELLED'",(invoice_id,)).fetchone()['total']
            if due>values['total']:
                raise HTTPException(409,'Totale fattura inferiore alle scadenze già registrate')
        # The printable name must follow edits to an occasional customer too;
        # confirmed invoices are already protected above and keep their snapshot.
        values['customer_name']=customer['name']
        cols=list(values)
        if invoice_id is None:
            row=conn.execute(f"INSERT INTO invoice_register ({','.join(cols)}) VALUES ({','.join(['%s']*len(cols))}) RETURNING id",tuple(values.values())).fetchone()
        else:
            row=conn.execute(f"UPDATE invoice_register SET {','.join(c+'=%s' for c in cols)} WHERE id=%s AND active=true RETURNING id",(*values.values(),invoice_id)).fetchone()
            if not row:raise HTTPException(404,'Fattura non trovata')
        audit(conn,user,'CREATE' if invoice_id is None else 'UPDATE','invoice_register',row['id'])
        return {'id':row['id']}


@router.post('/invoice-register',status_code=201)
def add_invoice(data:InvoiceIn,user=Depends(allowed('ADMIN','OFFICE'))):
    return save_invoice(data,user)


@router.put('/invoice-register/{invoice_id}')
def edit_invoice(invoice_id:int,data:InvoiceIn,user=Depends(allowed('ADMIN','OFFICE'))):
    return save_invoice(data,user,invoice_id)


@router.delete('/invoice-register/{invoice_id}')
def archive_invoice(invoice_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        current=conn.execute('SELECT i.issue_date,f.status fiscal_status FROM invoice_register i JOIN fiscal_years f ON f.year=i.fiscal_year WHERE i.id=%s AND i.active=true FOR UPDATE',(invoice_id,)).fetchone()
        if not current:
            raise HTTPException(404,'Fattura non trovata')
        if current['fiscal_status']!='OPEN':raise HTTPException(409,'Esercizio chiuso: fattura in sola lettura')
        if conn.execute('SELECT 1 FROM payment_due WHERE invoice_id=%s AND active=true',(invoice_id,)).fetchone():
            raise HTTPException(409,'Prima archivia le scadenze della fattura')
        if conn.execute('SELECT 1 FROM invoice_sources WHERE invoice_id=%s',(invoice_id,)).fetchone():
            raise HTTPException(409,'Prima rimuovi i DDT e SAL collegati')
        if conn.execute('SELECT 1 FROM invoice_lines WHERE invoice_id=%s',(invoice_id,)).fetchone():
            raise HTTPException(409,'Prima rimuovi le righe della fattura')
        if conn.execute("SELECT 1 FROM invoice_register WHERE id=%s AND document_status='CONFIRMED'",(invoice_id,)).fetchone():
            raise HTTPException(409,'Fattura confermata: conserva il numero e il documento')
        if conn.execute('SELECT 1 FROM credit_notes WHERE original_invoice_id=%s AND active=true',(invoice_id,)).fetchone():
            raise HTTPException(409,'Fattura collegata a una nota di credito')
        row=conn.execute('UPDATE invoice_register SET active=false WHERE id=%s AND active=true RETURNING id',(invoice_id,)).fetchone()
        audit(conn,user,'ARCHIVE','invoice_register',invoice_id)
    return {'ok':True}


@router.get('/payment-due')
def due_list(invoice_id:int|None=None,customer_id:int|None=None,status:str|None=None,
             due_from:date|None=None,due_to:date|None=None,overdue:bool=False,
             user=Depends(allowed('ADMIN','OFFICE'))):
    if status and status not in ('OPEN','PAID','CANCELLED'):
        raise HTTPException(400,'Stato scadenza non valido')
    if due_from and due_to and due_from>due_to:
        raise HTTPException(400,'Intervallo date non valido')
    # Keep the selected exercise focused, while carrying forward unpaid items
    # from older exercises so they cannot disappear from the collection diary.
    where=['d.active=true', "(i.fiscal_year=%s OR d.status='OPEN')"]
    params=[user['selected_fiscal_year']]
    for column,value in [('d.invoice_id',invoice_id),('i.customer_id',customer_id),('d.status',status)]:
        if value is not None:where.append(column+'=%s');params.append(value)
    if due_from:where.append('d.due_date >= %s');params.append(due_from)
    if due_to:where.append('d.due_date <= %s');params.append(due_to)
    if overdue:where.extend(["d.status='OPEN'",'d.due_date < current_date'])
    with connect() as conn:
        rows=conn.execute('SELECT d.*,i.number AS invoice_number,i.customer_id,i.customer_name,m.name AS payment_method_name '
                          'FROM payment_due d JOIN invoice_register i ON i.id=d.invoice_id '
                          'LEFT JOIN payment_methods m ON m.id=d.payment_method_id '
                          'WHERE '+' AND '.join(where)+' ORDER BY d.due_date,d.id LIMIT 10001',tuple(params)).fetchall()
    if len(rows)>10000:raise HTTPException(413,'Troppi risultati: restringi i filtri')
    return [{**r,'amount':str(r['amount'])} for r in rows]


def save_due(data,user,due_id=None):
    values=data.model_dump()
    values['amount']=decimal(values['amount'],maximum='99999999999.99',minimum='0.01',places=2)
    if values['status'] not in ('OPEN','PAID','CANCELLED'):
        raise HTTPException(400,'Stato scadenza non valido')
    if values['status']=='PAID' and not values['paid_at']:
        values['paid_at']=date.today()
    if values['status']!='PAID':
        values['paid_at']=None
    with connect() as conn:
        existing=conn.execute('SELECT invoice_id,due_date,generated,status,amount FROM payment_due WHERE id=%s AND active=true FOR UPDATE',(due_id,)).fetchone() if due_id else None
        if due_id and not existing:raise HTTPException(404,'Scadenza non trovata')
        if existing and existing['generated'] and values['invoice_id']!=existing['invoice_id']:
            raise HTTPException(409,'Una rata generata non può essere spostata a un’altra fattura')
        if existing and existing['status']=='PAID' and values['status']!='PAID':
            raise HTTPException(409,'Rata pagata: serve una rettifica esplicita')
        if existing and existing['status']=='PAID' and (values['amount']!=existing['amount'] or data.invoice_id!=existing['invoice_id']):
            raise HTTPException(409,'Una rata pagata non può cambiare importo o fattura')
        invoice=conn.execute('SELECT total,issue_date FROM invoice_register WHERE id=%s AND active=true FOR UPDATE',(values['invoice_id'],)).fetchone()
        if not invoice:
            raise HTTPException(400,'Fattura non trovata')
        if values['due_date'] is None:
            method=conn.execute('SELECT default_days,end_of_month,extra_days FROM payment_methods WHERE id=%s',(values['payment_method_id'],)).fetchone() if values['payment_method_id'] else None
            if values['payment_method_id'] and not method:raise HTTPException(400,'Modalità non trovata')
            values['due_date']=suggested_due_date(invoice['issue_date'],**method) if method else invoice['issue_date']
        if values['status']!='CANCELLED':
            previous=conn.execute("SELECT COALESCE(sum(amount),0) AS amount FROM payment_due WHERE invoice_id=%s AND active=true AND status<>'CANCELLED' AND id<>%s",(values['invoice_id'],due_id or 0)).fetchone()['amount']
            if previous+values['amount']>Decimal(str(invoice['total'])):
                raise HTTPException(409,'La somma delle scadenze supera il totale della fattura')
        if values['payment_method_id'] is not None and not conn.execute('SELECT 1 FROM payment_methods WHERE id=%s',(values['payment_method_id'],)).fetchone():
            raise HTTPException(400,'Modalità non trovata')
        cols=list(values)
        if due_id is None:
            row=conn.execute(f"INSERT INTO payment_due ({','.join(cols)}) VALUES ({','.join(['%s']*len(cols))}) RETURNING id",tuple(values.values())).fetchone()
        else:
            row=conn.execute(f"UPDATE payment_due SET {','.join(c+'=%s' for c in cols)} WHERE id=%s AND active=true RETURNING id",(*values.values(),due_id)).fetchone()
            if not row:raise HTTPException(404,'Scadenza non trovata')
            if existing['generated'] and values['due_date']!=existing['due_date']:
                conn.execute('UPDATE payment_due SET date_overridden=true WHERE id=%s',(due_id,))
        if values['status']=='PAID':
            balance=conn.execute("SELECT COALESCE(sum(amount),0) AS paid FROM payment_due WHERE invoice_id=%s AND active=true AND status='PAID'",(values['invoice_id'],)).fetchone()['paid']
            if balance>=invoice['total'] and invoice['total']>0:
                conn.execute("UPDATE invoice_register SET status='PAID' WHERE id=%s AND document_status='CONFIRMED'",(values['invoice_id'],))
        elif existing and existing['status']=='PAID':
            conn.execute("UPDATE invoice_register SET status='OPEN' WHERE id=%s AND document_status='CONFIRMED'",(values['invoice_id'],))
        audit(conn,user,'CREATE' if due_id is None else 'UPDATE','payment_due',row['id'])
        return {'id':row['id']}


@router.post('/payment-due',status_code=201)
def add_due(data:DueIn,user=Depends(allowed('ADMIN','OFFICE'))):
    return save_due(data,user)


@router.put('/payment-due/{due_id}')
def edit_due(due_id:int,data:DueIn,user=Depends(allowed('ADMIN','OFFICE'))):
    return save_due(data,user,due_id)


@router.delete('/payment-due/{due_id}')
def remove_due(due_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        row=conn.execute("UPDATE payment_due SET active=false WHERE id=%s AND active=true AND status<>'PAID' RETURNING id",(due_id,)).fetchone()
        if not row:raise HTTPException(409,'Scadenza pagata o non trovata: registra una rettifica')
        audit(conn,user,'ARCHIVE','payment_due',due_id)
    return {'ok':True}
