"""Shared A4 print layout. Pure renderer: no database access."""
from io import BytesIO
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_RIGHT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, KeepTogether

INK=colors.HexColor('#183d53')
MUTED=colors.HexColor('#5b7180')
LINE=colors.HexColor('#d8e3e9')
PALE=colors.HexColor('#f2f6f8')


def render_document(title,headings,rows,notes=(),footer=(),company=None,extra_image=None,recipient=None,payment=(),logistics=()):
    company=company or {}
    stream=BytesIO();width=A4[0]-84
    normal=ParagraphStyle('normal',fontName='Helvetica',fontSize=9,leading=13,textColor=INK,spaceAfter=3)
    small=ParagraphStyle('small',parent=normal,fontSize=8,leading=11)
    head=ParagraphStyle('head',parent=normal,fontName='Helvetica-Bold',fontSize=22,leading=27,spaceAfter=8)
    brand=ParagraphStyle('brand',parent=normal,fontName='Helvetica-Bold',fontSize=15,leading=19)
    column=ParagraphStyle('column',parent=small,fontName='Helvetica-Bold',textColor=colors.white)
    numeric=ParagraphStyle('numeric',parent=small,alignment=TA_RIGHT)
    def p(value,style=normal):return Paragraph(escape(str(value if value is not None else '')).replace('\n','<br/>'),style)
    story=[]
    issuer=[p(company.get('name') or 'La tua azienda',brand)]
    for text in [' '.join(str(company.get(k) or '') for k in ('address','postal_code','city','province')),
                 'P. IVA '+str(company.get('vat_number') or ''),
                 ' | '.join(str(company.get(k) or '') for k in ('phone','email') if company.get(k))]:
        if text.strip():issuer.append(p(text,small))
    logo=''
    if company.get('logo_data'):
        try:logo=Image(BytesIO(bytes(company['logo_data'])),width=112,height=55,kind='proportional')
        except (ValueError,OSError):pass
    if logo:issuer.insert(0,logo)
    recipient=recipient or {}
    customer=[]
    if recipient:
        customer.append(p('DESTINATARIO',ParagraphStyle('recipient-label',parent=small,fontName='Helvetica-Bold',textColor=MUTED)))
        customer.append(p(recipient.get('name') or '',brand))
        for text in [' '.join(str(recipient.get(k) or '') for k in ('address','postal_code','city','province')),
                     ' · '.join(x for x in (('P. IVA '+str(recipient.get('vat_number') or '')).strip(),('C.F. '+str(recipient.get('tax_code') or '')).strip()) if x not in ('P. IVA','C.F.')),
                     ' · '.join(str(recipient.get(k) or '') for k in ('sdi_code','pec') if recipient.get(k))]:
            if text.strip():customer.append(p(text,small))
    right=customer
    banner=Table([[issuer,right]],colWidths=[width*.48,width*.52]);banner.setStyle(TableStyle([
        ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),0),
        ('LEFTPADDING',(1,0),(1,0),14),('BOX',(1,0),(1,0),.6,LINE),('BACKGROUND',(1,0),(1,0),colors.white),
        ('LINEBELOW',(0,0),(-1,-1),1.2,INK),('BOTTOMPADDING',(0,0),(-1,-1),12)]))
    story.extend([banner,Spacer(1,15),p(title,head)])
    if payment:
        payment_box=Table([[p('PAGAMENTO E DATI BANCARI',column)],[p(' · '.join(str(x) for x in payment if str(x or '').strip()),small)]],colWidths=[width])
        payment_box.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),INK),('BACKGROUND',(0,1),(-1,1),PALE),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
        story.extend([payment_box,Spacer(1,8)])
    # Full-width paragraphs allow long addresses, conditions and technical notes to flow.
    for note in notes:
        if str(note or '').strip():story.append(p(note))
    if extra_image:
        try:story.extend([Spacer(1,8),Image(BytesIO(extra_image),width=120,height=105,kind='proportional')])
        except (ValueError,OSError):pass
    story.append(Spacer(1,17))
    rows=list(rows)
    if headings and rows:
        weights=[]
        for h in headings:
            text=h.lower()
            weights.append(3.7 if any(k in text for k in ['descrizione','articolo','causale','lavori']) else 1.15 if any(k in text for k in ['codice','numero','data','importo','totale','prezzo','imponibile']) else 0.9)
        widths=[width*w/sum(weights) for w in weights]
        right=[i for i,h in enumerate(headings) if any(k in h.lower() for k in ['€','iva','qtà','quantità','peso','%'])]
        data=[[p(h,column) for h in headings]]
        for row in rows:
            data.append([p(value,numeric if i in right else small) for i,value in enumerate(row)])
        table=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT',splitByRow=1,splitInRow=1)
        table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),INK),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE]),
            ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
            ('TOPPADDING',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),9),
            ('LINEBELOW',(0,0),(-1,0),.5,INK),('LINEBELOW',(0,-1),(-1,-1),.5,LINE)]))
        story.append(table)
    else:story.append(p('Nessuna riga presente.',small))
    if footer:
        totalstyle=ParagraphStyle('total',parent=normal,fontName='Helvetica-Bold',fontSize=11,leading=16,textColor=colors.white,alignment=TA_RIGHT)
        for index,text in enumerate(footer):
            last=index==len(footer)-1
            box=Table([[p(text,totalstyle if last else normal)]],colWidths=[width]);box.setStyle(TableStyle([
                ('BACKGROUND',(0,0),(-1,-1),INK if last else PALE),('LEFTPADDING',(0,0),(-1,-1),13),
                ('RIGHTPADDING',(0,0),(-1,-1),13),('TOPPADDING',(0,0),(-1,-1),12),('BOTTOMPADDING',(0,0),(-1,-1),12)]))
            story.append(KeepTogether([Spacer(1,10),box]))
    if logistics:
        data=[]
        for label,value in logistics:
            if str(value or '').strip():data.append([p(label,ParagraphStyle('log-label',parent=small,fontName='Helvetica-Bold')),p(value,small)])
        if data:
            logistics_box=Table(data,colWidths=[width*.26,width*.74]);logistics_box.setStyle(TableStyle([('BACKGROUND',(0,0),(0,-1),PALE),('GRID',(0,0),(-1,-1),.35,LINE),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
            story.extend([Spacer(1,10),logistics_box])
    def page(canvas,doc):
        canvas.saveState();canvas.setStrokeColor(LINE);canvas.line(42,39,A4[0]-42,39)
        canvas.setFont('Helvetica',7.5);canvas.setFillColor(MUTED)
        canvas.drawString(42,26,str(company.get('name') or 'ERP Idraulici G&T')[:75])
        canvas.drawRightString(A4[0]-42,26,f'Pagina {doc.page}')
        if doc.page>1:
            canvas.setFont('Helvetica',8);canvas.drawString(42,A4[1]-28,title[:100]);canvas.line(42,A4[1]-34,A4[0]-42,A4[1]-34)
        canvas.restoreState()
    SimpleDocTemplate(stream,pagesize=A4,leftMargin=42,rightMargin=42,topMargin=47,bottomMargin=54,title=title,author=str(company.get('name') or '')).build(story,onFirstPage=page,onLaterPages=page)
    return stream.getvalue()

