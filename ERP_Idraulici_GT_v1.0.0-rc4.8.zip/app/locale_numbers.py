"""Parse canonical decimal strings and Italian grouped numeric input."""
from decimal import Decimal, ROUND_HALF_UP
import re


def normalized(value: str) -> str:
    text=value.strip()
    if ',' not in text:return text
    if not re.fullmatch(r'[+-]?(?:\d+|\d{1,3}(?:\.\d{3})+),\d+',text):
        raise ValueError('Formato numerico non valido')
    return text.replace('.','').replace(',','.')


def quantized_input(value: Decimal, places: int) -> Decimal:
    """Accept harmless binary-float tails, but still reject real excess precision."""
    step = Decimal(1).scaleb(-places)
    rounded = value.quantize(step, rounding=ROUND_HALF_UP)
    tolerance = step * Decimal('0.000001')
    if value != rounded and abs(value - rounded) > tolerance:
        raise ValueError('Troppe cifre decimali')
    return rounded
