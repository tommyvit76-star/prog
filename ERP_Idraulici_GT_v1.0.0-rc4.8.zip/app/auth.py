import hashlib
import hmac
import os
import secrets
from datetime import datetime, timedelta, timezone
from fastapi import Depends, Header, HTTPException, Request
from app.db import connect

ROLES = {'ADMIN', 'OFFICE', 'WAREHOUSE', 'TECHNICIAN'}


def hash_password(password: str, salt: bytes | None = None) -> str:
    if len(password) < 6:
        raise ValueError('La password deve contenere almeno 6 caratteri')
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 600_000)
    return 'pbkdf2_sha256$600000$' + salt.hex() + '$' + digest.hex()


def verify_password(password: str, encoded: str) -> bool:
    try:
        method, rounds, salt, digest = encoded.split('$')
        if method != 'pbkdf2_sha256' or int(rounds) != 600_000:
            return False
        result = hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt), int(rounds))
        return hmac.compare_digest(result, bytes.fromhex(digest))
    except (ValueError, TypeError):
        return False


def bootstrap():
    password = os.environ.get('ADMIN_PASSWORD')
    if not password:
        raise RuntimeError('Set ADMIN_PASSWORD in .env before starting')
    encoded = hash_password(password)
    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute('SELECT pg_advisory_xact_lock(783452)')
            cur.execute('SELECT 1 FROM users LIMIT 1')
            if not cur.fetchone():
                cur.execute('INSERT INTO users(username,password_hash,role) VALUES (%s,%s,%s)', ('admin', encoded, 'ADMIN'))


def login(username: str, password: str) -> str:
    with connect() as conn:
        row = conn.execute('SELECT id,password_hash FROM users WHERE username=%s AND active=true', (username,)).fetchone()
        if not row or not verify_password(password, row['password_hash']):
            raise HTTPException(401, 'Invalid credentials')
        token = secrets.token_urlsafe(32)
        conn.execute('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES (%s,%s,%s)',
                     (hashlib.sha256(token.encode()).hexdigest(), row['id'], datetime.now(timezone.utc) + timedelta(hours=12)))
        return token


MODULE_PATHS = {'/customers':'customers','/suppliers':'suppliers','/units':'units',
                '/pdf/ddt':'ddt','/pdf/sal':'sal','/pdf/invoices':'invoices',
                '/pdf/movements':'reports','/pdf/document-events':'reports','/pdf/payment-due':'payments',
                '/pdf/credit-notes':'credit-notes','/pdf/projects':'jobs',
                '/pdf/inventory':'balances','/pdf/products':'products',
                '/product-categories':'products',
                '/purchase-discounts':'suppliers',
                '/company-bank-accounts':'payments',
                '/products':'products','/warehouses':'warehouses','/balances':'balances',
                '/movements':'movements','/movement-report':'reports','/document-events':'reports',
                '/price-lists':'price-lists','/quotes':'quotes',
                '/payment-methods':'payment-methods','/payment-due':'payments',
                '/invoice-register':'invoices','/invoice-sources':'invoices',
                '/delivery-notes':'ddt','/progress-certificates':'sal','/credit-notes':'credit-notes','/projects':'jobs'}


def module_for(path):
    for prefix, module in MODULE_PATHS.items():
        if path == prefix or path.startswith(prefix + '/'):
            return module
    return None


def has_module(user, module, edit=False):
    if user['role'] == 'ADMIN':
        return True
    grants = user.get('permissions', {})
    if module=='payment-methods':
        return bool(grants.get('payments',{}).get('edit' if edit else 'view') or
                    (not edit and grants.get('quotes',{}).get('view')))
    own = grants.get(module, {})
    if own.get('edit' if edit else 'view'):
        return True
    if not edit and module in ('customers','suppliers','products','price-lists') and grants.get('quotes',{}).get('view'):
        return True
    if not edit and module=='payments' and grants.get('invoices',{}).get('view'):
        return True
    if not edit and module in ('invoices','customers') and grants.get('payments',{}).get('view'):
        return True
    if not edit and module=='customers' and grants.get('invoices',{}).get('view'):
        return True
    if not edit and module in ('products','warehouses','units','customers') and grants.get('ddt',{}).get('view'):
        return True
    if not edit and module in ('customers','quotes') and grants.get('sal',{}).get('view'):
        return True
    if not edit and module in ('customers','ddt','sal','payments') and grants.get('invoices',{}).get('view'):
        return True
    if not edit and module in ('products','balances','movements','warehouses','units') and grants.get('reports',{}).get('view'):
        return True
    if not edit and module in ('products','units','warehouses','balances') and grants.get('movements',{}).get('view'):
        return True
    return False


def current_user(request: Request, authorization: str | None = Header(default=None)) -> dict:
    if not authorization or not authorization.startswith('Bearer '):
        raise HTTPException(401, 'Login required')
    token = authorization[7:]
    with connect() as conn:
        row = conn.execute('SELECT u.id,u.username,u.role,u.selected_fiscal_year FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=%s AND s.expires_at > now() AND u.active=true',
                           (hashlib.sha256(token.encode()).hexdigest(),)).fetchone()
        if not row:
            raise HTTPException(401, 'Session expired')
        permissions = conn.execute('SELECT module,can_view,can_edit FROM user_modules WHERE user_id=%s', (row['id'],)).fetchall()
    user = dict(row)
    user['permissions'] = {p['module']:{'view':p['can_view'] or p['can_edit'],'edit':p['can_edit']} for p in permissions}
    module = module_for(request.url.path)
    if module and not has_module(user,module,request.method not in ('GET','HEAD')):
        raise HTTPException(403,'Modulo non autorizzato')
    return user


def allowed(*roles):
    def check(request: Request, user=Depends(current_user)):
        module = module_for(request.url.path)
        if module:
            if not has_module(user,module,request.method not in ('GET','HEAD')):
                raise HTTPException(403, 'Insufficient permissions')
        elif user['role'] not in roles:
            raise HTTPException(403, 'Insufficient permissions')
        return user
    return check
