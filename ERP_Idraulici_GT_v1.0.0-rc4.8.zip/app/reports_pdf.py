"""Downloadable, branded operational PDF documents."""
from io import BytesIO
from datetime import date
from xml.sax.saxutils import escape

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, KeepTogether

from app.auth import allowed
from app.db import connect
from app.movement_reports import query_movements
from app.payments import due_list
from app.workflow import delivery_detail
from app.quotes import details as quote_details
from app.document_events import query_document_events
from app.professional import credit_detail, project_detail

MOVEMENT_NAMES={'LOAD':'Carico','TRANSFER':'Trasferimento','CONSUME':'Scarico','RETURN':'Rientro',
                'SUPPLIER_RETURN':'Reso al fornitore','ADJUST':'Rettifica','REVERSAL':'Storno'}
STATUS_NAMES={'DRAFT':'Bozza','PLANNED':'Pianificato','OPEN':'Aperto','SENT':'Inviato','ISSUED':'Emesso',
              'PARTIAL':'Parziale','PENDING':'In attesa','CONFIRMED':'Confermato','APPROVED':'Approvato',
              'ACCEPTED':'Accettato','COMPLETED':'Completato','PAID':'Pagato','INVOICED':'Fatturato',
              'CLOSED':'Chiuso','ARCHIVED':'Archiviato','CANCELLED':'Annullato','REJECTED':'Rifiutato',
              'DISPUTED':'Contestato','SUSPENDED':'Sospeso','OVERDUE':'Scaduto'}


def status_name(value):
    return STATUS_NAMES.get(str(value or '').upper(),str(value or ''))


def italian_number(value,places=2):
    from decimal import Decimal
    amount=f'{Decimal(str(value)):,.{places}f}'
    return amount.replace(',','@').replace('.',',').replace('@','.')

router=APIRouter()


def item(value):
    return escape(str(value if value is not None else ''))


def titled(label, number):
    return str(number) if str(number).upper().startswith(label.upper()) else f'{label} {number}'


def pdf_response(title, headings, rows, notes=(), wide=False, extra_image=None, footer=(), company_override=None,recipient=None,payment=(),logistics=()):
    if company_override is not None:company=company_override
    else:
        with connect() as conn:
            company=conn.execute('SELECT name,vat_number,address,postal_code,city,province,phone,email,logo_data FROM company_settings WHERE id=1').fetchone()
    from app.pdf_layout import render_document
    payload=render_document(title,headings,rows,notes,footer,company,extra_image,recipient,payment,logistics)
    return Response(payload,media_type='application/pdf',headers={'Content-Disposition':f'attachment; filename="{title.split()[0].lower()}.pdf"'})



@router.get('/pdf/quotes/{quote_id}')
def quote_pdf(quote_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:quote=quote_details(conn,quote_id)
    party_label='Fornitore' if quote.get('party_type')=='SUPPLIER' else 'Cliente'
    notes=[f"{party_label}: {quote['customer_name']}",
           f"Indirizzo: {quote['customer_address']} {quote['customer_city']}",
           f"Data: {quote['issue_date']} · Validità: {quote['valid_days']} giorni",
           f"Intervento: {quote['intervention']}"]
    for label,key in [('Relazione tecnica','introduction'),('Esclusioni','exclusions'),('Condizioni di pagamento','payment_terms')]:
        if quote[key]:notes.append(f'{label}: {quote[key]}')
    totals=[f"Manodopera € {italian_number(quote.get('manual_labor_cost',0))} · Trasferta € {italian_number(quote['kilometer_total'])} · Imponibile € {italian_number(quote['subtotal'])}",
            f"IVA € {italian_number(quote['vat_total'])} · TOTALE € {italian_number(quote['total'])}"]
    recipient={'name':quote['customer_name'],'address':quote['customer_address'],'city':quote['customer_city']}
    return pdf_response(titled('Preventivo',quote['number'])+' · '+quote['title'],['Codice','Descrizione','Qtà','U.M.','Prezzo €','Totale €'],
        [(r['code'],r['description'],italian_number(r['quantity'],4),r['unit_code'],italian_number(r['display_unit_price'],3),italian_number(r['total'])) for r in quote['lines']],notes,wide=True,footer=totals,recipient=recipient,payment=(quote.get('payment_method_name') or quote.get('payment_terms') or 'Da concordare',))


@router.get('/pdf/ddt/{doc_id}')
def delivery_pdf(doc_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        doc=delivery_detail(conn,doc_id)
        customer=conn.execute('SELECT name,vat_number,tax_code,address,postal_code,city,province FROM customers WHERE id=%s',(doc['customer_id'],)).fetchone()
        quote_sources={r['line_id']:r for r in conn.execute('SELECT dl.id line_id,q.id quote_id,q.number,q.issue_date FROM delivery_lines dl JOIN quote_lines ql ON ql.id=dl.quote_line_id JOIN quotes q ON q.id=ql.quote_id WHERE dl.delivery_id=%s',(doc_id,)).fetchall()}
    snapshot=doc.get('transport_snapshot') or {}
    notes=[f"Data documento: {doc['issued_on']} · Data/ora trasporto: {doc.get('transport_date') or doc['issued_on']} {doc.get('transport_time') or ''}",
           f"Cliente: {doc['customer_name']} · P.IVA: {(customer or {}).get('vat_number') or '—'} · C.F.: {(customer or {}).get('tax_code') or '—'}",
           f"Sede cliente: {' '.join(str((customer or {}).get(k) or '') for k in ('address','postal_code','city','province')).strip() or '—'}",
           f"Destinazione merce: {doc['shipping_address'] or '—'}",
           f"Causale: {snapshot.get('reason_name') or doc.get('transport_reason_name') or '—'} · Aspetto beni: {snapshot.get('appearance_name') or doc.get('goods_appearance_name') or '—'}",
           f"Porto: {snapshot.get('port_name') or doc.get('port_term_name') or '—'} · Trasporto: {snapshot.get('mode_name') or doc.get('transport_mode_name') or '—'}",
           f"Colli: {doc.get('package_count',0)} · Peso lordo: {italian_number(doc.get('gross_weight',0),3)} {doc.get('weight_unit','kg')} · Peso netto: {italian_number(doc.get('net_weight',0),3)} {doc.get('weight_unit','kg')}"]
    if snapshot.get('carrier_name'):notes.append(f"Vettore: {snapshot['carrier_name']} · P.IVA {snapshot.get('carrier_vat','')} · {snapshot.get('carrier_address','')} {snapshot.get('carrier_postal','')} {snapshot.get('carrier_city','')} · Autista {snapshot.get('driver_name','')} · Targa {snapshot.get('vehicle_plate','')}")
    if doc.get('return_due_date'):notes.append(f"Rientro previsto: {doc['return_due_date']}")
    references=[]
    totals=doc.get('totals') or {}
    footer=[f"Materiali € {italian_number(totals.get('materials',0))} · Manodopera € {italian_number(totals.get('labor',0))} · Trasferta € {italian_number(totals.get('travel',0))} · Prestazione € {italian_number(totals.get('service',0))}",
            f"Sconti € {italian_number(totals.get('discounts',0))} · Imponibile € {italian_number(totals.get('taxable',0))} · IVA € {italian_number(totals.get('vat',0))} · TOTALE € {italian_number(totals.get('total',0))}",
            'Firma conducente ____________________   Firma vettore ____________________   Firma destinatario ____________________']
    rows=[];current_source=None
    if doc.get('project_code'):rows.append(('RIF',f"Riferimento a: cantiere {doc['project_code']} · {doc.get('project_name') or ''}",'','','','',''))
    for r in doc['lines']:
        source=quote_sources.get(r['id'])
        marker=source['quote_id'] if source else None
        if marker!=current_source:
            if source:rows.append(('RIF',f"Riferimento a: preventivo n. {source['number']} del {source['issue_date']}",'','','','',''))
            elif current_source is not None:rows.append(('RIF','Voci aggiuntive del DDT','','','','',''))
            current_source=marker
        rows.append((r['product_code'] or {'SERVICE':'MAN','TRAVEL':'KM','DISCOUNT':'SCONTO'}.get(r.get('kind'),''),r['description'],italian_number(r['quantity'],4),r['unit_code'],italian_number(r['unit_price'],3),italian_number(r['discount_percent'])+'%',italian_number(r['total'])))
    for code,label,key,sign in [('MAN','Manodopera globale','global_labor',1),('TRASF','Trasferta globale','global_travel',1),('PREST','Prestazione globale','global_service',1),('SCONTO','Sconto globale','global_discount',-1)]:
        if doc.get(key):rows.append((code,label,'1','NR',italian_number(doc[key]),'',italian_number(doc[key]*sign)))
    logistics=[('Causale',snapshot.get('reason_name') or doc.get('transport_reason_name') or '—'),('Aspetto beni',snapshot.get('appearance_name') or doc.get('goods_appearance_name') or '—'),('Porto',snapshot.get('port_name') or doc.get('port_term_name') or '—'),('Trasporto',snapshot.get('mode_name') or doc.get('transport_mode_name') or '—'),('Colli e pesi',f"{doc.get('package_count',0)} colli · lordo {italian_number(doc.get('gross_weight',0),3)} {doc.get('weight_unit','kg')} · netto {italian_number(doc.get('net_weight',0),3)} {doc.get('weight_unit','kg')}"),('Destinazione',doc['shipping_address'] or '—')]
    return pdf_response(titled('DDT',doc['number']),['Codice','Descrizione','Qtà','U.M.','Prezzo','Sconto','Totale'],rows,
        notes+references+[str(doc['notes'] or '')],footer=footer,recipient=dict(customer or {},name=doc['customer_name']),logistics=logistics)


@router.get('/pdf/sal/{sal_id}')
def sal_pdf(sal_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        row=conn.execute('SELECT * FROM progress_certificates WHERE id=%s AND active=true',(sal_id,)).fetchone()
    if not row:raise HTTPException(404,'SAL non trovato')
    with connect() as conn:
        previous=conn.execute('SELECT COALESCE(sum(percent),0) percent,COALESCE(sum(amount+variation_amount-retention_amount-advance_recovery),0) amount FROM progress_certificates WHERE project_id=%s AND active=true AND (sequence_no<%s OR sequence_no=%s AND id<%s)',(row['project_id'],row['sequence_no'],row['sequence_no'],row['id'])).fetchone() if row['project_id'] else {'percent':0,'amount':0}
        project=project_detail(conn,row['project_id']) if row['project_id'] else None
        sal_customer=conn.execute('SELECT name,vat_number,tax_code,address,postal_code,city,province,sdi_code,pec FROM customers WHERE id=%s',(row['customer_id'],)).fetchone()
    current=row['amount']+row['variation_amount']-row['retention_amount']-row['advance_recovery']
    notes=[f"Cliente: {row['customer_name']} · Data: {row['issued_on']} · Periodo: {row['period_from'] or '—'} / {row['period_to'] or '—'}",
           f"SAL n. {row['sequence_no']} · Stato: {status_name(row['approval_status'])} · Avanzamento precedente {italian_number(previous['percent'])}% · corrente {italian_number(row['percent'])}% · cumulato {italian_number(previous['percent']+row['percent'])}%"]
    if row.get('quote_id'):
        with connect() as conn:q=conn.execute('SELECT number,issue_date FROM quotes WHERE id=%s',(row['quote_id'],)).fetchone()
        if q:notes.append(f"Riferimento a: preventivo n. {q['number']} del {q['issue_date']}")
    if project:notes.append(f"Riferimento a: cantiere {project['code']} · {project['name']}")
    return pdf_response(titled('SAL',row['number']),['Lavori','Importo lavori','Varianti','Ritenuta','Recupero anticipo','Netto SAL','IVA'],
        [(row['description'],italian_number(row['amount']),italian_number(row['variation_amount']),italian_number(row['retention_amount']),italian_number(row['advance_recovery']),italian_number(current),str(row['vat_rate'])+'%')],
        notes+[str(row['notes'] or '')],wide=True,footer=[f"Importo precedente € {italian_number(previous['amount'])} · Cumulato € {italian_number(previous['amount']+current)}",'Firma committente ____________________   Direzione lavori ____________________   Impresa ____________________'],recipient=dict(sal_customer or {},name=row['customer_name']))


@router.get('/pdf/credit-notes/{note_id}')
def credit_note_pdf(note_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:note=credit_detail(conn,note_id)
    customer=note.get('customer_snapshot') or {}
    notes=[f"Cliente: {note['customer_name']} · P.IVA: {customer.get('vat_number') or '—'} · C.F.: {customer.get('tax_code') or '—'}",
           f"Sede: {' '.join(str(customer.get(k) or '') for k in ('address','postal_code','city','province')).strip() or '—'} · Data: {note['issue_date']} · Stato: {status_name(note['status'])}",
           f"Fattura originaria: {note['original_invoice_number']} del {note['original_invoice_date']}",f"Causale: {note['cause']}"]
    return pdf_response(titled('Nota di credito',note['number']),['Codice','Descrizione','Quantità','Prezzo €','Sconto','Imponibile €','IVA €'],
        [(r['code'],r['description'],italian_number(r['quantity'],4),italian_number(r['unit_price'],3),str(r['discount_percent'])+'%',italian_number(r['taxable']),italian_number(r['vat_amount'])) for r in note['lines']],notes,wide=True,
        footer=[f"Imponibile € {italian_number(note['taxable'])} · IVA € {italian_number(note['vat_amount'])} · TOTALE NOTA € {italian_number(note['total'])}"],
        company_override={**note['company_snapshot'],'logo_data':note['logo_snapshot']} if note['company_snapshot'] else None,recipient=dict(customer,name=note['customer_name']))


@router.get('/pdf/projects/{project_id}')
def project_pdf(project_id:int,user=Depends(allowed('ADMIN','OFFICE','TECHNICIAN'))):
    with connect() as conn:
        p=project_detail(conn,project_id)
        docs=conn.execute("SELECT 'DDT' kind,number,issued_on date,status FROM delivery_notes WHERE project_id=%s AND active=true UNION ALL SELECT 'SAL',number,issued_on,approval_status FROM progress_certificates WHERE project_id=%s AND active=true UNION ALL SELECT 'Fattura',number,issue_date,document_status FROM invoice_register WHERE project_id=%s AND active=true ORDER BY date",(project_id,project_id,project_id)).fetchall()
    notes=[f"Cliente: {p['customer_name']} · Indirizzo: {p['address']}",f"Stato: {status_name(p['status'])} · Responsabile: {p['manager']}",f"Valore contratto € {italian_number(p['contract_total'])} · SAL € {italian_number(p['sal_amount'])} · Fatturato € {italian_number(p['invoiced'])} · Residuo SAL € {italian_number(p['remaining_to_sal'])}"]
    return pdf_response('Cantiere '+p['code']+' · '+p['name'],['Tipo','Numero','Data','Stato'],[(r['kind'],r['number'],r['date'],status_name(r['status'])) for r in docs],notes,wide=True,recipient={'name':p['customer_name'],'address':p['address']})


@router.get('/pdf/invoices/{invoice_id}')
def invoice_pdf(invoice_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        invoice=conn.execute('SELECT i.*,m.name AS method_name FROM invoice_register i LEFT JOIN payment_methods m ON m.id=i.payment_method_id WHERE i.id=%s AND i.active=true',(invoice_id,)).fetchone()
        if not invoice:raise HTTPException(404,'Fattura non trovata')
        sources=conn.execute('SELECT s.*,d.number AS ddt_number,p.number AS sal_number FROM invoice_sources s LEFT JOIN delivery_notes d ON d.id=s.delivery_id LEFT JOIN progress_certificates p ON p.id=s.sal_id WHERE s.invoice_id=%s ORDER BY s.id',(invoice_id,)).fetchall()
        references=conn.execute('SELECT r.reference_type,r.include_amounts,r.quote_id,r.delivery_id,r.sal_id,r.project_id,q.number quote_number,q.issue_date quote_date,d.number ddt_number,d.issued_on ddt_date,s.number sal_number,s.issued_on sal_date,p.code project_code,p.name project_name '
          'FROM invoice_references r LEFT JOIN quotes q ON q.id=r.quote_id LEFT JOIN delivery_notes d ON d.id=r.delivery_id LEFT JOIN progress_certificates s ON s.id=r.sal_id LEFT JOIN project_sites p ON p.id=r.project_id WHERE r.invoice_id=%s ORDER BY r.id',(invoice_id,)).fetchall()
        lines=conn.execute('SELECT id,source_quote_id,kind,code,description,quantity,unit_code,unit_price,discount_percent,discount_amount,vat_rate,vat_nature,taxable,vat_amount FROM invoice_lines WHERE invoice_id=%s ORDER BY position,id',(invoice_id,)).fetchall()
        dues=conn.execute('SELECT due_date,amount,status FROM payment_due WHERE invoice_id=%s AND active=true ORDER BY due_date',(invoice_id,)).fetchall()
        customer=invoice['customer_snapshot'] or invoice['casual_customer']
        if customer is None and invoice['customer_id']:
            customer=conn.execute('SELECT name,vat_number,tax_code,address,postal_code,city,province,sdi_code,pec FROM customers WHERE id=%s',(invoice['customer_id'],)).fetchone()
        customer=dict(customer or {})
        customer.setdefault('name',invoice['customer_name'])
    state='Confermata' if invoice['document_status']=='CONFIRMED' else 'Bozza'
    notes=[f"Cliente: {invoice['customer_name']} · P.IVA: {customer.get('vat_number') or '—'} · C.F.: {customer.get('tax_code') or '—'}",
           f"Sede: {' '.join(str(customer.get(k) or '') for k in ('address','postal_code','city','province')).strip() or '—'} · Data: {invoice['issue_date']} · {state}",
           f"Codice SDI: {customer.get('sdi_code') or '—'} · PEC: {customer.get('pec') or '—'} · Modalità: {invoice['method_name'] or 'Non indicata'}"]
    if invoice['show_iban'] and invoice['bank_iban']:notes.append(f"IBAN aziendale: {invoice['bank_holder']} · {invoice['bank_name']} · {invoice['bank_iban']}")
    if invoice['payment_type']=='RIBA':notes.append(f"Ri.Ba. banca cliente: {invoice['customer_bank_name']} · {invoice['customer_iban']}")
    notes.extend(f"Scadenza: {due['due_date']} · € {italian_number(due['amount'])} · {status_name(due['status'])}" for due in dues)
    if invoice['document_status']=='DRAFT':notes.append('BOZZA GESTIONALE — Documento non confermato.')
    if invoice.get('notes'):notes.append('Note: '+invoice['notes'])
    def invoice_line(r):return (r['code'],r['description'],italian_number(r['quantity'],4)+' '+r['unit_code'],italian_number(r['unit_price'],4),italian_number(r['discount_percent'])+'% / '+italian_number(r['discount_amount']),italian_number(r['vat_rate'])+'%',italian_number(r['taxable']))
    rows=[];used_lines=set();used_sources=set()
    for ref in references:
        kind=ref['reference_type']
        if kind=='QUOTE':label=f"Riferimento a: preventivo n. {ref['quote_number']} del {ref['quote_date']}"
        elif kind=='DDT':label=f"Riferimento a: DDT n. {ref['ddt_number']} del {ref['ddt_date']}"
        elif kind=='SAL':label=f"Riferimento a: SAL n. {ref['sal_number']} del {ref['sal_date']}"
        else:label=f"Riferimento a: cantiere {ref['project_code']} · {ref['project_name']}"
        rows.append(('RIF',label,'','','','',''))
        if kind=='QUOTE':
            for line in lines:
                if line['source_quote_id']==ref['quote_id']:rows.append(invoice_line(line));used_lines.add(line['id'])
        elif kind in ('DDT','SAL'):
            key='delivery_id' if kind=='DDT' else 'sal_id'
            for source in sources:
                if source[key]==ref[key]:rows.append((kind+' '+(source['ddt_number'] if kind=='DDT' else source['sal_number']),'Importo richiamato','-','-','-','-',italian_number(source['taxable'])));used_sources.add(source['id'])
    manual=[line for line in lines if line['id'] not in used_lines]
    if manual:rows.append(('RIF','Voci aggiuntive della fattura','','','','',''));rows.extend(invoice_line(line) for line in manual)
    for source in sources:
        if source['id'] not in used_sources:rows.append((('DDT '+source['ddt_number']) if source['delivery_id'] else ('SAL '+source['sal_number']),'Importo richiamato','-','-','-','-',italian_number(source['taxable'])))
    payment=[invoice['method_name'] or 'Modalità non indicata']
    if invoice['show_iban'] and invoice['bank_iban']:payment.append(f"{invoice['bank_holder']} · {invoice['bank_name']} · {invoice['bank_iban']}")
    return pdf_response(titled('Fattura',invoice['number']),['Codice','Descrizione','Quantità','Prezzo €','Sconto % / €','IVA %','Importo €'],rows,notes,
        footer=[f"Imponibile € {italian_number(invoice['taxable'])} | IVA € {italian_number(invoice['vat_amount'])}",f"TOTALE DOCUMENTO € {italian_number(invoice['total'])}"],
        company_override={**invoice['company_snapshot'],'logo_data':invoice['logo_snapshot']} if invoice['company_snapshot'] else None,recipient=customer,payment=payment)



@router.get('/pdf/movements')
def movements_pdf(product_id:int|None=None,warehouse_id:int|None=None,source_id:int|None=None,destination_id:int|None=None,
                  supplier_id:int|None=None,kind:str|None=None,actor:str|None=None,reason:str|None=None,
                  date_from:str|None=None,date_to:str|None=None,user=Depends(allowed('ADMIN','OFFICE','WAREHOUSE'))):
    if date_from is None:date_from=f"{user['selected_fiscal_year']}-01-01"
    if date_to is None:date_to=f"{user['selected_fiscal_year']}-12-31"
    rows=query_movements(product_id=product_id,warehouse_id=warehouse_id,source_id=source_id,destination_id=destination_id,
        supplier_id=supplier_id,kind=kind,actor=actor,reason=reason,date_from=date_from,date_to=date_to,limit=10000)
    return pdf_response('Movimenti magazzino',['Data','Articolo','Tipo','Quantità','Da','A','Causale'],
        [(r['created_at'].strftime('%d/%m/%Y %H:%M'),r['product_code']+' · '+r['product_description'],MOVEMENT_NAMES.get(r['kind'],r['kind']),italian_number(r['quantity'],4)+' '+r['unit_code'],r['source_name'],r['destination_name'],r['reason']) for r in rows],
        [f"Periodo: {date_from or 'inizio'} / {date_to or 'oggi'}",f"Articolo ID: {product_id or 'tutti'} · Magazzino ID: {warehouse_id or 'tutti'} · Causale: {reason or 'tutte'}"],wide=True)


@router.get('/pdf/document-events')
def document_events_pdf(entity:str|None=None,action:str|None=None,actor:str|None=None,
                        date_from:date|None=None,date_to:date|None=None,
                        user=Depends(allowed('ADMIN','OFFICE','WAREHOUSE'))):
    rows=query_document_events(entity=entity,action=action,actor=actor,date_from=date_from,date_to=date_to,limit=10000)
    return pdf_response('Movimenti documentali',['Data','Documento','ID','Operazione','Utente','Dettagli'],
        [(r['created_at'].strftime('%d/%m/%Y %H:%M'),r['entity_label'],r['entity_id'],r['action_label'],r['username'] or 'Sistema',str(r['details'] or '')) for r in rows],
        [f"Periodo: {date_from or 'inizio'} / {date_to or 'oggi'} · Documento: {entity or 'tutti'} · Operazione: {action or 'tutte'}"],wide=True)


@router.get('/pdf/inventory')
def inventory_pdf(q:str='',category:str='',product_id:int|None=None,warehouse_id:int|None=None,
                  only_low:bool=False,user=Depends(allowed('ADMIN','OFFICE','WAREHOUSE'))):
    if len(q)>120 or len(category)>120:raise HTTPException(400,'Ricerca troppo lunga')
    where=['p.active=true'];args=[]
    if q:
        where.append('(p.code ILIKE %s OR p.description ILIKE %s)');args.extend(['%'+q+'%','%'+q+'%'])
    if category:where.append('lower(p.category)=lower(%s)');args.append(category)
    if product_id:where.append('p.id=%s');args.append(product_id)
    if warehouse_id:where.append('w.id=%s');args.append(warehouse_id)
    if only_low:where.append('COALESCE((SELECT sum(b2.quantity) FROM balances b2 WHERE b2.product_id=p.id),0)<p.min_stock')
    with connect() as conn:
        rows=conn.execute('SELECT p.code,p.description,w.name AS warehouse,COALESCE(b.quantity,0) AS quantity,u.code AS unit,p.min_stock '
                          'FROM products p LEFT JOIN balances b ON b.product_id=p.id '
                          'LEFT JOIN warehouses w ON w.id=b.warehouse_id JOIN units u ON u.id=p.unit_id '
                          'WHERE '+' AND '.join(where)+' ORDER BY w.name,p.description,p.code LIMIT 10001',tuple(args)).fetchall()
    if len(rows)>10000:raise HTTPException(413,'Riduci la ricerca: oltre 10.000 righe')
    return pdf_response('Giacenze filtrate',['Codice','Articolo','Magazzino','Quantità','Unità','Scorta minima'],
        [(r['code'],r['description'],r['warehouse'] or 'Non assegnato',italian_number(r['quantity'],4),r['unit'],italian_number(r['min_stock'],4)) for r in rows],
        [f'Categoria: {category or "tutte"} · Ricerca: {q or "tutte"} · Righe: {len(rows)}'],wide=True)


@router.get('/pdf/products/{product_id}')
def product_pdf(product_id:int,include_price:bool=False,user=Depends(allowed('ADMIN','OFFICE','WAREHOUSE'))):
    with connect() as conn:
        p=conn.execute('SELECT p.*,u.code AS unit,s.name AS supplier FROM products p JOIN units u ON u.id=p.unit_id '
                       'LEFT JOIN suppliers s ON s.id=p.supplier_id WHERE p.id=%s AND p.active=true',(product_id,)).fetchone()
        if not p:raise HTTPException(404,'Articolo non trovato')
        balances=conn.execute('SELECT w.name,b.quantity FROM balances b JOIN warehouses w ON w.id=b.warehouse_id '
                              'WHERE b.product_id=%s ORDER BY w.name',(product_id,)).fetchall()
        photo=conn.execute('SELECT data FROM product_photos WHERE product_id=%s',(product_id,)).fetchone()
    details=[f"Codice: {p['code']} · Categoria: {p['category'] or '—'} · Unità: {p['unit']}",
             f"Fornitore: {p['supplier'] or '—'} · Codice fornitore: {p['supplier_code'] or '—'}",
             f"Marca: {p['brand'] or '—'} · Ubicazione: {p['location'] or '—'}"]
    if include_price:details.append('Prezzo listino: € '+italian_number(p['list_price'],3))
    if p['notes']:details.append('Note: '+p['notes'])
    return pdf_response('Articolo '+p['code']+' · '+p['description'],['Magazzino','Giacenza','Unità','Scorta minima'],
        [(b['name'],italian_number(b['quantity'],4),p['unit'],italian_number(p['min_stock'],4)) for b in balances],
        details,extra_image=bytes(photo['data']) if photo else None)


@router.get('/pdf/payment-due')
def due_pdf(invoice_id:int|None=None,customer_id:int|None=None,status:str|None=None,due_from:date|None=None,due_to:date|None=None,
            overdue:bool=False,user=Depends(allowed('ADMIN','OFFICE'))):
    rows=due_list(invoice_id=invoice_id,customer_id=customer_id,status=status,due_from=due_from,due_to=due_to,overdue=overdue,user=user)
    from decimal import Decimal
    total=sum((Decimal(r['amount']) for r in rows),Decimal('0'))
    return pdf_response('Scadenziario fatture',['Cliente','Fattura','Scadenza','Importo','Stato','Modalità'],
        [(r['customer_name'],r['invoice_number'],r['due_date'],r['amount'],status_name(r['status']),r['payment_method_name']) for r in rows],
        [f"Filtri: stato {status_name(status) if status else 'tutti'} · da {due_from or 'inizio'} a {due_to or 'oggi'} · cliente {customer_id or 'tutti'}",
         f'Totale righe: {len(rows)} · Importo € {total:.2f}'],wide=True)
