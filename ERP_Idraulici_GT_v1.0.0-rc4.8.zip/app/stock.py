from decimal import Decimal
from psycopg.errors import CheckViolation, ForeignKeyViolation
from app.domain import quantity


def move(conn, *, product_id: int, source_id: int | None, destination_id: int | None,
         amount: str, kind: str, actor: str, reason: str, supplier_id: int | None = None,
         reverses_id: int | None = None) -> dict:
    qty = quantity(amount)
    if (source_id is None and destination_id is None) or source_id == destination_id:
        raise ValueError('Seleziona un magazzino; per un trasferimento scegli origine e destinazione diverse')
    if kind not in {'LOAD', 'TRANSFER', 'CONSUME', 'RETURN', 'ADJUST', 'REVERSAL', 'SUPPLIER_RETURN'}:
        raise ValueError('unknown movement kind')
    if kind == 'SUPPLIER_RETURN':
        if source_id is None or destination_id is not None or supplier_id is None:
            raise ValueError('Per il reso scegli il magazzino di partenza e il fornitore')
    elif supplier_id is not None:
        raise ValueError('Il fornitore si indica solo per un reso al fornitore')
    if kind == 'REVERSAL' and reverses_id is None:
        raise ValueError('Per annullare un movimento usa il comando di rettifica')
    if kind == 'LOAD' and source_id is not None:
        raise ValueError('Per un carico scegli solo il magazzino di destinazione')
    if kind == 'CONSUME' and destination_id is not None:
        raise ValueError('Per uno scarico scegli solo il magazzino di partenza')
    if kind in ('TRANSFER', 'RETURN') and (source_id is None or destination_id is None):
        raise ValueError('Trasferimento e rientro richiedono magazzino di partenza e destinazione')
    if not actor.strip() or not reason.strip():
        raise ValueError('Indica utente e causale del movimento')
    with conn.transaction():
        with conn.cursor() as cur:
            cur.execute('SELECT id FROM products WHERE id=%s AND active=true', (product_id,))
            if not cur.fetchone():
                raise ValueError('active product not found')
            if supplier_id is not None:
                cur.execute('SELECT id FROM suppliers WHERE id=%s AND active=true', (supplier_id,))
                if not cur.fetchone():
                    raise ValueError('active supplier not found')
            ids = sorted({i for i in (source_id, destination_id) if i is not None})
            for wid in ids:
                cur.execute('INSERT INTO balances(product_id, warehouse_id) VALUES (%s,%s) ON CONFLICT DO NOTHING', (product_id, wid))
            cur.execute('SELECT warehouse_id,quantity FROM balances WHERE product_id=%s AND warehouse_id = ANY(%s) ORDER BY warehouse_id FOR UPDATE', (product_id, ids))
            balances = {r['warehouse_id']: r['quantity'] for r in cur.fetchall()}
            if source_id is not None and balances[source_id] < qty:
                raise ValueError('insufficient stock')
            if source_id is not None:
                cur.execute('UPDATE balances SET quantity=quantity-%s WHERE product_id=%s AND warehouse_id=%s', (qty, product_id, source_id))
            if destination_id is not None:
                cur.execute('UPDATE balances SET quantity=quantity+%s WHERE product_id=%s AND warehouse_id=%s', (qty, product_id, destination_id))
            cur.execute('INSERT INTO movements(product_id,source_id,destination_id,quantity,kind,actor,reason,supplier_id,reverses_id) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id,created_at',
                        (product_id, source_id, destination_id, qty, kind, actor, reason, supplier_id, reverses_id))
            row = cur.fetchone()
            return {'id': row['id'], 'created_at': row['created_at'], 'quantity': str(qty)}


def automatic_warehouse(conn, product_id: int | None = None) -> int:
    """Choose a configured warehouse without asking for it inside a document."""
    row = None
    if product_id:
        row = conn.execute('SELECT w.id FROM products p JOIN warehouses w ON w.id=p.default_warehouse_id AND w.active=true WHERE p.id=%s AND p.active=true', (product_id,)).fetchone()
    if not row:
        row = conn.execute('SELECT id FROM warehouses WHERE active=true ORDER BY id LIMIT 1').fetchone()
    if not row:
        raise ValueError('Configura almeno un magazzino attivo nelle anagrafiche')
    return row['id']


def consume_any(conn, *, product_id: int, amount: str, actor: str, reason: str) -> list[dict]:
    """Consume stock across all active warehouses, preferring the product default."""
    qty = quantity(amount)
    rows = conn.execute(
        'SELECT b.warehouse_id,b.quantity FROM balances b JOIN warehouses w ON w.id=b.warehouse_id AND w.active=true '
        'JOIN products p ON p.id=b.product_id WHERE b.product_id=%s AND b.quantity>0 '
        'ORDER BY (b.warehouse_id=p.default_warehouse_id) DESC,b.quantity DESC,b.warehouse_id FOR UPDATE',
        (product_id,),
    ).fetchall()
    available = sum((row['quantity'] for row in rows), Decimal('0'))
    if available < qty:
        raise ValueError(f'Giacenza complessiva insufficiente: disponibile {available}, richiesta {qty}')
    remaining = qty
    movements = []
    for row in rows:
        used = min(remaining, row['quantity'])
        if used > 0:
            movements.append(move(conn, product_id=product_id, source_id=row['warehouse_id'], destination_id=None,
                                  amount=str(used), kind='CONSUME', actor=actor, reason=reason))
            remaining -= used
        if remaining == 0:
            break
    return movements


def reverse(conn, movement_id: int, actor: str, reason: str) -> dict:
    if not reason.strip():
        raise ValueError('reason required')
    with conn.transaction():
        with conn.cursor() as cur:
            cur.execute('SELECT * FROM movements WHERE id=%s FOR UPDATE', (movement_id,))
            previous = cur.fetchone()
            if not previous:
                raise ValueError('movement not found')
            if previous['reverses_id'] is not None:
                raise ValueError('cannot reverse a reversal')
            cur.execute('SELECT id FROM movements WHERE reverses_id=%s', (movement_id,))
            if cur.fetchone():
                raise ValueError('movement already reversed')
        return move(conn, product_id=previous['product_id'], source_id=previous['destination_id'],
                    destination_id=previous['source_id'], amount=str(previous['quantity']),
                    kind='REVERSAL', actor=actor, reason=reason, reverses_id=movement_id)
