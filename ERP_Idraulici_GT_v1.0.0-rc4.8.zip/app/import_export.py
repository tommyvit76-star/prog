"""CSV catalog transfer: preview all rows, then import in one transaction."""
import csv
import base64
import binascii
from io import BytesIO
from io import StringIO
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel

from app.auth import allowed
from app.catalog import number, audit
from app.db import connect
from app.domain import quantity
from app.stock import move

router=APIRouter()
HEADERS=('codice','descrizione','unita','categoria','prezzo_acquisto','prezzo_listino',
         'iva','scorta_minima','magazzino_iniziale','quantita_iniziale')


@router.get('/products/import-template.csv')
def import_template(user=Depends(allowed('ADMIN','OFFICE'))):
    return Response('\ufeff'+';'.join(HEADERS)+'\n',media_type='text/csv; charset=utf-8',
        headers={'Content-Disposition':'attachment; filename="tracciato_articoli.csv"'})


class CsvIn(BaseModel):
    csv_text:str


class WorkbookIn(BaseModel):
    xlsx_base64:str


def workbook_csv(encoded):
    try:
        data=base64.b64decode(encoded,validate=True)
        if len(data)>1_000_000:raise HTTPException(413,'File troppo grande (massimo 1 MB)')
        from openpyxl import load_workbook
        workbook=load_workbook(BytesIO(data),read_only=True,data_only=True)
        try:
            sheet=workbook.active
            iterator=sheet.iter_rows(values_only=True)
            headers=next(iterator,None)
            if not headers:raise HTTPException(400,'Foglio Excel vuoto')
            names=[str(value or '').strip().lower() for value in headers]
            if len(set(names))!=len(names):raise HTTPException(400,'Intestazioni Excel duplicate')
            if not {'codice','descrizione','unita'}.issubset(names):
                raise HTTPException(400,'Intestazioni richieste: codice, descrizione, unita')
            if sheet.max_row>2001:raise HTTPException(413,'Massimo 2000 articoli')
            out=StringIO();writer=csv.writer(out,delimiter=';');writer.writerow(names)
            for row in iterator:
                writer.writerow(['' if value is None else str(value) for value in row[:len(names)]])
            return out.getvalue()
        finally:workbook.close()
    except (ValueError,binascii.Error,TypeError):raise HTTPException(400,'File Excel non valido')
    except HTTPException:raise
    except Exception as exc:
        raise HTTPException(400,'Non riesco a leggere il file .xlsx; verifica il formato e il foglio attivo') from exc


def parse_csv(text):
    if len(text.encode('utf-8'))>1_000_000:raise HTTPException(413,'File troppo grande (massimo 1 MB)')
    text=text.lstrip('\ufeff')
    try:
        delimiter=csv.Sniffer().sniff(text[:2048],delimiters=';,').delimiter
    except csv.Error:
        delimiter=';'
    reader=csv.DictReader(StringIO(text),delimiter=delimiter)
    if not reader.fieldnames or not {'codice','descrizione','unita'}.issubset(reader.fieldnames):
        raise HTTPException(400,'Intestazioni richieste: codice;descrizione;unita')
    records=list(reader)
    if len(records)>2000:raise HTTPException(413,'Massimo 2000 righe per importazione')
    return records


def checked_records(conn,text):
    rows=parse_csv(text)
    units={r['code'].upper():r['id'] for r in conn.execute('SELECT id,code FROM units').fetchall()}
    categories={r['name'].casefold():r['name'] for r in conn.execute('SELECT name FROM product_categories WHERE active=true').fetchall()}
    warehouses={r['code'].upper():r['id'] for r in conn.execute('SELECT id,code FROM warehouses WHERE active=true').fetchall()}
    products={r['code'].upper() for r in conn.execute('SELECT code FROM products').fetchall()}
    checked=[];seen={};errors=[]
    for index,row in enumerate(rows,2):
        try:
            code=(row.get('codice') or '').strip().upper();description=(row.get('descrizione') or '').strip()
            unit=(row.get('unita') or '').strip().upper();category=(row.get('categoria') or '').strip()
            warehouse=(row.get('magazzino_iniziale') or '').strip().upper();stock=(row.get('quantita_iniziale') or '').strip()
            if not code or len(code)>64 or not description or unit not in units:raise ValueError('Codice, descrizione o unità non validi')
            if code in products:raise ValueError('Articolo già presente: importazione di articoli nuovi soltanto')
            if category and category.casefold() not in categories:raise ValueError('Categoria non presente: '+category)
            values={key:number(row.get(field) or default,2 if key=='vat_rate' else 4,Decimal('100') if key=='vat_rate' else Decimal('99999999999.9999'))
                for key,field,default in [('purchase_price','prezzo_acquisto','0'),('list_price','prezzo_listino','0'),
                                           ('vat_rate','iva','22'),('min_stock','scorta_minima','0')]}
            if stock:
                if warehouse not in warehouses:raise ValueError('Magazzino iniziale non valido')
                qty=quantity(stock)
            else:
                if warehouse:raise ValueError('Indica una quantità per il magazzino iniziale')
                qty=None
            signature=(description,unit,category.casefold(),*values.values())
            if code in seen and seen[code]!=signature:raise ValueError('Dati articolo diversi nelle righe con lo stesso codice')
            seen[code]=signature
            checked.append(dict(code=code,description=description,unit_id=units[unit],
                category=categories.get(category.casefold(),''),warehouse_id=warehouses.get(warehouse),quantity=qty,**values))
        except (ValueError,HTTPException) as exc:
            errors.append(f'Riga {index}: {getattr(exc,"detail",str(exc))}')
    if len(errors)>20:errors=errors[:20]+['Altri errori presenti.']
    return checked,errors


@router.get('/products/export.csv')
def export_catalog(user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        rows=conn.execute('SELECT p.code,p.description,u.code AS unit_code,p.category,p.purchase_price,p.list_price,p.vat_rate,p.min_stock,w.code AS warehouse_code,b.quantity '
                          'FROM products p JOIN units u ON u.id=p.unit_id LEFT JOIN balances b ON b.product_id=p.id AND b.quantity>0 '
                          'LEFT JOIN warehouses w ON w.id=b.warehouse_id WHERE p.active=true ORDER BY p.code,w.code LIMIT 100001').fetchall()
    if len(rows)>100000:raise HTTPException(413,'Catalogo troppo grande per una sola esportazione')
    out=StringIO();writer=csv.writer(out,delimiter=';');writer.writerow(HEADERS)
    for r in rows:writer.writerow([r['code'],r['description'],r['unit_code'],r['category'],r['purchase_price'],r['list_price'],
                                    r['vat_rate'],r['min_stock'],r['warehouse_code'] or '',r['quantity'] if r['warehouse_code'] else ''])
    return Response('\ufeff'+out.getvalue(),media_type='text/csv; charset=utf-8',
                    headers={'Content-Disposition':'attachment; filename="articoli.csv"'})


@router.post('/products/import-preview')
def preview_catalog(data:CsvIn,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        rows,errors=checked_records(conn,data.csv_text)
    return {'rows':len(rows),'articles':len({r['code'] for r in rows}),'movements':sum(r['quantity'] is not None for r in rows),'errors':errors}


@router.post('/products/import-xlsx-preview')
def preview_workbook(data:WorkbookIn,user=Depends(allowed('ADMIN','OFFICE'))):
    return preview_catalog(CsvIn(csv_text=workbook_csv(data.xlsx_base64)),user)


@router.post('/products/import-xlsx')
def import_workbook(data:WorkbookIn,user=Depends(allowed('ADMIN','OFFICE'))):
    return import_catalog(CsvIn(csv_text=workbook_csv(data.xlsx_base64)),user)


@router.post('/products/import')
def import_catalog(data:CsvIn,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        rows,errors=checked_records(conn,data.csv_text)
        if errors:raise HTTPException(400,'; '.join(errors))
        inserted={}
        for row in rows:
            if row['code'] not in inserted:
                created=conn.execute('INSERT INTO products(code,description,unit_id,category,purchase_price,list_price,vat_rate,min_stock) '
                    'VALUES (%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id',
                    (row['code'],row['description'],row['unit_id'],row['category'],row['purchase_price'],
                     row['list_price'],row['vat_rate'],row['min_stock'])).fetchone()
                inserted[row['code']]=created['id'];audit(conn,user,'CREATE','products',created['id'],{'source':'CSV'})
            if row['quantity'] is not None:
                move(conn,product_id=inserted[row['code']],source_id=None,destination_id=row['warehouse_id'],
                     amount=str(row['quantity']),kind='LOAD',actor=user['username'],reason='Carico iniziale da importazione CSV')
        return {'articles':len(inserted),'movements':sum(r['quantity'] is not None for r in rows)}
