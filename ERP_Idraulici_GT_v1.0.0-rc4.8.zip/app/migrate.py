from pathlib import Path
from app.db import connect


def migrate():
    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute('CREATE TABLE IF NOT EXISTS schema_migrations (version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())')
            cur.execute('SELECT pg_advisory_xact_lock(783451)')
            for path in sorted((Path(__file__).resolve().parent.parent / 'migrations').glob('*.sql')):
                cur.execute('SELECT 1 FROM schema_migrations WHERE version = %s', (path.stem,))
                if not cur.fetchone():
                    cur.execute(path.read_text())
                    cur.execute('INSERT INTO schema_migrations(version) VALUES (%s)', (path.stem,))


if __name__ == '__main__':
    migrate()
