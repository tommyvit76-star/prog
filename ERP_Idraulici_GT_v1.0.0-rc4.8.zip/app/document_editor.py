"""One request and one transaction for the complete document editor."""
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from app.auth import allowed
from app.db import atomic_document
from app.fiscal_years import assert_open
from app import billing, payments, quotes, workflow, professional
from app.catalog import audit

router = APIRouter()


class InvoiceRow(billing.LineIn):
    id: int | None = None


class InvoiceReference(BaseModel):
    kind: str
    source_id: int
    include_amounts: bool = False
    amount: str | None = None


class InvoiceDocument(BaseModel):
    id: int | None = None
    header: payments.InvoiceIn
    lines: list[InvoiceRow] = Field(default_factory=list, max_length=300)
    references: list[InvoiceReference] = Field(default_factory=list,max_length=100)


def reference_record(conn,invoice_id,reference):
    kind=reference.kind
    if kind not in ('QUOTE','DDT','SAL','PROJECT'):raise HTTPException(400,'Tipo di riferimento non valido')
    invoice=conn.execute('SELECT customer_id FROM invoice_register WHERE id=%s',(invoice_id,)).fetchone()
    mapping={'QUOTE':('quotes','quote_id'),'DDT':('delivery_notes','delivery_id'),
             'SAL':('progress_certificates','sal_id'),'PROJECT':('project_sites','project_id')}
    table,column=mapping[kind]
    source=conn.execute(f'SELECT customer_id FROM {table} WHERE id=%s AND active=true FOR UPDATE',(reference.source_id,)).fetchone()
    if not source:raise HTTPException(404,f'{kind}: documento non trovato')
    if not source['customer_id'] or source['customer_id']!=invoice['customer_id']:
        raise HTTPException(409,f'{kind}: cliente diverso dalla fattura')
    if kind=='QUOTE' and conn.execute('SELECT 1 FROM project_quote_links l JOIN project_sites p ON p.id=l.project_id AND p.active=true WHERE l.quote_id=%s',(reference.source_id,)).fetchone():
        raise HTTPException(409,'Il preventivo appartiene a un cantiere: fattura il cantiere oppure dissocialo')
    if kind=='QUOTE' and quotes.linked_invoice_for_quote(conn,reference.source_id,invoice_id):
        raise HTTPException(409,'Il preventivo è già stato fatturato in un altro documento')
    if kind in ('DDT','SAL'):
        project_id=conn.execute(f'SELECT project_id FROM {table} WHERE id=%s',(reference.source_id,)).fetchone()['project_id']
        if project_id and not conn.execute('SELECT 1 FROM invoice_references WHERE invoice_id=%s AND project_id=%s',(invoice_id,project_id)).fetchone():
            raise HTTPException(409,f'{kind} associato a un cantiere: aggiungi prima il riferimento al cantiere')
    conn.execute(f'INSERT INTO invoice_references(invoice_id,reference_type,{column},include_amounts) VALUES (%s,%s,%s,%s)',
                 (invoice_id,kind,reference.source_id,reference.include_amounts))


def check_ids(rows, existing):
    ids = [row.id for row in rows if row.id is not None]
    if len(ids) != len(set(ids)) or not set(ids) <= existing:
        raise HTTPException(400, 'Le righe non appartengono al documento o sono duplicate')
    return set(ids)


@router.post('/invoice-register/full/save')
def save_invoice_document(data: InvoiceDocument, user=Depends(allowed('ADMIN','OFFICE'))):
    with atomic_document() as conn:
        if data.id:
            billing.editable(conn, data.id)
        # Calculated totals and source relationships cannot be supplied as header edits.
        header = payments.InvoiceIn(**data.header.model_dump(exclude={'taxable','vat_amount','total','quote_id','project_id'}))
        header.quote_id=None;header.project_id=None
        result = payments.save_invoice(header, user, data.id)
        doc_id = result['id']
        # Rebuild generated relationships in this same transaction. Manual rows keep their identity.
        conn.execute('DELETE FROM invoice_lines WHERE invoice_id=%s AND source_quote_id IS NOT NULL',(doc_id,))
        conn.execute('DELETE FROM invoice_sources WHERE invoice_id=%s',(doc_id,))
        conn.execute('DELETE FROM invoice_references WHERE invoice_id=%s',(doc_id,))
        existing = {r['id'] for r in conn.execute('SELECT id FROM invoice_lines WHERE invoice_id=%s AND source_quote_id IS NULL FOR UPDATE',(doc_id,)).fetchall()}
        kept = check_ids(data.lines, existing)
        for line_id in existing-kept:
            removed=conn.execute('DELETE FROM invoice_lines WHERE id=%s AND invoice_id=%s AND movement_id IS NULL RETURNING id',(line_id,doc_id)).fetchone()
            if not removed: raise HTTPException(409,'Riga già movimentata: documento non modificabile')
            audit(conn,user,'DELETE','invoice_lines',line_id)
        for row in data.lines:
            billing.save_line(doc_id,billing.LineIn(**row.model_dump(exclude={'id'})),user,row.id,refresh_totals=False)
        seen=set()
        for reference in data.references:
            marker=(reference.kind,reference.source_id)
            if marker in seen:raise HTTPException(400,'Lo stesso documento è stato collegato due volte')
            seen.add(marker);reference_record(conn,doc_id,reference)
            if not reference.include_amounts:continue
            if reference.kind=='QUOTE':billing.import_quote(doc_id,reference.source_id,user,multiple=True)
            elif reference.kind in ('DDT','SAL'):
                workflow.link_source(doc_id,workflow.SourceIn(kind=reference.kind,source_id=reference.source_id,amount=reference.amount),user)
            else:raise HTTPException(400,'Il cantiere può essere aggiunto come riferimento, senza duplicarne il valore')
        total = billing.refresh(conn,doc_id)
        return {'id':doc_id,'total':str(total)}


@router.get('/invoice-register/{invoice_id}/references')
def invoice_references(invoice_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with atomic_document() as conn:
        rows=conn.execute('SELECT r.id,r.reference_type,r.include_amounts,r.quote_id,r.delivery_id,r.sal_id,r.project_id,'
          'q.number quote_number,q.issue_date quote_date,d.number delivery_number,d.issued_on delivery_date,'
          's.number sal_number,s.issued_on sal_date,p.code project_code,p.name project_name,src.taxable source_amount '
          'FROM invoice_references r LEFT JOIN quotes q ON q.id=r.quote_id LEFT JOIN delivery_notes d ON d.id=r.delivery_id '
          'LEFT JOIN progress_certificates s ON s.id=r.sal_id LEFT JOIN project_sites p ON p.id=r.project_id '
          'LEFT JOIN invoice_sources src ON src.invoice_id=r.invoice_id AND src.sal_id=r.sal_id '
          'WHERE r.invoice_id=%s ORDER BY r.id',(invoice_id,)).fetchall()
        result=[]
        for row in rows:
            kind=row['reference_type'];source_id=row[{'QUOTE':'quote_id','DDT':'delivery_id','SAL':'sal_id','PROJECT':'project_id'}[kind]]
            number=row.get({'QUOTE':'quote_number','DDT':'delivery_number','SAL':'sal_number','PROJECT':'project_code'}[kind])
            issued=row.get({'QUOTE':'quote_date','DDT':'delivery_date','SAL':'sal_date','PROJECT':'project_name'}[kind])
            result.append({'id':row['id'],'kind':kind,'source_id':source_id,'include_amounts':row['include_amounts'],
                           'number':number,'issued_on':issued.isoformat() if hasattr(issued,'isoformat') else issued,
                           'amount':str(row['source_amount']) if kind=='SAL' and row['source_amount'] is not None else None})
        return result


@router.get('/invoice-reference-candidates')
def invoice_reference_candidates(customer_id:int,invoice_id:int|None=None,user=Depends(allowed('ADMIN','OFFICE'))):
    with atomic_document() as conn:
        quotes_rows=conn.execute("SELECT q.id,q.number,q.issue_date,q.title,true AS can_include FROM quotes q WHERE q.active=true AND q.party_type='CUSTOMER' AND q.customer_id=%s AND q.status<>'REJECTED' AND NOT EXISTS(SELECT 1 FROM project_quote_links l JOIN project_sites p ON p.id=l.project_id AND p.active=true WHERE l.quote_id=q.id) AND NOT EXISTS(SELECT 1 FROM delivery_notes d WHERE d.quote_id=q.id AND d.active=true) AND NOT EXISTS(SELECT 1 FROM invoice_references r JOIN invoice_register i ON i.id=r.invoice_id AND i.active=true WHERE r.quote_id=q.id AND r.invoice_id<>%s) AND NOT EXISTS(SELECT 1 FROM invoice_register i WHERE i.active=true AND i.quote_id=q.id AND i.id<>%s) AND NOT EXISTS(SELECT 1 FROM invoice_lines l JOIN invoice_register i ON i.id=l.invoice_id AND i.active=true WHERE l.source_quote_id=q.id AND l.invoice_id<>%s) ORDER BY q.issue_date DESC,q.id DESC",(customer_id,invoice_id or 0,invoice_id or 0,invoice_id or 0)).fetchall()
        ddt=conn.execute("SELECT d.id,d.number,d.issued_on FROM delivery_notes d JOIN transport_reasons r ON r.id=d.transport_reason_id WHERE d.active=true AND d.customer_id=%s AND d.status='CONFIRMED' AND d.project_id IS NULL AND d.billing_destination='DIRECT_INVOICE' AND r.invoiceable=true AND NOT EXISTS(SELECT 1 FROM invoice_sources s WHERE s.delivery_id=d.id AND s.invoice_id<>%s) ORDER BY d.issued_on DESC,d.id DESC",(customer_id,invoice_id or 0)).fetchall()
        sal=conn.execute("SELECT s.id,s.number,s.issued_on,(s.amount+s.variation_amount-s.retention_amount-s.advance_recovery-COALESCE((SELECT sum(x.taxable) FROM invoice_sources x WHERE x.sal_id=s.id AND x.invoice_id<>%s),0)) amount,s.vat_rate,s.approval_status FROM progress_certificates s WHERE s.active=true AND s.customer_id=%s AND s.project_id IS NULL AND s.approval_status='APPROVED' AND (s.amount+s.variation_amount-s.retention_amount-s.advance_recovery)>COALESCE((SELECT sum(x.taxable) FROM invoice_sources x WHERE x.sal_id=s.id AND x.invoice_id<>%s),0) ORDER BY s.issued_on DESC,s.id DESC",(invoice_id or 0,customer_id,invoice_id or 0)).fetchall()
        projects=conn.execute("SELECT id,code,name,quote_id FROM project_sites WHERE active=true AND customer_id=%s ORDER BY id DESC",(customer_id,)).fetchall()
        quote_values=[]
        for row in quotes_rows:
            value=dict(row);detail=quotes.details(conn,row['id'])
            descriptions=[f"{line['code']} · {line['description']} · {line['quantity']} {line['unit_code']}" for line in detail['lines']]
            if Decimal(str(detail.get('manual_labor_cost') or 0))>0: descriptions.append(f"Manodopera · € {detail['manual_labor_cost']}")
            if Decimal(str(detail.get('kilometer_total') or 0))>0: descriptions.append(f"Trasferta · € {detail['kilometer_total']}")
            value.update(taxable=detail['subtotal'] if row['can_include'] else '0',vat=detail['vat_total'] if row['can_include'] else '0',details=descriptions);quote_values.append(value)
        ddt_values=[]
        for row in ddt:
            value=dict(row);detail=workflow.delivery_detail(conn,row['id']);taxable,vat=workflow.delivery_amount(conn,row['id'])
            descriptions=[f"{line['product_code']} · {line['description']} · {line['quantity']} {line['unit_code']}" for line in detail['lines']]
            for label,key in [('Manodopera','global_labor'),('Trasferta','global_travel'),('Prestazione','global_service'),('Sconto','global_discount')]:
                if Decimal(str(detail.get(key) or 0))>0: descriptions.append(f"{label} · € {detail[key]}")
            value.update(taxable=str(taxable),vat=str(vat),details=descriptions);ddt_values.append(value)
        sal_values=[]
        for row in sal:
            value=dict(row);value.update(taxable=str(row['amount']),vat=str(quotes.money(row['amount']*row['vat_rate']/100)),details=[f"Avanzamento lavori · € {row['amount']}"]);sal_values.append(value)
        project_values=[]
        for project in projects:
            value=dict(project);children=[]
            project_ddt=conn.execute("SELECT d.id,d.number,d.issued_on FROM delivery_notes d JOIN transport_reasons r ON r.id=d.transport_reason_id WHERE d.project_id=%s AND d.active=true AND d.status='CONFIRMED' AND d.billing_destination='DIRECT_INVOICE' AND r.invoiceable=true AND NOT EXISTS(SELECT 1 FROM invoice_sources x WHERE x.delivery_id=d.id AND x.invoice_id<>%s) ORDER BY d.issued_on,d.id",(project['id'],invoice_id or 0)).fetchall()
            for row in project_ddt:
                detail=workflow.delivery_detail(conn,row['id']);taxable,vat=workflow.delivery_amount(conn,row['id']);descriptions=[f"{line['product_code']} · {line['description']} · {line['quantity']} {line['unit_code']}" for line in detail['lines']]
                for label,key in [('Manodopera','global_labor'),('Trasferta','global_travel'),('Prestazione','global_service'),('Sconto','global_discount')]:
                    if Decimal(str(detail.get(key) or 0))>0: descriptions.append(f"{label} · € {detail[key]}")
                children.append({**dict(row),'kind':'DDT','taxable':str(taxable),'vat':str(vat),'details':descriptions})
            project_sal=conn.execute("SELECT s.id,s.number,s.issued_on,(s.amount+s.variation_amount-s.retention_amount-s.advance_recovery-COALESCE((SELECT sum(x.taxable) FROM invoice_sources x WHERE x.sal_id=s.id AND x.invoice_id<>%s),0)) amount,s.vat_rate FROM progress_certificates s WHERE s.project_id=%s AND s.active=true AND s.approval_status='APPROVED' AND (s.amount+s.variation_amount-s.retention_amount-s.advance_recovery)>COALESCE((SELECT sum(x.taxable) FROM invoice_sources x WHERE x.sal_id=s.id AND x.invoice_id<>%s),0) ORDER BY s.sequence_no,s.id",(invoice_id or 0,project['id'],invoice_id or 0)).fetchall()
            for row in project_sal:children.append({**dict(row),'kind':'SAL','taxable':str(row['amount']),'vat':str(quotes.money(row['amount']*row['vat_rate']/100)),'details':[f"Avanzamento lavori · € {row['amount']}"]})
            value['children']=children;project_values.append(value)
        return {'QUOTE':quote_values,'DDT':ddt_values,'SAL':sal_values,'PROJECT':project_values}


class QuoteRow(quotes.LineIn):
    id: int | None = None


class QuoteDocument(BaseModel):
    id: int | None = None
    header: quotes.QuoteIn
    lines: list[QuoteRow] = Field(default_factory=list,max_length=300)


@router.post('/quotes/full/save')
def save_quote_document(data: QuoteDocument,user=Depends(allowed('ADMIN','OFFICE'))):
    with atomic_document() as conn:
        if data.id:
            old=conn.execute('SELECT issue_date FROM quotes WHERE id=%s AND active=true FOR UPDATE',(data.id,)).fetchone()
            if not old: raise HTTPException(404,'Preventivo non trovato')
            assert_open(conn,old['issue_date'])
            if conn.execute('SELECT 1 FROM invoice_register WHERE quote_id=%s AND active=true UNION ALL SELECT 1 FROM project_sites WHERE quote_id=%s AND active=true UNION ALL SELECT 1 FROM project_quote_links l JOIN project_sites p ON p.id=l.project_id WHERE l.quote_id=%s AND p.active=true',(data.id,data.id,data.id)).fetchone():
                raise HTTPException(409,'Preventivo collegato: dissocia prima il documento di destinazione')
        result=quotes.save_quote(data.header,user,data.id)
        doc_id=result['id']
        existing={r['id'] for r in conn.execute('SELECT id FROM quote_lines WHERE quote_id=%s FOR UPDATE',(doc_id,)).fetchall()}
        kept=check_ids(data.lines,existing)
        for line_id in existing-kept: quotes.delete_line(doc_id,line_id,user)
        for row in data.lines: quotes.save_line(doc_id,quotes.LineIn(**row.model_dump(exclude={'id'})),user,row.id)
        return quotes.details(conn,doc_id)


class CreditSelection(professional.CreditLineEdit):
    index: int = Field(ge=0)


class CreditDocument(BaseModel):
    id: int | None = None
    header: professional.CreditCreate
    lines: list[CreditSelection] = Field(min_length=1,max_length=300)


@router.post('/credit-notes/full/preview')
def preview_credit(data: professional.CreditCreate,user=Depends(allowed('ADMIN','OFFICE'))):
    # Reuse source validation and preparation without persisting a draft or reserving a number.
    with atomic_document() as conn:
        with conn.transaction(force_rollback=True):
            result=professional.credit_create(data,user)
            return {'lines':result['lines']}


@router.post('/credit-notes/full/save')
def save_credit_document(data: CreditDocument,user=Depends(allowed('ADMIN','OFFICE'))):
    if not data.header.cause.strip(): raise HTTPException(400,'Indica il motivo della nota di credito')
    with atomic_document() as conn:
        if data.id:
            note=conn.execute('SELECT * FROM credit_notes WHERE id=%s AND active=true FOR UPDATE',(data.id,)).fetchone()
            if not note or note['status']!='DRAFT': raise HTTPException(409,'Nota non modificabile')
            assert_open(conn,note['issue_date']); assert_open(conn,data.header.issue_date)
            if note['original_invoice_id']!=data.header.original_invoice_id: raise HTTPException(409,'La fattura originale non può cambiare')
            if data.header.number != note['number']: raise HTTPException(409,'Il numero della nota già salvata non può cambiare qui')
            conn.execute('UPDATE credit_notes SET issue_date=%s,fiscal_year=%s,cause=%s,notes=%s WHERE id=%s',
                         (data.header.issue_date,data.header.issue_date.year,data.header.cause,data.header.notes,data.id))
            result=professional.credit_detail(conn,data.id)
        else:
            result=professional.credit_create(data.header,user)
        doc_id=result['id']; rows=result['lines']
        indices=[line.index for line in data.lines]
        if len(indices)!=len(set(indices)) or any(i>=len(rows) for i in indices): raise HTTPException(400,'Selezione righe non valida')
        for i,row in enumerate(rows):
            if i not in indices: professional.credit_line_delete(doc_id,row['id'],user)
        for line in data.lines:
            professional.credit_line(doc_id,rows[line.index]['id'],professional.CreditLineEdit(**line.model_dump(exclude={'index'})),user)
        return professional.credit_detail(conn,doc_id)
