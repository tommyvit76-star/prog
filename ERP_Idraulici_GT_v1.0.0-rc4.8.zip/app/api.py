from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.responses import FileResponse
from pydantic import BaseModel
from app.db import connect
from app.stock import move, reverse
from app.auth import current_user, allowed, login
import hashlib
import json
from pathlib import Path
from app.catalog import router as catalog_router, product_payload, product_rows, number
from app.banking import clean_iban
from app.quotes import router as quotes_router
from app.admin import router as admin_router
from app.payments import router as payments_router
from app.workflow import router as workflow_router
from app.reports_pdf import router as pdf_router
from app.import_export import router as import_router
from app.backups import router as backup_router, maintenance, start_scheduler
from app.billing import router as billing_router
from app.fiscal_xml import router as fiscal_xml_router
from app.document_events import router as document_events_router
from app.professional import router as professional_router
from app.fiscal_years import router as fiscal_years_router
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
from decimal import Decimal
from app.movement_reports import query_movements
from datetime import date

@asynccontextmanager
async def lifespan(app):
    start_scheduler()
    yield


app = FastAPI(title='ERP Idraulici G&T — v1.0.0-rc4.8', lifespan=lifespan)


@app.middleware('http')
async def pause_during_restore(request, call_next):
    if maintenance.is_set():
        return JSONResponse({'detail': 'Ripristino database in corso; riprova tra poco'}, status_code=503)
    return await call_next(request)



class UnitIn(BaseModel):
    code: str
    description: str


class ProductIn(BaseModel):
    code: str
    description: str
    unit_id: int
    supplier_id: int | None = None
    purchase_profile_id: int | None = None
    supplier_code: str = ''
    barcode: str = ''
    category: str = ''
    brand: str = ''
    location: str = ''
    notes: str = ''
    purchase_price: str = '0'
    list_price: str = '0'
    vat_rate: str = '22'
    min_stock: str = '0'
    default_warehouse_id: int | None = None
    kind: str = 'SIMPLE'


class WarehouseIn(BaseModel):
    code: str
    name: str
    kind: str


class MoveIn(BaseModel):
    product_id: int
    source_id: int | None = None
    destination_id: int | None = None
    amount: str
    kind: str
    actor: str
    reason: str
    supplier_id: int | None = None


class ReverseIn(BaseModel):
    actor: str
    reason: str


class LoginIn(BaseModel):
    username: str
    password: str


class ContactIn(BaseModel):
    code: str = ''
    name: str
    person_type: str = 'COMPANY'
    address: str = ''
    postal_code: str = ''
    city: str = ''
    province: str = ''
    tax_code: str = ''
    vat_number: str = ''
    sdi_code: str = ''
    pec: str = ''
    phone: str = ''
    mobile: str = ''
    email: str = ''
    contact_name: str = ''
    notes: str = ''
    iban: str = ''
    bank_name: str = ''
    price_list_id: int | None = None
    payment_method_id: int | None = None
    discount_mode: str = 'SIMPLE'
    discount_percent: str = '0'
    discount_1: str = '0'
    discount_2: str = '0'
    discount_3: str = '0'


class SupplierIn(BaseModel):
    name: str
    vat_number: str = ''
    address: str = ''
    phone: str = ''
    email: str = ''
    contact_name: str = ''
    notes: str = ''
    iban: str = ''
    bank_name: str = ''
    discount_1: str = '0'
    discount_2: str = '0'
    discount_3: str = '0'


@app.get('/')
def home():
    return FileResponse(Path(__file__).resolve().parent.parent / 'web' / 'index.html')


@app.get('/documents.js')
def documents_script():
    return FileResponse(Path(__file__).resolve().parent.parent / 'web' / 'documents.js', media_type='application/javascript')


@app.get('/documents.css')
def documents_style():
    return FileResponse(Path(__file__).resolve().parent.parent / 'web' / 'documents.css', media_type='text/css')


@app.get('/app.js')
def app_script():
    return FileResponse(Path(__file__).resolve().parent.parent / 'web' / 'app.js', media_type='application/javascript')


@app.get('/format.js')
def format_script():
    return FileResponse(Path(__file__).resolve().parent.parent / 'web' / 'format.js', media_type='application/javascript')


@app.get('/quotes.js')
def quotes_script():
    return FileResponse(Path(__file__).resolve().parent.parent / 'web' / 'quotes.js', media_type='application/javascript')


@app.get('/reports.js')
def reports_script():
    return FileResponse(Path(__file__).resolve().parent.parent / 'web' / 'reports.js', media_type='application/javascript')


@app.get('/billing.js')
def billing_script():
    return FileResponse(Path(__file__).resolve().parent.parent / 'web' / 'billing.js', media_type='application/javascript')


@app.get('/purchase.js')
def purchase_script():
    return FileResponse(Path(__file__).resolve().parent.parent / 'web' / 'purchase.js', media_type='application/javascript')


@app.get('/professional.js')
def professional_script():
    return FileResponse(Path(__file__).resolve().parent.parent / 'web' / 'professional.js', media_type='application/javascript')


@app.get('/admin.js')
def admin_script():
    return FileResponse(Path(__file__).resolve().parent.parent / 'web' / 'admin.js', media_type='application/javascript')


@app.get('/payments.js')
def payments_script():
    return FileResponse(Path(__file__).resolve().parent.parent / 'web' / 'payments.js', media_type='application/javascript')


@app.get('/workflow.js')
def workflow_script():
    return FileResponse(Path(__file__).resolve().parent.parent / 'web' / 'workflow.js', media_type='application/javascript')


@app.get('/gt-logo.svg')
def gt_logo():
    return FileResponse(Path(__file__).resolve().parent.parent / 'web' / 'gt-logo.svg', media_type='image/svg+xml')


@app.post('/auth/login')
def sign_in(data: LoginIn):
    return {'token': login(data.username, data.password)}


@app.get('/auth/me')
def whoami(user=Depends(current_user)):
    return user


@app.post('/auth/logout')
def sign_out(authorization: str | None = Header(default=None), user=Depends(current_user)):
    with connect() as conn:
        conn.execute('DELETE FROM sessions WHERE token_hash=%s', (hashlib.sha256(authorization[7:].encode()).hexdigest(),))
    return {'ok': True}


@app.get('/health')
def health():
    with connect() as conn:
        conn.execute('SELECT 1')
    return {'status': 'ok'}


def insert(sql, args):
    try:
        with connect() as conn:
            return conn.execute(sql, args).fetchone()
    except Exception as exc:
        raise HTTPException(400, str(exc)) from exc


@app.post('/units', status_code=201)
def add_unit(data: UnitIn, user=Depends(allowed('ADMIN', 'OFFICE', 'WAREHOUSE'))):
    return insert('INSERT INTO units(code,description) VALUES (%s,%s) RETURNING id,code,description', (data.code, data.description))


@app.get('/units')
def units(user=Depends(current_user)):
    with connect() as conn:
        return conn.execute('SELECT * FROM units ORDER BY code').fetchall()


BUILTIN_UNITS = frozenset({'PZ', 'MT', 'KG', 'LT', 'MQ', 'MC', 'CF', 'ROT'})


@app.delete('/units/{unit_id}')
def delete_unit(unit_id: int, user=Depends(allowed('ADMIN'))):
    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute('SELECT code FROM units WHERE id=%s FOR UPDATE', (unit_id,))
            row = cur.fetchone()
            if row is None:
                raise HTTPException(404, 'Unità non trovata')
            if row['code'] in BUILTIN_UNITS:
                raise HTTPException(409, 'Le unità predefinite non possono essere eliminate')
            cur.execute('SELECT 1 FROM products WHERE unit_id=%s LIMIT 1', (unit_id,))
            if cur.fetchone():
                raise HTTPException(409, 'Unità già usata da un articolo: modifica prima l’articolo')
            cur.execute('DELETE FROM units WHERE id=%s', (unit_id,))
            cur.execute('INSERT INTO audit_events(user_id,action,entity,entity_id,details) VALUES (%s,%s,%s,%s,%s)',
                        (user['id'], 'DELETE', 'units', unit_id, json.dumps({'code': row['code']})))
    return {'ok': True}


@app.post('/products', status_code=201)
def add_product(data: ProductIn, user=Depends(allowed('ADMIN', 'OFFICE'))):
    return product_payload(data, None, user)


@app.get('/products')
def products(user=Depends(current_user)):
    return product_rows(user)


@app.post('/warehouses', status_code=201)
def add_warehouse(data: WarehouseIn, user=Depends(allowed('ADMIN', 'WAREHOUSE'))):
    return insert('INSERT INTO warehouses(code,name,kind) VALUES (%s,%s,%s) RETURNING id,code,name,kind', (data.code, data.name, data.kind))


@app.get('/warehouses')
def warehouses(user=Depends(current_user)):
    with connect() as conn:
        return conn.execute('SELECT * FROM warehouses WHERE active=true ORDER BY code').fetchall()


@app.post('/movements', status_code=201)
def add_movement(data: MoveIn, user=Depends(allowed('ADMIN', 'WAREHOUSE'))):
    try:
        with connect() as conn:
            return move(conn, **{**data.model_dump(), 'actor': user['username']})
    except Exception as exc:
        raise HTTPException(400, str(exc)) from exc


@app.post('/movements/{movement_id}/reverse', status_code=201)
def reverse_movement(movement_id: int, data: ReverseIn, user=Depends(allowed('ADMIN', 'WAREHOUSE'))):
    try:
        with connect() as conn:
            return reverse(conn, movement_id, user['username'], data.reason)
    except Exception as exc:
        raise HTTPException(400, str(exc)) from exc


@app.get('/movements')
def movements(product_id: int | None = None, warehouse_id: int | None = None,
              source_id: int | None = None, destination_id: int | None = None,
              supplier_id: int | None = None,
              kind: str | None = None, actor: str | None = None, reason: str | None = None,
              date_from: date | None = None, date_to: date | None = None,
              user=Depends(current_user)):
    if date_from is None:
        date_from=date(user['selected_fiscal_year'],1,1)
    if date_to is None:
        date_to=date(user['selected_fiscal_year'],12,31)
    return query_movements(product_id=product_id, warehouse_id=warehouse_id,source_id=source_id,
                           supplier_id=supplier_id,
                           destination_id=destination_id,kind=kind,actor=actor,reason=reason,
                           date_from=date_from,date_to=date_to,limit=500)


@app.get('/movement-report')
def movement_report(product_id: int | None = None, warehouse_id: int | None = None,
                    source_id: int | None = None, destination_id: int | None = None,
                    supplier_id: int | None = None,
                    kind: str | None = None, actor: str | None = None, reason: str | None = None,
                    date_from: date | None = None, date_to: date | None = None,
                    user=Depends(allowed('ADMIN','OFFICE','WAREHOUSE'))):
    if date_from is None:
        date_from=date(user['selected_fiscal_year'],1,1)
    if date_to is None:
        date_to=date(user['selected_fiscal_year'],12,31)
    return query_movements(product_id=product_id,warehouse_id=warehouse_id,source_id=source_id,
                           supplier_id=supplier_id,
                           destination_id=destination_id,kind=kind,actor=actor,reason=reason,
                           date_from=date_from,date_to=date_to,limit=10000)


@app.get('/balances')
def balances(user=Depends(current_user)):
    with connect() as conn:
        rows = conn.execute('SELECT * FROM balances ORDER BY product_id,warehouse_id').fetchall()
    return [{**r, 'quantity': str(r['quantity'])} for r in rows]


def contact_create(table, data, user):
    values = data.model_dump()
    values['iban'] = clean_iban(values['iban'])
    if table == 'suppliers':
        for key in ('discount_1','discount_2','discount_3'):
            values[key] = number(values[key], 2, Decimal('100'))
    if table == 'customers':
        values['code'] = values['code'].strip().upper()
        if values['discount_mode'] not in ('SIMPLE','SEQUENTIAL'):
            raise HTTPException(400,'Tipo sconto cliente non valido')
        for key in ('discount_percent','discount_1','discount_2','discount_3'):
            values[key] = number(values[key], 2, Decimal('100'))
        if values['price_list_id'] is None:
            with connect() as conn:
                values['price_list_id'] = conn.execute("SELECT id FROM price_lists WHERE code='BASE'").fetchone()['id']
    if not values['name'].strip():
        raise HTTPException(400, 'Name required')
    cols = list(values)
    params = ','.join(['%s'] * len(cols))
    try:
        with connect() as conn:
            if table == 'customers':
                conn.execute('SELECT pg_advisory_xact_lock(783470)')
                if values['payment_method_id'] is not None and not conn.execute('SELECT 1 FROM payment_methods WHERE id=%s AND active=true',(values['payment_method_id'],)).fetchone():
                    raise HTTPException(400,'Modalità di pagamento predefinita non valida')
                if not values['code']:
                    last=conn.execute("SELECT COALESCE(max(substring(code from '[0-9]+$')::integer),0) AS n FROM customers WHERE code ~* '^CLI-[0-9]+$'").fetchone()['n']
                    values['code']=f'CLI-{last+1:06d}'
                if conn.execute('SELECT 1 FROM customers WHERE lower(trim(code))=lower(trim(%s))',(values['code'],)).fetchone():
                    raise HTTPException(409,'Codice cliente già presente')
            cols = list(values)
            params = ','.join(['%s'] * len(cols))
            row = conn.execute(f'INSERT INTO {table} ({",".join(cols)}) VALUES ({params}) RETURNING *', tuple(values.values())).fetchone()
            conn.execute('INSERT INTO audit_events(user_id,action,entity,entity_id) VALUES (%s,%s,%s,%s)', (user['id'], 'CREATE', table, row['id']))
            return row
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, str(exc)) from exc


def contact_update(table, record_id, data, user):
    values = data.model_dump()
    values['iban'] = clean_iban(values['iban'])
    if table == 'suppliers':
        for key in ('discount_1','discount_2','discount_3'):
            values[key] = number(values[key], 2, Decimal('100'))
    if table == 'customers':
        values['code'] = values['code'].strip().upper()
        if values['discount_mode'] not in ('SIMPLE','SEQUENTIAL'):
            raise HTTPException(400,'Tipo sconto cliente non valido')
        for key in ('discount_percent','discount_1','discount_2','discount_3'):
            values[key] = number(values[key], 2, Decimal('100'))
        with connect() as conn:
            existing = conn.execute('SELECT price_list_id FROM customers WHERE id=%s', (record_id,)).fetchone()
            if not existing:
                raise HTTPException(404, 'Record not found')
            if values['price_list_id'] is None: values['price_list_id'] = existing['price_list_id']
            if not values['code']:
                values['code']=conn.execute('SELECT code FROM customers WHERE id=%s',(record_id,)).fetchone()['code']
    if not values['name'].strip():
        raise HTTPException(400, 'Name required')
    cols = list(values)
    assignments = ','.join(f'{col}=%s' for col in cols)
    with connect() as conn:
        if table == 'customers' and values['payment_method_id'] is not None and not conn.execute('SELECT 1 FROM payment_methods WHERE id=%s AND active=true',(values['payment_method_id'],)).fetchone():
            raise HTTPException(400,'Modalità di pagamento predefinita non valida')
        if table == 'customers' and conn.execute('SELECT 1 FROM customers WHERE id<>%s AND lower(trim(code))=lower(trim(%s))',(record_id,values['code'])).fetchone():
            raise HTTPException(409,'Codice cliente già presente')
        row = conn.execute(f'UPDATE {table} SET {assignments} WHERE id=%s AND active=true RETURNING *', (*values.values(), record_id)).fetchone()
        if not row:
            raise HTTPException(404, 'Record not found')
        conn.execute('INSERT INTO audit_events(user_id,action,entity,entity_id) VALUES (%s,%s,%s,%s)', (user['id'], 'UPDATE', table, record_id))
        return row


def contact_archive(table, record_id, user):
    with connect() as conn:
        row = conn.execute(f'UPDATE {table} SET active=false WHERE id=%s AND active=true RETURNING id', (record_id,)).fetchone()
        if not row:
            raise HTTPException(404, 'Record not found')
        conn.execute('INSERT INTO audit_events(user_id,action,entity,entity_id) VALUES (%s,%s,%s,%s)', (user['id'], 'ARCHIVE', table, record_id))
    return {'ok': True}


@app.get('/customers')
def customers(user=Depends(allowed('ADMIN', 'OFFICE'))):
    with connect() as conn:
        return conn.execute('SELECT * FROM customers WHERE active=true ORDER BY name LIMIT 500').fetchall()


@app.post('/customers', status_code=201)
def add_customer(data: ContactIn, user=Depends(allowed('ADMIN', 'OFFICE'))):
    return contact_create('customers', data, user)


@app.put('/customers/{record_id}')
def edit_customer(record_id: int, data: ContactIn, user=Depends(allowed('ADMIN', 'OFFICE'))):
    return contact_update('customers', record_id, data, user)


@app.delete('/customers/{record_id}')
def archive_customer(record_id: int, user=Depends(allowed('ADMIN', 'OFFICE'))):
    return contact_archive('customers', record_id, user)


@app.get('/suppliers')
def suppliers(user=Depends(allowed('ADMIN', 'OFFICE'))):
    with connect() as conn:
        return conn.execute('SELECT * FROM suppliers WHERE active=true ORDER BY name LIMIT 500').fetchall()


@app.post('/suppliers', status_code=201)
def add_supplier(data: SupplierIn, user=Depends(allowed('ADMIN', 'OFFICE'))):
    return contact_create('suppliers', data, user)


@app.put('/suppliers/{record_id}')
def edit_supplier(record_id: int, data: SupplierIn, user=Depends(allowed('ADMIN', 'OFFICE'))):
    return contact_update('suppliers', record_id, data, user)


@app.delete('/suppliers/{record_id}')
def archive_supplier(record_id: int, user=Depends(allowed('ADMIN', 'OFFICE'))):
    return contact_archive('suppliers', record_id, user)


from app.document_editor import router as document_editor_router
app.include_router(document_editor_router)
app.include_router(catalog_router)
app.include_router(quotes_router)
app.include_router(admin_router)
app.include_router(payments_router)
app.include_router(workflow_router)
app.include_router(pdf_router)
app.include_router(import_router)
app.include_router(backup_router)
app.include_router(billing_router)
app.include_router(fiscal_xml_router)
app.include_router(document_events_router)
app.include_router(professional_router)
app.include_router(fiscal_years_router)



