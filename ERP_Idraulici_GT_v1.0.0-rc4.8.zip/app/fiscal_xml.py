"""Conservative FatturaPA ordinary-format XML preview; official XSD test required externally."""
import re
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_UP
from xml.etree import ElementTree as ET

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response

from app.auth import allowed
from app.db import connect
from app.billing import invoice_totals
from app.quotes import money
from app.workflow import delivery_line_total

router=APIRouter()
NS='http://ivaservizi.agenziaentrate.gov.it/docs/xsd/fatture/v1.2'
ET.register_namespace('p',NS)


def tag(parent,name,value=None):
    node=ET.SubElement(parent,f'{{{NS}}}{name}')
    if value is not None:node.text=str(value)
    return node


def money_text(value):return f'{Decimal(str(value)).quantize(Decimal("0.01"),rounding=ROUND_HALF_UP):.2f}'


def validate_parties(company,customer):
    issues=[]
    for name,label in [(company['name'],'Ragione sociale azienda'),(company['address'],'Indirizzo azienda'),
                       (company['city'],'Comune azienda'),(customer['name'],'Nome cliente'),
                       (customer['address'],'Indirizzo cliente'),(customer['city'],'Comune cliente')]:
        if not str(name or '').strip():issues.append(label)
    for row,label in [(company,'azienda'),(customer,'cliente')]:
        if not re.fullmatch(r'\d{5}',row['postal_code'] or ''):issues.append('CAP '+label+' (5 cifre)')
        if not re.fullmatch(r'[A-Z]{2}',row['province'] or ''):issues.append('Provincia '+label+' (2 lettere)')
    if not re.fullmatch(r'\d{11}',company['vat_number'] or ''):issues.append('Partita IVA azienda (11 cifre)')
    if not re.fullmatch(r'RF\d{2}',company['fiscal_regime'] or ''):issues.append('Regime fiscale azienda (RFxx)')
    if not re.fullmatch(r'\d{11}',customer['vat_number'] or ''):issues.append('Partita IVA cliente (11 cifre)')
    if customer['sdi_code'] and not re.fullmatch(r'[A-Z0-9]{7}',customer['sdi_code'].upper()):issues.append('Codice destinatario (7 caratteri)')
    if len(customer['name'] or '')>80 or len(company['name'] or '')>80:issues.append('Ragione sociale (massimo 80 caratteri)')
    if issues:raise HTTPException(422,'XML non generato: completa i campi: '+', '.join(issues))


def create_xml(invoice,company,customer,lines,sources,ddts,sals,dues):
    if invoice['document_status']!='CONFIRMED':raise HTTPException(409,'Conferma prima la fattura')
    if invoice['customer_id'] is not None and invoice['customer_id']!=customer['id']:raise HTTPException(409,'Cliente fattura incoerente')
    validate_parties(company,customer)
    if not lines and not sources:raise HTTPException(422,'XML non generato: mancano le righe')
    if len(str(invoice['id']))>8:raise HTTPException(422,'Numero invio troppo lungo')
    if invoice['fiscal_document_type']=='TD24' and (not ddts or lines or sals):
        raise HTTPException(422,'TD24 disponibile soltanto per la fattura differita di DDT; separa le altre righe')
    if not dues or sum((d['amount'] for d in dues),Decimal('0'))!=invoice['total']:
        raise HTTPException(422,'Le scadenze attive devono coincidere con il totale fattura')
    root=ET.Element(f'{{{NS}}}FatturaElettronica',{'versione':'FPR12'})
    header=tag(root,'FatturaElettronicaHeader');transmission=tag(header,'DatiTrasmissione')
    sender=tag(transmission,'IdTrasmittente');tag(sender,'IdPaese','IT');tag(sender,'IdCodice',company['vat_number'])
    progress=f'{invoice["id"]:05d}'
    tag(transmission,'ProgressivoInvio',progress)
    tag(transmission,'FormatoTrasmissione','FPR12')
    code=(customer['sdi_code'] or '0000000').upper();tag(transmission,'CodiceDestinatario',code)
    if code=='0000000' and customer.get('pec'):tag(transmission,'PECDestinatario',customer['pec'])
    for element,row,issuer in [('CedentePrestatore',company,True),('CessionarioCommittente',customer,False)]:
        party=tag(header,element);ident=tag(party,'DatiAnagrafici');vat=tag(ident,'IdFiscaleIVA');tag(vat,'IdPaese','IT');tag(vat,'IdCodice',row['vat_number'])
        if row.get('tax_code'):tag(ident,'CodiceFiscale',row['tax_code'])
        personal=tag(ident,'Anagrafica');tag(personal,'Denominazione',row['name'])
        if issuer:tag(ident,'RegimeFiscale',row['fiscal_regime'])
        address=tag(party,'Sede');tag(address,'Indirizzo',row['address']);tag(address,'CAP',row['postal_code']);tag(address,'Comune',row['city']);tag(address,'Provincia',row['province']);tag(address,'Nazione','IT')
    body=tag(root,'FatturaElettronicaBody');general=tag(body,'DatiGenerali');document=tag(general,'DatiGeneraliDocumento')
    tag(document,'TipoDocumento',invoice['fiscal_document_type']);tag(document,'Divisa','EUR')
    tag(document,'Data',invoice['issue_date'].isoformat());tag(document,'Numero',invoice['number']);tag(document,'ImportoTotaleDocumento',money_text(invoice['total']))
    items=[];related={}
    for row in lines:
        descriptor=row['description']
        if row['discount_percent'] or row['discount_amount']:
            descriptor+=f" (sconto {row['discount_percent']}%; € {row['discount_amount']})"
        items.append({'description':descriptor,'quantity':row['quantity'],'unit':row['unit_code'],
                      'taxable':row['taxable'],'vat_rate':row['vat_rate'],'nature':row['vat_nature']})
    for source in sources:
        if source['delivery_id']:
            for row in ddts[source['delivery_id']]:
                items.append({'description':row['description'],'quantity':row['quantity'],'unit':row['unit_code'],
                              'taxable':delivery_line_total(row),'vat_rate':row['vat_rate'],'nature':''})
                related.setdefault(source['delivery_id'],[]).append(len(items))
        else:
            row=sals[source['sal_id']]
            items.append({'description':'SAL '+row['number']+' · '+row['description'],'quantity':Decimal('1'),
                          'unit':'PZ','taxable':source['taxable'],'vat_rate':row['vat_rate'],'nature':''})
    if any(row['vat_rate']==0 and not row['nature'] for row in items):
        raise HTTPException(422,'XML non generato: indica la natura IVA per tutte le righe con aliquota zero, incluse DDT/SAL')
    for source in sources:
        if source['delivery_id']:
            block=tag(general,'DatiDDT')
            for line_number in related[source['delivery_id']]:tag(block,'RiferimentoNumeroLinea',line_number)
            tag(block,'NumeroDDT',source['ddt_number']);tag(block,'DataDDT',source['ddt_date'].isoformat())
    goods=tag(body,'DatiBeniServizi');grouped=defaultdict(Decimal)
    for index,row in enumerate(items,1):
        line=tag(goods,'DettaglioLinee');tag(line,'NumeroLinea',index);tag(line,'Descrizione',row['description'][:1000]);tag(line,'Quantita',f'{row["quantity"]:.4f}');tag(line,'UnitaMisura',str(row['unit'])[:10]);
        price=(Decimal(row['taxable'])/Decimal(row['quantity'])).quantize(Decimal('0.00000001'),rounding=ROUND_HALF_UP)
        tag(line,'PrezzoUnitario',price);tag(line,'PrezzoTotale',money_text(row['taxable']));tag(line,'AliquotaIVA',money_text(row['vat_rate']))
        if row['nature']:tag(line,'Natura',row['nature'])
        grouped[(row['vat_rate'],row['nature'])]+=row['taxable']
    for (rate,nature),taxable in sorted(grouped.items()):
        if taxable<0:raise HTTPException(422,'Sconto oltre l’imponibile della stessa aliquota')
        block=tag(goods,'DatiRiepilogo');tag(block,'AliquotaIVA',money_text(rate));
        if nature:tag(block,'Natura',nature)
        tag(block,'ImponibileImporto',money_text(taxable));tag(block,'Imposta',money_text(taxable*rate/100));tag(block,'EsigibilitaIVA','I')
    vat=sum((money(taxable*rate/100) for (rate,_),taxable in grouped.items()),Decimal('0'))
    total=sum(grouped.values(),Decimal('0'))+vat
    if money(total)!=invoice['total']:
        raise HTTPException(422,'Totale XML diverso dalla fattura: controlla arrotondamenti e fonti')
    payment=tag(body,'DatiPagamento');tag(payment,'CondizioniPagamento','TP02' if len(dues)>1 else 'TP01')
    mode={'TRANSFER':'MP05','RIBA':'MP12'}.get(invoice['payment_type'],'MP01')
    for due in dues:
        row=tag(payment,'DettaglioPagamento');tag(row,'ModalitaPagamento',mode);tag(row,'DataScadenzaPagamento',due['due_date'].isoformat());tag(row,'ImportoPagamento',money_text(due['amount']))
        if invoice['bank_iban'] and mode in ('MP05','MP12'):tag(row,'IBAN',invoice['bank_iban'])
    result=ET.tostring(root,encoding='utf-8',xml_declaration=True)
    ET.fromstring(result)
    return result


@router.get('/invoice-register/{invoice_id}/xml-preview')
def export_xml_preview(invoice_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        invoice=conn.execute('SELECT * FROM invoice_register WHERE id=%s AND active=true',(invoice_id,)).fetchone()
        if not invoice:raise HTTPException(404,'Fattura non trovata')
        company=invoice['company_snapshot'] or conn.execute('SELECT * FROM company_settings WHERE id=1').fetchone()
        customer=invoice['customer_snapshot'] or (conn.execute('SELECT * FROM customers WHERE id=%s',(invoice['customer_id'],)).fetchone() if invoice['customer_id'] else invoice['casual_customer'])
        lines=conn.execute('SELECT * FROM invoice_lines WHERE invoice_id=%s ORDER BY position,id',(invoice_id,)).fetchall()
        sources=conn.execute('SELECT s.*,d.number AS ddt_number,d.issued_on AS ddt_date FROM invoice_sources s LEFT JOIN delivery_notes d ON d.id=s.delivery_id WHERE invoice_id=%s ORDER BY s.id',(invoice_id,)).fetchall()
        ddts={r['delivery_id']:conn.execute('SELECT * FROM delivery_lines WHERE delivery_id=%s ORDER BY id',(r['delivery_id'],)).fetchall() for r in sources if r['delivery_id']}
        sals={r['sal_id']:conn.execute('SELECT * FROM progress_certificates WHERE id=%s',(r['sal_id'],)).fetchone() for r in sources if r['sal_id']}
        dues=conn.execute("SELECT due_date,amount FROM payment_due WHERE invoice_id=%s AND active=true AND status<>'CANCELLED' ORDER BY due_date,id",(invoice_id,)).fetchall()
        payload=create_xml(invoice,company,customer,lines,sources,ddts,sals,dues)
    filename=f"IT{company['vat_number']}_{invoice_id:05d}.xml"
    return Response(payload,media_type='application/xml',headers={'Content-Disposition':f'attachment; filename="{filename}"','X-ERP-Validation':'internal-only; official-XSD-and-Aruba-test-required'})
