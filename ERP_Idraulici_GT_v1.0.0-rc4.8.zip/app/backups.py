"""PostgreSQL company backups and guarded database replacement."""
import asyncio
import os
import re
import subprocess
import tempfile
import threading
import time
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import psycopg
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel

from app.auth import allowed
from app.db import connect

router = APIRouter()
ROOT = Path(os.environ.get('BACKUP_DIR', '/app/backup'))
MAX_UPLOAD = 8 * 1024 * 1024 * 1024
BACKUP_TIMEOUT = 3600
MAX_BACKUPS = 7
_mutex = threading.Lock()
maintenance = threading.Event()


def settings():
    opts = psycopg.conninfo.conninfo_to_dict(os.environ['DATABASE_URL'])
    dbname = opts.get('dbname')
    if not dbname or not re.fullmatch(r'[a-zA-Z][a-zA-Z0-9_]*', dbname):
        raise RuntimeError('Nome database non supportato per i backup')
    return opts, dbname


def pg_env(opts):
    env = os.environ.copy()
    for key, target in [('host','PGHOST'), ('port','PGPORT'), ('user','PGUSER'),
                        ('password','PGPASSWORD'), ('sslmode','PGSSLMODE')]:
        if opts.get(key):
            env[target] = str(opts[key])
    return env


def directory(dbname):
    folder = ROOT / dbname
    folder.mkdir(mode=0o700, parents=True, exist_ok=True)
    return folder


def command(args, opts, timeout=BACKUP_TIMEOUT, env_override=None):
    try:
        return subprocess.run(args, env={**pg_env(opts), **(env_override or {})}, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=timeout, check=True)
    except FileNotFoundError as exc:
        raise RuntimeError('Client PostgreSQL non installato nel container API') from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError('Operazione PostgreSQL scaduta') from exc
    except subprocess.CalledProcessError as exc:
        # Do not echo stderr: connection strings may appear in diagnostic output.
        raise RuntimeError(f'Comando PostgreSQL non riuscito (codice {exc.returncode})') from exc


def validate_archive(path, opts):
    with open(path, 'rb') as stream:
        if stream.read(5) != b'PGDMP':
            raise ValueError('Serve un backup PostgreSQL .dump in formato personalizzato')
    listing = command(['pg_restore','--list',str(path)], opts, timeout=120).stdout.decode(errors='replace')
    if not re.search(r'^\d+;.*\bTABLE\b.*\bschema_migrations\b', listing, re.M) or not re.search(
            r'^\d+;.*\bTABLE\b.*\bcompany_settings\b', listing, re.M):
        raise ValueError('Il file non contiene un backup completo del gestionale')


def create_backup():
    opts, dbname = settings()
    folder = directory(dbname)
    stamp = datetime.now(ZoneInfo('Europe/Rome')).strftime('%Y%m%d_%H%M%S')
    destination = folder / f'{dbname}_{stamp}_{os.urandom(3).hex()}.dump'
    fd, tmp = tempfile.mkstemp(prefix='.creating_', suffix='.dump', dir=folder)
    os.close(fd)
    try:
        os.chmod(tmp, 0o600)
        command(['pg_dump','--format=custom','--no-owner','--no-acl','--file',tmp,dbname], opts)
        validate_archive(tmp, opts)
        if os.stat(tmp).st_size < 100:
            raise RuntimeError('Backup vuoto')
        os.replace(tmp, destination)
        backups=sorted((p for p in folder.glob(f'{dbname}_*.dump') if p.is_file()),key=lambda p:p.stat().st_mtime,reverse=True)
        for stale in backups[MAX_BACKUPS:]:
            stale.unlink(missing_ok=True)
        return destination
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


@contextmanager
def exclusive():
    if not _mutex.acquire(blocking=False):
        raise HTTPException(409, 'È già in corso un backup o un ripristino')
    try:
        yield
    finally:
        _mutex.release()


class ScheduleEdit(BaseModel):
    enabled: bool
    backup_time: str


@router.get('/admin/backups')
def list_backups(user=Depends(allowed('ADMIN'))):
    _, dbname = settings()
    with connect() as conn:
        schedule = conn.execute('SELECT enabled,backup_time::text AS backup_time,timezone,last_success_day,last_success_at,last_error FROM backup_schedule WHERE id=1').fetchone()
    files = sorted(directory(dbname).glob(f'{dbname}_*.dump'), key=lambda p:p.stat().st_mtime, reverse=True)[:MAX_BACKUPS]
    return {'schedule': schedule, 'files': [
        {'name': p.name, 'size': p.stat().st_size,
         'created_at': datetime.fromtimestamp(p.stat().st_mtime, ZoneInfo('Europe/Rome')).isoformat()}
        for p in files if p.is_file()]}


@router.put('/admin/backups/schedule')
def save_schedule(data: ScheduleEdit, user=Depends(allowed('ADMIN'))):
    if not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d', data.backup_time):
        raise HTTPException(400, 'Orario richiesto in formato HH:MM, da 00:00 a 23:59')
    with connect() as conn:
        conn.execute('UPDATE backup_schedule SET enabled=%s,backup_time=%s WHERE id=1',
                     (data.enabled, data.backup_time))
    return {'ok': True}


@router.post('/admin/backups/create')
def manual_backup(user=Depends(allowed('ADMIN'))):
    with exclusive():
        try:
            path = create_backup()
        except (RuntimeError, OSError) as exc:
            raise HTTPException(500, str(exc)) from exc
    return {'name': path.name, 'size': path.stat().st_size}


def existing_file(name):
    _, dbname = settings()
    if not re.fullmatch(re.escape(dbname) + r'_\d{8}_\d{6}_[a-f0-9]{6}\.dump', name):
        raise HTTPException(404, 'Backup non trovato')
    path = directory(dbname) / name
    if not path.is_file() or path.is_symlink():
        raise HTTPException(404, 'Backup non trovato')
    return path


@router.get('/admin/backups/{name}')
def download_backup(name: str, user=Depends(allowed('ADMIN'))):
    path = existing_file(name)
    return FileResponse(path, filename=path.name, media_type='application/octet-stream',
                        headers={'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'})


def restore_archive(path):
    opts, dbname = settings()
    validate_archive(path, opts)
    # A separate database is fully checked before the active database is touched.
    control_opts = {**opts, 'dbname': 'postgres'}
    stage = f'erp_stage_{os.urandom(5).hex()}'
    previous = f'erp_before_{os.urandom(5).hex()}'
    with psycopg.connect(psycopg.conninfo.make_conninfo('', **control_opts), autocommit=True) as admin:
        with admin.cursor() as cur:
            cur.execute('SELECT pg_advisory_lock(783454)')
            created = False
            renamed = False
            try:
                cur.execute(f'CREATE DATABASE "{stage}" TEMPLATE template0')
                created = True
                command(['pg_restore','--no-owner','--no-acl','--exit-on-error',
                         '--single-transaction','--dbname',stage,str(path)], opts)
                with psycopg.connect(psycopg.conninfo.make_conninfo('', **{**opts, 'dbname':stage})) as verify:
                    installed = {r[0] for r in verify.execute('SELECT version FROM schema_migrations').fetchall()}
                    available = {p.stem for p in (Path(__file__).parent.parent / 'migrations').glob('*.sql')}
                    if not installed <= available:
                        raise ValueError('Il backup proviene da una versione del programma più recente')
                # Older backups can be restored and upgraded before activating them.
                command(['python','-m','app.migrate'], opts, env_override={
                    'DATABASE_URL': psycopg.conninfo.make_conninfo('', **{**opts, 'dbname':stage})})
                with psycopg.connect(psycopg.conninfo.make_conninfo('', **{**opts, 'dbname':stage})) as verify:
                    for table in ('schema_migrations', 'company_settings', 'users'):
                        verify.execute(f'SELECT count(*) FROM "{table}"').fetchone()
                    verify.execute('DELETE FROM sessions')
                # Preserve a complete copy on disk before switching database names.
                create_backup()
                cur.execute('SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname=%s AND pid<>pg_backend_pid()', (dbname,))
                cur.execute(f'ALTER DATABASE "{dbname}" RENAME TO "{previous}"')
                renamed = True
                try:
                    cur.execute(f'ALTER DATABASE "{stage}" RENAME TO "{dbname}"')
                except Exception:
                    cur.execute(f'ALTER DATABASE "{previous}" RENAME TO "{dbname}"')
                    renamed = False
                    raise
                created = False
                # Keep the previous database until the restored one is queried successfully.
                try:
                    with connect() as check:
                        check.execute('SELECT count(*) FROM schema_migrations').fetchone()
                except Exception:
                    cur.execute('SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname=%s', (dbname,))
                    cur.execute(f'ALTER DATABASE "{dbname}" RENAME TO "{stage}"')
                    cur.execute(f'ALTER DATABASE "{previous}" RENAME TO "{dbname}"')
                    created = True
                    renamed = False
                    raise
                # The pre-restore dump is the retained rollback copy.
                try:
                    cur.execute(f'DROP DATABASE "{previous}" WITH (FORCE)')
                except psycopg.Error:
                    pass  # The old database stays available for manual recovery.
                renamed = False
            finally:
                if created:
                    cur.execute(f'DROP DATABASE IF EXISTS "{stage}" WITH (FORCE)')
                cur.execute('SELECT pg_advisory_unlock(783454)')


@router.post('/admin/backups/restore')
async def restore_upload(request: Request, user=Depends(allowed('ADMIN'))):
    if request.headers.get('content-type', '').split(';')[0] != 'application/octet-stream':
        raise HTTPException(415, 'Carica un file .dump')
    opts, dbname = settings()
    folder = directory(dbname)
    with exclusive():
        fd, path = tempfile.mkstemp(prefix='.incoming_', suffix='.dump', dir=folder)
        try:
            total = 0
            with os.fdopen(fd, 'wb') as stream:
                os.chmod(path, 0o600)
                async for chunk in request.stream():
                    total += len(chunk)
                    if total > MAX_UPLOAD:
                        raise HTTPException(413, 'Backup troppo grande (limite 8 GB)')
                    stream.write(chunk)
            try:
                maintenance.set()
                await asyncio.to_thread(restore_archive, path)
            except (ValueError, RuntimeError, OSError, psycopg.Error) as exc:
                raise HTTPException(400, f'Ripristino non riuscito: {exc}') from exc
            finally:
                maintenance.clear()
        finally:
            os.unlink(path)
    return {'ok': True, 'message': 'Database ripristinato; accedi nuovamente'}


def daily_worker():
    while True:
        try:
            now = datetime.now(ZoneInfo('Europe/Rome'))
            with connect() as conn:
                row = conn.execute('SELECT enabled,backup_time,last_success_day FROM backup_schedule WHERE id=1').fetchone()
            if (row and row['enabled'] and now.hour == row['backup_time'].hour
                    and now.minute == row['backup_time'].minute
                    and row['last_success_day'] != now.date() and _mutex.acquire(blocking=False)):
                try:
                    path = create_backup()
                    with connect() as conn:
                        conn.execute('UPDATE backup_schedule SET last_success_day=%s,last_success_at=now(),last_error=NULL WHERE id=1', (now.date(),))
                except Exception as exc:
                    with connect() as conn:
                        conn.execute('UPDATE backup_schedule SET last_error=%s WHERE id=1', (str(exc)[:300],))
                finally:
                    _mutex.release()
        except Exception:
            pass  # Recheck after a transient connection failure; keep API available.
        time.sleep(30)


def start_scheduler():
    threading.Thread(target=daily_worker, name='erp-daily-backup', daemon=True).start()
