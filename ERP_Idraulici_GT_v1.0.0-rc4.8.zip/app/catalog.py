"""Catalog, addresses and price lists. Existing stock ledger remains the source of quantities."""
import base64
import binascii
import json
from datetime import date
from decimal import Decimal, InvalidOperation
from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel
from app.auth import allowed, current_user, has_module
from app.db import connect
from app.locale_numbers import normalized, quantized_input

router = APIRouter()


class CategoryIn(BaseModel):
    name: str
    default_markup: str = '22'


@router.get('/product-categories')
def list_categories(user=Depends(allowed('ADMIN','OFFICE','WAREHOUSE'))):
    with connect() as conn:
        return conn.execute('SELECT id,name FROM product_categories WHERE active=true ORDER BY name').fetchall()


def save_category(data,user,category_id=None):
    name=data.name.strip()
    if not name or len(name)>120:raise HTTPException(400,'Nome categoria non valido')
    markup=number(data.default_markup,2,Decimal('1000'))
    with connect() as conn:
        if conn.execute('SELECT 1 FROM product_categories WHERE lower(name)=lower(%s) AND id<>%s AND active=true',(name,category_id or 0)).fetchone():
            raise HTTPException(409,'Categoria già presente')
        if category_id is None:
            row=conn.execute('INSERT INTO product_categories(name,default_markup) VALUES (%s,%s) RETURNING id',(name,markup)).fetchone()
        else:
            previous=conn.execute('SELECT name FROM product_categories WHERE id=%s AND active=true FOR UPDATE',(category_id,)).fetchone()
            if not previous:raise HTTPException(404,'Categoria non trovata')
            row=conn.execute('UPDATE product_categories SET name=%s,default_markup=%s WHERE id=%s RETURNING id',(name,markup,category_id)).fetchone()
            conn.execute('UPDATE products SET category=%s WHERE lower(category)=lower(%s)',(name,previous['name']))
        audit(conn,user,'CREATE' if category_id is None else 'UPDATE','product_categories',row['id'])
        return {'id':row['id']}


@router.post('/product-categories',status_code=201)
def add_category(data:CategoryIn,user=Depends(allowed('ADMIN','OFFICE'))):
    return save_category(data,user)


@router.put('/product-categories/{category_id}')
def edit_category(category_id:int,data:CategoryIn,user=Depends(allowed('ADMIN','OFFICE'))):
    return save_category(data,user,category_id)


@router.delete('/product-categories/{category_id}')
def archive_category(category_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        old=conn.execute('SELECT name FROM product_categories WHERE id=%s AND active=true FOR UPDATE',(category_id,)).fetchone()
        if not old:raise HTTPException(404,'Categoria non trovata')
        if conn.execute('SELECT 1 FROM products WHERE lower(category)=lower(%s) AND active=true LIMIT 1',(old['name'],)).fetchone():
            raise HTTPException(409,'Categoria usata da articoli: sposta prima gli articoli')
        conn.execute('UPDATE product_categories SET active=false WHERE id=%s',(category_id,))
        audit(conn,user,'ARCHIVE','product_categories',category_id)
    return {'ok':True}
PRODUCT_FIELDS = ('code','description','unit_id','supplier_id','supplier_code','barcode','category',
                  'brand','location','notes','purchase_price','list_price','vat_rate','min_stock',
                  'default_warehouse_id','kind','purchase_profile_id')


def number(value, places=4, maximum=Decimal('99999999999.9999')):
    try:
        if not isinstance(value, str):
            raise ValueError()
        d = Decimal(normalized(value))
        if not d.is_finite() or d < 0 or d > maximum:
            raise ValueError()
        return quantized_input(d, places)
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise HTTPException(400, f'Numero non valido: {value}') from exc


def discounted_price(price: Decimal, percent: Decimal) -> Decimal:
    return (price * (Decimal(1) - percent / Decimal(100))).quantize(Decimal('0.0001'))


def sequential_discounts(price: Decimal, discounts) -> Decimal:
    for percent in discounts:
        price = price * (Decimal(1) - percent / Decimal(100))
    return price.quantize(Decimal('0.0001'))


def audit(conn, user, action, entity, entity_id, details=None):
    conn.execute('INSERT INTO audit_events(user_id,action,entity,entity_id,details) VALUES (%s,%s,%s,%s,%s)',
                 (user['id'], action, entity, entity_id, json.dumps(details or {})))


def product_payload(data, record_id, user):
    values = data.model_dump()
    for name in ('purchase_price','list_price','min_stock'):
        values[name] = number(values[name])
    values['vat_rate'] = number(values['vat_rate'], 2, Decimal('100'))
    if values['purchase_profile_id'] is not None:
        with connect() as conn:
            profile=conn.execute('SELECT supplier_id FROM purchase_discount_profiles WHERE id=%s AND active=true',(values['purchase_profile_id'],)).fetchone()
            if not profile or profile['supplier_id'] is not None and profile['supplier_id']!=values['supplier_id']:
                raise HTTPException(400,'La condizione di acquisto non appartiene al fornitore selezionato')
    if not values['code'].strip() or not values['description'].strip() or values['kind'] not in ('SIMPLE','KIT'):
        raise HTTPException(400, 'Codice, descrizione e tipo articolo validi sono obbligatori')
    values['category']=values['category'].strip()
    if values['category']:
        with connect() as conn:
            category=conn.execute('SELECT name FROM product_categories WHERE lower(name)=lower(%s) AND active=true',(values['category'],)).fetchone()
            if not category:raise HTTPException(400,'Scegli una categoria esistente')
            values['category']=category['name']
    columns = ','.join(PRODUCT_FIELDS)
    params = tuple(values[name] for name in PRODUCT_FIELDS)
    try:
        with connect() as conn:
            if record_id is None:
                placeholders = ','.join(['%s'] * len(PRODUCT_FIELDS))
                row = conn.execute(f'INSERT INTO products ({columns}) VALUES ({placeholders}) RETURNING *', params).fetchone()
                action = 'CREATE'
            else:
                assignments = ','.join(f'{c}=%s' for c in PRODUCT_FIELDS)
                row = conn.execute(f'UPDATE products SET {assignments} WHERE id=%s AND active=true RETURNING *', (*params, record_id)).fetchone()
                if not row:
                    raise HTTPException(404, 'Articolo non trovato')
                action = 'UPDATE'
            audit(conn, user, action, 'products', row['id'])
            return format_product(row, user)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, str(exc)) from exc


def format_product(row, user):
    result = dict(row)
    for key in ('purchase_price','list_price','vat_rate','min_stock','total_stock'):
        if key in result and result[key] is not None:
            result[key] = str(result[key])
    if user['role'] != 'ADMIN' and not (has_module(user,'suppliers',True) or has_module(user,'quotes',True)):
        result.pop('purchase_price', None)
    return result


def product_rows(user):
    with connect() as conn:
        rows = conn.execute('SELECT p.*,u.code AS unit_code,s.name AS supplier_name,w.name AS default_warehouse_name, '
                            'COALESCE((SELECT sum(b.quantity) FROM balances b WHERE b.product_id=p.id),0) AS total_stock, '
                            'EXISTS(SELECT 1 FROM product_photos ph WHERE ph.product_id=p.id) AS has_photo '
                            'FROM products p JOIN units u ON u.id=p.unit_id '
                            'LEFT JOIN suppliers s ON s.id=p.supplier_id LEFT JOIN warehouses w ON w.id=p.default_warehouse_id '
                            'WHERE p.active=true ORDER BY p.code LIMIT 2000').fetchall()
    return [format_product(row,user) for row in rows]


@router.get('/products/search')
def search_products(q:str='',category:str='',user=Depends(current_user)):
    if len(q)>120 or len(category)>120:raise HTTPException(400,'Ricerca troppo lunga')
    terms=q.strip().split()
    where=['p.active=true'];params=[]
    for term in terms:
        where.append('(p.code ILIKE %s OR p.description ILIKE %s)')
        params.extend(['%'+term+'%','%'+term+'%'])
    if category:
        where.append('lower(p.category)=lower(%s)');params.append(category)
    with connect() as conn:
        rows=conn.execute('SELECT p.*,u.code AS unit_code,s.name AS supplier_name,w.name AS default_warehouse_name, '
                          'COALESCE((SELECT sum(b.quantity) FROM balances b WHERE b.product_id=p.id),0) AS total_stock, '
                          'EXISTS(SELECT 1 FROM product_photos ph WHERE ph.product_id=p.id) AS has_photo '
                          'FROM products p JOIN units u ON u.id=p.unit_id '
                          'LEFT JOIN suppliers s ON s.id=p.supplier_id LEFT JOIN warehouses w ON w.id=p.default_warehouse_id '
                          'WHERE '+' AND '.join(where)+' ORDER BY p.code LIMIT 100',tuple(params)).fetchall()
    return [format_product(row,user) for row in rows]


@router.put('/products/{record_id}')
def edit_product(record_id: int, data: dict, user=Depends(allowed('ADMIN','OFFICE'))):
    # Use the same schema as creation without importing app.api (which owns this router).
    from app.api import ProductIn
    return product_payload(ProductIn.model_validate(data), record_id, user)


@router.delete('/products/{record_id}')
def archive_product(record_id: int, user=Depends(allowed('ADMIN'))):
    with connect() as conn:
        row = conn.execute('SELECT id FROM products WHERE id=%s AND active=true FOR UPDATE', (record_id,)).fetchone()
        if not row:
            raise HTTPException(404, 'Articolo non trovato')
        if conn.execute('SELECT 1 FROM balances WHERE product_id=%s AND quantity>0 LIMIT 1', (record_id,)).fetchone():
            raise HTTPException(409, 'Articolo con giacenza: scarica o trasferisci prima il materiale')
        if conn.execute('SELECT 1 FROM bom_lines WHERE component_id=%s OR parent_id=%s LIMIT 1', (record_id,record_id)).fetchone():
            raise HTTPException(409, 'Articolo presente in una distinta base')
        if conn.execute('SELECT 1 FROM delivery_lines WHERE product_id=%s LIMIT 1', (record_id,)).fetchone():
            raise HTTPException(409, 'Articolo presente in un DDT: conserva l’articolo per mantenere la catena dei documenti')
        if conn.execute('SELECT 1 FROM quote_lines WHERE product_id=%s LIMIT 1', (record_id,)).fetchone():
            raise HTTPException(409, 'Articolo presente in un preventivo: conserva il documento associato')
        conn.execute('UPDATE products SET active=false WHERE id=%s', (record_id,))
        audit(conn,user,'ARCHIVE','products',record_id)
    return {'ok':True}


class WarehouseEdit(BaseModel):
    code: str
    name: str
    kind: str


@router.put('/warehouses/{record_id}')
def edit_warehouse(record_id: int, data: WarehouseEdit, user=Depends(allowed('ADMIN','WAREHOUSE'))):
    if data.kind not in ('CENTRAL','VAN','JOB','OTHER') or not data.name.strip() or not data.code.strip():
        raise HTTPException(400,'Dati magazzino non validi')
    with connect() as conn:
        row=conn.execute('UPDATE warehouses SET code=%s,name=%s,kind=%s WHERE id=%s AND active=true RETURNING *',
                         (data.code,data.name,data.kind,record_id)).fetchone()
        if not row: raise HTTPException(404,'Magazzino non trovato')
        audit(conn,user,'UPDATE','warehouses',record_id)
        return row


@router.delete('/warehouses/{record_id}')
def archive_warehouse(record_id: int, user=Depends(allowed('ADMIN'))):
    with connect() as conn:
        row=conn.execute('SELECT id FROM warehouses WHERE id=%s AND active=true FOR UPDATE',(record_id,)).fetchone()
        if not row: raise HTTPException(404,'Magazzino non trovato')
        if conn.execute('SELECT 1 FROM balances WHERE warehouse_id=%s AND quantity>0 LIMIT 1',(record_id,)).fetchone():
            raise HTTPException(409,'Magazzino con giacenza: trasferisci prima il materiale')
        if conn.execute('SELECT 1 FROM products WHERE default_warehouse_id=%s AND active=true LIMIT 1',(record_id,)).fetchone():
            raise HTTPException(409,'Magazzino predefinito di un articolo')
        conn.execute('UPDATE warehouses SET active=false WHERE id=%s',(record_id,))
        audit(conn,user,'ARCHIVE','warehouses',record_id)
    return {'ok':True}


class UnitEdit(BaseModel):
    code: str
    description: str


@router.put('/units/{record_id}')
def edit_unit(record_id:int,data:UnitEdit,user=Depends(allowed('ADMIN'))):
    if not data.code.strip() or not data.description.strip(): raise HTTPException(400,'Dati unità mancanti')
    from app.api import BUILTIN_UNITS
    with connect() as conn:
        old=conn.execute('SELECT code FROM units WHERE id=%s FOR UPDATE',(record_id,)).fetchone()
        if not old: raise HTTPException(404,'Unità non trovata')
        if old['code'] in BUILTIN_UNITS and data.code != old['code']:
            raise HTTPException(409,'Il codice di una unità predefinita non può cambiare')
        row=conn.execute('UPDATE units SET code=%s,description=%s WHERE id=%s RETURNING *',
                         (data.code,data.description,record_id)).fetchone()
        audit(conn,user,'UPDATE','units',record_id)
        return row


class AddressIn(BaseModel):
    label: str
    address: str
    postal_code: str = ''
    city: str = ''
    province: str = ''
    contact_name: str = ''
    phone: str = ''
    is_default: bool = False


def address_table(party):
    if party not in ('customers','suppliers'): raise HTTPException(404,'Tipo anagrafica non trovato')
    return (party[:-1]+'_addresses', party[:-1]+'_id')


@router.get('/{party}/'+'{party_id}/addresses')
def addresses(party:str,party_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    table,fk=address_table(party)
    with connect() as conn:
        return conn.execute(f'SELECT * FROM {table} WHERE {fk}=%s AND active=true ORDER BY is_default DESC,id',(party_id,)).fetchall()


@router.post('/{party}/'+'{party_id}/addresses',status_code=201)
def add_address(party:str,party_id:int,data:AddressIn,user=Depends(allowed('ADMIN','OFFICE'))):
    table,fk=address_table(party)
    if not data.label.strip() or not data.address.strip(): raise HTTPException(400,'Etichetta e indirizzo obbligatori')
    fields=list(data.model_dump())
    with connect() as conn:
        if not conn.execute(f'SELECT id FROM {party} WHERE id=%s AND active=true FOR UPDATE',(party_id,)).fetchone():
            raise HTTPException(404,'Anagrafica non trovata')
        if data.is_default:
            conn.execute(f'UPDATE {table} SET is_default=false WHERE {fk}=%s AND active=true',(party_id,))
        row=conn.execute(f'INSERT INTO {table} ({fk},{",".join(fields)}) VALUES ({",".join(["%s"]*(len(fields)+1))}) RETURNING *',
                         (party_id,*data.model_dump().values())).fetchone()
        audit(conn,user,'CREATE',table,row['id'])
        return row


@router.put('/{party}/'+'{party_id}/addresses/{address_id}')
def edit_address(party:str,party_id:int,address_id:int,data:AddressIn,user=Depends(allowed('ADMIN','OFFICE'))):
    table,fk=address_table(party)
    if not data.label.strip() or not data.address.strip(): raise HTTPException(400,'Etichetta e indirizzo obbligatori')
    fields=list(data.model_dump())
    with connect() as conn:
        if not conn.execute(f'SELECT id FROM {party} WHERE id=%s AND active=true FOR UPDATE',(party_id,)).fetchone():
            raise HTTPException(404,'Anagrafica non trovata')
        if data.is_default:
            conn.execute(f'UPDATE {table} SET is_default=false WHERE {fk}=%s AND active=true',(party_id,))
        row=conn.execute(f'UPDATE {table} SET {",".join(f+"=%s" for f in fields)} WHERE id=%s AND {fk}=%s AND active=true RETURNING *',
                         (*data.model_dump().values(),address_id,party_id)).fetchone()
        if not row: raise HTTPException(404,'Indirizzo non trovato')
        audit(conn,user,'UPDATE',table,address_id)
        return row


@router.delete('/{party}/'+'{party_id}/addresses/{address_id}')
def archive_address(party:str,party_id:int,address_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    table,fk=address_table(party)
    with connect() as conn:
        row=conn.execute(f'UPDATE {table} SET active=false WHERE id=%s AND {fk}=%s AND active=true RETURNING id',(address_id,party_id)).fetchone()
        if not row: raise HTTPException(404,'Indirizzo non trovato')
        audit(conn,user,'ARCHIVE',table,address_id)
    return {'ok':True}


class PurchaseProfileIn(BaseModel):
    name: str
    supplier_id: int | None = None
    discount_1: str = '0'
    discount_2: str = '0'
    discount_3: str = '0'


@router.get('/purchase-discounts')
def purchase_profiles(user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        rows=conn.execute('SELECT d.*,s.name AS supplier_name FROM purchase_discount_profiles d '
                          'LEFT JOIN suppliers s ON s.id=d.supplier_id WHERE d.active=true ORDER BY d.name').fetchall()
    return [{**r,**{key:str(r[key]) for key in ('discount_1','discount_2','discount_3')}} for r in rows]


def save_purchase_profile(data,user,profile_id=None):
    name=data.name.strip()
    if not name or len(name)>100:raise HTTPException(400,'Indica un nome della condizione (massimo 100 caratteri)')
    rates=[number(getattr(data,'discount_'+str(i)),2,Decimal('100')) for i in (1,2,3)]
    with connect() as conn:
        if data.supplier_id and not conn.execute('SELECT 1 FROM suppliers WHERE id=%s AND active=true',(data.supplier_id,)).fetchone():
            raise HTTPException(400,'Fornitore non valido')
        if profile_id is None:
            row=conn.execute('INSERT INTO purchase_discount_profiles(name,supplier_id,discount_1,discount_2,discount_3) VALUES (%s,%s,%s,%s,%s) RETURNING id',
                             (name,data.supplier_id,*rates)).fetchone()
        else:
            current=conn.execute('SELECT 1 FROM purchase_discount_profiles WHERE id=%s AND active=true FOR UPDATE',(profile_id,)).fetchone()
            if not current:raise HTTPException(404,'Condizione di acquisto non trovata')
            if data.supplier_id and conn.execute('SELECT 1 FROM products WHERE purchase_profile_id=%s AND supplier_id IS DISTINCT FROM %s',(profile_id,data.supplier_id)).fetchone():
                raise HTTPException(409,'Sposta prima gli articoli assegnati a un altro fornitore')
            row=conn.execute('UPDATE purchase_discount_profiles SET name=%s,supplier_id=%s,discount_1=%s,discount_2=%s,discount_3=%s WHERE id=%s RETURNING id',
                             (name,data.supplier_id,*rates,profile_id)).fetchone()
        audit(conn,user,'CREATE' if profile_id is None else 'UPDATE','purchase_discount_profiles',row['id'])
    return {'id':row['id']}


@router.post('/purchase-discounts',status_code=201)
def add_purchase_profile(data:PurchaseProfileIn,user=Depends(allowed('ADMIN','OFFICE'))):
    return save_purchase_profile(data,user)


@router.put('/purchase-discounts/{profile_id}')
def edit_purchase_profile(profile_id:int,data:PurchaseProfileIn,user=Depends(allowed('ADMIN','OFFICE'))):
    return save_purchase_profile(data,user,profile_id)


@router.delete('/purchase-discounts/{profile_id}')
def archive_purchase_profile(profile_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        if conn.execute('SELECT 1 FROM products WHERE purchase_profile_id=%s AND active=true',(profile_id,)).fetchone():
            raise HTTPException(409,'Condizione in uso: sposta prima gli articoli')
        row=conn.execute('UPDATE purchase_discount_profiles SET active=false WHERE id=%s AND active=true RETURNING id',(profile_id,)).fetchone()
        if not row:raise HTTPException(404,'Condizione non trovata')
        audit(conn,user,'ARCHIVE','purchase_discount_profiles',profile_id)
    return {'ok':True}


class PriceListIn(BaseModel):
    code:str
    name:str
    discount_percent:str='0'
    discount_mode:str='SIMPLE'
    discount_1:str='0'
    discount_2:str='0'
    discount_3:str='0'


def price_list_values(data):
    if data.discount_mode not in ('SIMPLE','SEQUENTIAL'):
        raise HTTPException(400,'Tipo sconto listino non valido')
    return (number(data.discount_percent,2,Decimal('100')),data.discount_mode,
            number(data.discount_1,2,Decimal('100')),number(data.discount_2,2,Decimal('100')),
            number(data.discount_3,2,Decimal('100')))


@router.get('/price-lists')
def price_lists(user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        return conn.execute('SELECT * FROM price_lists WHERE active=true ORDER BY code').fetchall()


@router.post('/price-lists',status_code=201)
def add_price_list(data:PriceListIn,user=Depends(allowed('ADMIN','OFFICE'))):
    if not data.code.strip() or not data.name.strip(): raise HTTPException(400,'Codice e nome obbligatori')
    discount,mode,d1,d2,d3=price_list_values(data)
    with connect() as conn:
        row=conn.execute('INSERT INTO price_lists(code,name,discount_percent,discount_mode,discount_1,discount_2,discount_3) VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING *',(data.code,data.name,discount,mode,d1,d2,d3)).fetchone()
        audit(conn,user,'CREATE','price_lists',row['id'])
        return row


@router.put('/price-lists/{list_id}')
def edit_price_list(list_id:int,data:PriceListIn,user=Depends(allowed('ADMIN','OFFICE'))):
    if not data.code.strip() or not data.name.strip(): raise HTTPException(400,'Codice e nome obbligatori')
    discount,mode,d1,d2,d3=price_list_values(data)
    with connect() as conn:
        row=conn.execute('UPDATE price_lists SET code=%s,name=%s,discount_percent=%s,discount_mode=%s,discount_1=%s,discount_2=%s,discount_3=%s WHERE id=%s AND active=true RETURNING *',
                         (data.code,data.name,discount,mode,d1,d2,d3,list_id)).fetchone()
        if not row: raise HTTPException(404,'Listino non trovato')
        audit(conn,user,'UPDATE','price_lists',list_id)
        return row


@router.delete('/price-lists/{list_id}')
def archive_price_list(list_id:int,user=Depends(allowed('ADMIN'))):
    with connect() as conn:
        row=conn.execute('SELECT code FROM price_lists WHERE id=%s AND active=true FOR UPDATE',(list_id,)).fetchone()
        if not row: raise HTTPException(404,'Listino non trovato')
        if row['code']=='BASE': raise HTTPException(409,'Il listino base è protetto')
        if conn.execute('SELECT 1 FROM customers WHERE price_list_id=%s AND active=true LIMIT 1',(list_id,)).fetchone():
            raise HTTPException(409,'Listino assegnato a clienti attivi')
        conn.execute('UPDATE price_lists SET active=false WHERE id=%s',(list_id,))
        audit(conn,user,'ARCHIVE','price_lists',list_id)
    return {'ok':True}


class PriceIn(BaseModel):
    price:str


@router.put('/price-lists/{list_id}/products/{product_id}')
def set_list_price(list_id:int,product_id:int,data:PriceIn,user=Depends(allowed('ADMIN','OFFICE'))):
    value=number(data.price)
    with connect() as conn:
        if not conn.execute('SELECT 1 FROM price_lists WHERE id=%s AND active=true',(list_id,)).fetchone():
            raise HTTPException(404,'Listino non trovato')
        if not conn.execute('SELECT 1 FROM products WHERE id=%s AND active=true',(product_id,)).fetchone():
            raise HTTPException(404,'Articolo non trovato')
        conn.execute('INSERT INTO product_list_prices(product_id,price_list_id,price) VALUES (%s,%s,%s) '
                     'ON CONFLICT(product_id,price_list_id) DO UPDATE SET price=EXCLUDED.price',(product_id,list_id,value))
        audit(conn,user,'PRICE','products',product_id,{'price_list_id':list_id})
    return {'price':str(value)}


@router.get('/products/{product_id}/prices')
def list_product_prices(product_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        rows=conn.execute('SELECT l.id AS price_list_id,l.name,l.code,pl.price,p.list_price AS base_price '
                          'FROM price_lists l CROSS JOIN products p LEFT JOIN product_list_prices pl '
                          'ON pl.price_list_id=l.id AND pl.product_id=p.id '
                          'WHERE p.id=%s AND l.active=true ORDER BY l.code',(product_id,)).fetchall()
    if not rows: raise HTTPException(404,'Articolo non trovato')
    return [{**r,'price':str(r['price'] if r['price'] is not None else r['base_price']),
             'overridden':r['price'] is not None,'base_price':str(r['base_price'])} for r in rows]


@router.get('/customers/{customer_id}/prices/{product_id}')
def customer_price(customer_id:int,product_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        row=conn.execute('SELECT c.price_list_id,c.discount_percent,c.discount_mode,c.discount_1,c.discount_2,c.discount_3,l.discount_percent AS list_discount_percent,l.discount_mode AS list_discount_mode,l.discount_1 AS list_discount_1,l.discount_2 AS list_discount_2,l.discount_3 AS list_discount_3,p.list_price,pl.price AS override_price '
                         'FROM customers c JOIN price_lists l ON l.id=c.price_list_id CROSS JOIN products p LEFT JOIN product_list_prices pl '
                         'ON pl.product_id=p.id AND pl.price_list_id=c.price_list_id '
                         'WHERE c.id=%s AND p.id=%s AND c.active=true AND p.active=true',(customer_id,product_id)).fetchone()
    if not row: raise HTTPException(404,'Cliente o articolo non trovato')
    price=row['override_price'] if row['override_price'] is not None else row['list_price']
    list_discounts=(row['list_discount_1'],row['list_discount_2'],row['list_discount_3']) if row['list_discount_mode']=='SEQUENTIAL' else (row['list_discount_percent'],)
    customer_discounts=(row['discount_1'],row['discount_2'],row['discount_3']) if row['discount_mode']=='SEQUENTIAL' else (row['discount_percent'],)
    after_list=sequential_discounts(price,list_discounts)
    net=sequential_discounts(after_list,customer_discounts)
    return {'price_list_id':row['price_list_id'],'list_price':str(price),
            'discount_percent':str(row['discount_percent']),
            'discount_mode':row['discount_mode'],'discounts':[str(x) for x in customer_discounts],
            'list_discount_percent':str(row['list_discount_percent']),'list_discount_mode':row['list_discount_mode'],
            'list_discounts':[str(x) for x in list_discounts],'net_price':str(net)}


@router.get('/suppliers/{supplier_id}/discount-preview')
def supplier_discount_preview(supplier_id:int,gross:str,user=Depends(allowed('ADMIN','OFFICE'))):
    amount=number(gross)
    with connect() as conn:
        row=conn.execute('SELECT discount_1,discount_2,discount_3 FROM suppliers WHERE id=%s AND active=true',(supplier_id,)).fetchone()
    if not row: raise HTTPException(404,'Fornitore non trovato')
    discounts=(row['discount_1'],row['discount_2'],row['discount_3'])
    return {'gross':str(amount),'discounts':[str(x) for x in discounts],
            'net':str(sequential_discounts(amount,discounts))}


class BomIn(BaseModel):
    component_id:int
    quantity:str


@router.get('/products/{parent_id}/bom')
def get_bom(parent_id:int,user=Depends(current_user)):
    with connect() as conn:
        rows=conn.execute('SELECT b.id,b.component_id,p.code,p.description,u.code AS unit_code,b.quantity,p.list_price '
                          'FROM bom_lines b JOIN products p ON p.id=b.component_id JOIN units u ON u.id=p.unit_id '
                          'WHERE b.parent_id=%s ORDER BY b.id',(parent_id,)).fetchall()
    return [{**r,'quantity':str(r['quantity']),'list_price':str(r['list_price'])} for r in rows]


@router.post('/products/{parent_id}/bom',status_code=201)
def add_bom(parent_id:int,data:BomIn,user=Depends(allowed('ADMIN','OFFICE'))):
    qty=number(data.quantity)
    if qty==0 or parent_id==data.component_id: raise HTTPException(400,'Componente o quantità non validi')
    with connect() as conn:
        conn.execute('SELECT pg_advisory_xact_lock(783453)')
        rows=conn.execute('SELECT id,kind FROM products WHERE id IN (%s,%s) AND active=true',(parent_id,data.component_id)).fetchall()
        if len(rows)!=2 or next((r for r in rows if r['id']==parent_id),{}).get('kind')!='KIT':
            raise HTTPException(400,'La distinta richiede un articolo composto e un componente attivo')
        cycle=conn.execute('WITH RECURSIVE descendants(id) AS (SELECT component_id FROM bom_lines WHERE parent_id=%s '
                           'UNION SELECT b.component_id FROM bom_lines b JOIN descendants d ON b.parent_id=d.id) '
                           'SELECT 1 FROM descendants WHERE id=%s LIMIT 1',(data.component_id,parent_id)).fetchone()
        if cycle: raise HTTPException(409,'La distinta creerebbe un ciclo')
        row=conn.execute('INSERT INTO bom_lines(parent_id,component_id,quantity) VALUES (%s,%s,%s) '
                         'ON CONFLICT(parent_id,component_id) DO UPDATE SET quantity=EXCLUDED.quantity RETURNING id',
                         (parent_id,data.component_id,qty)).fetchone()
        audit(conn,user,'UPSERT','bom_lines',row['id'])
    return {'id':row['id'],'quantity':str(qty)}


@router.delete('/products/{parent_id}/bom/{line_id}')
def delete_bom(parent_id:int,line_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        row=conn.execute('DELETE FROM bom_lines WHERE id=%s AND parent_id=%s RETURNING id',(line_id,parent_id)).fetchone()
        if not row: raise HTTPException(404,'Componente non trovato')
        audit(conn,user,'DELETE','bom_lines',line_id)
    return {'ok':True}


class PhotoIn(BaseModel):
    mime_type:str
    data_base64:str


@router.put('/products/{product_id}/photo')
def set_photo(product_id:int,data:PhotoIn,user=Depends(allowed('ADMIN','OFFICE','WAREHOUSE'))):
    if data.mime_type not in ('image/jpeg','image/png','image/webp') or len(data.data_base64)>2800000:
        raise HTTPException(400,'Solo JPG, PNG o WebP fino a 2 MB')
    try: image=base64.b64decode(data.data_base64,validate=True)
    except (ValueError,binascii.Error) as exc: raise HTTPException(400,'Foto non valida') from exc
    signatures={'image/jpeg':image.startswith(b'\xff\xd8\xff'),
                'image/png':image.startswith(b'\x89PNG\r\n\x1a\n'),
                'image/webp':image.startswith(b'RIFF') and image[8:12]==b'WEBP'}
    if not image or len(image)>2097152 or not signatures[data.mime_type]:
        raise HTTPException(400,'Foto non valida o superiore a 2 MB')
    with connect() as conn:
        if not conn.execute('SELECT 1 FROM products WHERE id=%s AND active=true',(product_id,)).fetchone():
            raise HTTPException(404,'Articolo non trovato')
        conn.execute('INSERT INTO product_photos(product_id,mime_type,data) VALUES (%s,%s,%s) '
                     'ON CONFLICT(product_id) DO UPDATE SET mime_type=EXCLUDED.mime_type,data=EXCLUDED.data',
                     (product_id,data.mime_type,image))
        audit(conn,user,'PHOTO','products',product_id)
    return {'ok':True}


@router.get('/products/{product_id}/photo')
def get_photo(product_id:int,user=Depends(current_user)):
    with connect() as conn:
        row=conn.execute('SELECT mime_type,data FROM product_photos WHERE product_id=%s',(product_id,)).fetchone()
    if not row: raise HTTPException(404,'Foto non trovata')
    return Response(bytes(row['data']),media_type=row['mime_type'],headers={'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'})


@router.delete('/products/{product_id}/photo')
def delete_photo(product_id:int,user=Depends(allowed('ADMIN','OFFICE','WAREHOUSE'))):
    with connect() as conn:
        row=conn.execute('DELETE FROM product_photos WHERE product_id=%s RETURNING product_id',(product_id,)).fetchone()
        if not row: raise HTTPException(404,'Foto non trovata')
        audit(conn,user,'PHOTO_DELETE','products',product_id)
    return {'ok':True}
