from datetime import date
from fastapi import HTTPException
from app.db import connect


def query_movements(*, product_id=None, warehouse_id=None, source_id=None, destination_id=None, supplier_id=None,
                    kind=None, actor=None, reason=None, date_from=None, date_to=None, limit=500):
    where, values = [], []
    rules = [('m.product_id',product_id),('m.source_id',source_id),('m.destination_id',destination_id),
             ('m.supplier_id',supplier_id),('m.kind',kind)]
    for column,value in rules:
        if value is not None and value!='':
            where.append(f'{column}=%s');values.append(value)
    if warehouse_id is not None:
        where.append('(m.source_id=%s OR m.destination_id=%s)');values.extend((warehouse_id,warehouse_id))
    if actor:
        where.append('m.actor ILIKE %s');values.append('%'+actor+'%')
    if reason:
        where.append('m.reason ILIKE %s');values.append('%'+reason+'%')
    if date_from:
        where.append('m.created_at >= %s');values.append(date_from)
    if date_to:
        where.append('m.created_at < (%s::date + INTERVAL \'1 day\')');values.append(date_to)
    sql=('SELECT m.id,m.created_at,m.product_id,p.code AS product_code,p.description AS product_description,'
         'm.source_id,ws.name AS source_name,m.destination_id,wd.name AS destination_name,'
         'm.quantity,u.code AS unit_code,m.kind,m.actor,m.reason,m.supplier_id,s.name AS supplier_name,m.reverses_id '
         'FROM movements m JOIN products p ON p.id=m.product_id JOIN units u ON u.id=p.unit_id '
         'LEFT JOIN warehouses ws ON ws.id=m.source_id LEFT JOIN warehouses wd ON wd.id=m.destination_id '
         'LEFT JOIN suppliers s ON s.id=m.supplier_id ')
    if where: sql+='WHERE '+' AND '.join(where)+' '
    sql+='ORDER BY m.created_at DESC,m.id DESC LIMIT %s'
    with connect() as conn:
        rows=conn.execute(sql,(*values,limit+1)).fetchall()
    if len(rows)>limit and limit>500: raise HTTPException(413,f'Troppi movimenti: restringi i filtri (massimo {limit})')
    return [{**r,'quantity':str(r['quantity'])} for r in rows[:limit]]
