from decimal import Decimal, InvalidOperation
from app.locale_numbers import normalized, quantized_input

FOUR = Decimal('0.0001')
MAX = Decimal('99999999999.9999')


def quantity(value: str) -> Decimal:
    """Reject floats and values that would silently round in NUMERIC(15,4)."""
    if not isinstance(value, str):
        raise ValueError('quantity must be a decimal string')
    try:
        result = Decimal(normalized(value))
    except InvalidOperation as exc:
        raise ValueError('invalid quantity') from exc
    if not result.is_finite() or result <= 0 or result > MAX:
        raise ValueError('quantity must be positive with at most four decimal places')
    try:
        return quantized_input(result, 4)
    except ValueError as exc:
        raise ValueError('quantity must be positive with at most four decimal places') from exc


def projected(source: Decimal, destination: Decimal, amount: Decimal) -> tuple[Decimal, Decimal]:
    if source < amount:
        raise ValueError('insufficient stock')
    return source - amount, destination + amount
