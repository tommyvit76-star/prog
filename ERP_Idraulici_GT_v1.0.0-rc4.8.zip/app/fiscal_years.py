"""Fiscal-year selection and guarded year-end closing."""
from datetime import date

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.auth import allowed
from app.backups import create_backup, exclusive
from app.catalog import audit
from app.db import connect

router=APIRouter()


class SelectYear(BaseModel):
    year:int


class CloseYear(BaseModel):
    notes:str=''
    accept_warnings:bool=False


def ensure_year(conn,year:int):
    if not 2000<=year<=2100:raise HTTPException(400,'Anno esercizio non valido')
    row=conn.execute('SELECT * FROM fiscal_years WHERE year=%s',(year,)).fetchone()
    if not row:raise HTTPException(404,'Esercizio non trovato')
    return row


def assert_open(conn,document_date:date):
    row=ensure_year(conn,document_date.year)
    if row['status']!='OPEN':raise HTTPException(409,f'Esercizio {document_date.year} chiuso: documento in sola lettura')
    if not row['starts_on']<=document_date<=row['ends_on']:raise HTTPException(400,'Data fuori dai limiti dell’esercizio')
    return row


def year_checks(conn,year:int):
    blockers=[];warnings=[]
    checks=[
      ('Preventivi in bozza','SELECT count(*) n FROM quotes WHERE fiscal_year=%s AND active=true AND status=%s','DRAFT'),
      ('DDT in bozza','SELECT count(*) n FROM delivery_notes WHERE fiscal_year=%s AND active=true AND status=%s','DRAFT'),
      ('SAL in bozza','SELECT count(*) n FROM progress_certificates WHERE fiscal_year=%s AND active=true AND approval_status=%s','DRAFT'),
      ('Fatture in bozza','SELECT count(*) n FROM invoice_register WHERE fiscal_year=%s AND active=true AND document_status=%s','DRAFT'),
      ('Note di credito in bozza','SELECT count(*) n FROM credit_notes WHERE fiscal_year=%s AND active=true AND status=%s','DRAFT'),
    ]
    for label,sql,state in checks:
        count=conn.execute(sql,(year,state)).fetchone()['n']
        if count:blockers.append({'label':label,'count':count})
    warning_checks=[
      ('Scadenze ancora aperte',"SELECT count(*) n FROM payment_due d JOIN invoice_register i ON i.id=d.invoice_id WHERE i.fiscal_year=%s AND d.active=true AND d.status='OPEN'"),
      ('Cantieri ancora aperti',"SELECT count(*) n FROM project_sites WHERE active=true AND status IN ('PLANNED','OPEN','SUSPENDED')"),
      ('DDT di vendita non ancora fatturati',"SELECT count(*) n FROM delivery_notes d JOIN transport_reasons r ON r.id=d.transport_reason_id WHERE d.fiscal_year=%s AND d.active=true AND d.status='CONFIRMED' AND r.invoiceable=true AND NOT EXISTS(SELECT 1 FROM invoice_sources s WHERE s.delivery_id=d.id)"),
      ('SAL approvati non completamente fatturati',"SELECT count(*) n FROM progress_certificates p WHERE p.fiscal_year=%s AND p.active=true AND p.approval_status='APPROVED' AND COALESCE((SELECT sum(s.taxable) FROM invoice_sources s WHERE s.sal_id=p.id),0)<p.amount+p.variation_amount-p.retention_amount-p.advance_recovery"),
    ]
    for label,sql in warning_checks:
        count=conn.execute(sql,(year,)).fetchone()['n'] if '%s' in sql else conn.execute(sql).fetchone()['n']
        if count:warnings.append({'label':label,'count':count})
    return blockers,warnings


@router.get('/fiscal-years')
def years(user=Depends(allowed('ADMIN','OFFICE','WAREHOUSE','TECHNICIAN'))):
    with connect() as conn:
        rows=conn.execute('SELECT year,starts_on,ends_on,status,closed_at,backup_name,closing_notes FROM fiscal_years ORDER BY year DESC').fetchall()
    return {'selected':user['selected_fiscal_year'],'years':rows}


@router.post('/fiscal-years/select')
def select_year(data:SelectYear,user=Depends(allowed('ADMIN','OFFICE','WAREHOUSE','TECHNICIAN'))):
    with connect() as conn:
        ensure_year(conn,data.year)
        conn.execute('UPDATE users SET selected_fiscal_year=%s WHERE id=%s',(data.year,user['id']))
    return {'year':data.year}


@router.get('/admin/fiscal-years/{year}/precheck')
def precheck(year:int,user=Depends(allowed('ADMIN'))):
    with connect() as conn:
        row=ensure_year(conn,year);blockers,warnings=year_checks(conn,year)
    return {'year':year,'status':row['status'],'blockers':blockers,'warnings':warnings,'can_close':row['status']=='OPEN' and not blockers}


@router.post('/admin/fiscal-years/{year}/close')
def close_year(year:int,data:CloseYear,user=Depends(allowed('ADMIN'))):
    with connect() as conn:
        row=ensure_year(conn,year);blockers,warnings=year_checks(conn,year)
        if row['status']!='OPEN':raise HTTPException(409,'Esercizio già chiuso')
        if blockers:raise HTTPException(409,'Completa prima: '+', '.join(f'{x["label"]} ({x["count"]})' for x in blockers))
        if warnings and not data.accept_warnings:raise HTTPException(409,'Conferma il riporto delle partite aperte: '+', '.join(f'{x["label"]} ({x["count"]})' for x in warnings))
    with exclusive():
        try:backup=create_backup()
        except Exception as exc:raise HTTPException(500,'Chiusura annullata: backup non riuscito') from exc
    next_year=year+1
    with connect() as conn:
        row=ensure_year(conn,year)
        if row['status']!='OPEN':raise HTTPException(409,'Esercizio chiuso da un’altra sessione')
        conn.execute('INSERT INTO fiscal_years(year,starts_on,ends_on) VALUES (%s,%s,%s) ON CONFLICT(year) DO NOTHING',(next_year,date(next_year,1,1),date(next_year,12,31)))
        conn.execute("UPDATE fiscal_years SET status='CLOSED',closed_at=now(),closed_by=%s,backup_name=%s,closing_notes=%s WHERE year=%s",(user['id'],backup.name,data.notes.strip(),year))
        conn.execute('UPDATE users SET selected_fiscal_year=%s WHERE id=%s',(next_year,user['id']))
        audit(conn,user,'CLOSE','fiscal_years',year,{'backup':backup.name,'next_year':next_year})
    return {'closed':year,'selected':next_year,'backup':backup.name,'warnings':warnings}


@router.post('/admin/fiscal-years/{year}/reopen')
def reopen_year(year:int,data:CloseYear,user=Depends(allowed('ADMIN'))):
    if len(data.notes.strip())<8:raise HTTPException(400,'Indica una motivazione di almeno 8 caratteri')
    with connect() as conn:
        row=ensure_year(conn,year)
        if row['status']!='CLOSED':raise HTTPException(409,'Esercizio già aperto')
        conn.execute("UPDATE fiscal_years SET status='OPEN',closing_notes=concat_ws(' · ',closing_notes,%s) WHERE year=%s",('Riaperto: '+data.notes.strip(),year))
        audit(conn,user,'REOPEN','fiscal_years',year,{'reason':data.notes.strip()})
    return {'year':year,'status':'OPEN'}
