"""Atomic, independent yearly counters for invoice, delivery and SAL records."""
from datetime import date
from fastapi import HTTPException

SOURCES={'FT':'invoice_register','DDT':'delivery_notes','SAL':'progress_certificates','PRE':'quotes','NC':'credit_notes'}


def number_settings(conn,kind):
    row=conn.execute('SELECT prefix,separator,sequence_digits,year_position,reset_yearly FROM document_number_settings WHERE document_type=%s',(kind,)).fetchone()
    return row or {'prefix':kind,'separator':'-','sequence_digits':6,'year_position':'SUFFIX','reset_yearly':True}


def formatted_number(settings,year,value):
    sequence=f"{value:0{settings['sequence_digits']}d}"
    parts=(str(year),settings['prefix'],sequence) if settings['year_position']=='PREFIX' else (settings['prefix'],sequence,str(year))
    return settings['separator'].join(parts)


def current_last(conn,kind,year,settings):
    if settings['reset_yearly']:
        row=conn.execute('SELECT last_number FROM document_sequences WHERE document_type=%s AND document_year=%s',(kind,year)).fetchone()
    else:
        row=conn.execute('SELECT max(last_number) AS last_number FROM document_sequences WHERE document_type=%s',(kind,)).fetchone()
    return int(row['last_number'] or 0) if row else 0


def next_document_number(conn,kind,issued_on):
    if kind not in SOURCES:
        raise ValueError('Tipo documento non valido')
    if not 2000<=issued_on.year<=2100:
        raise HTTPException(400,'Anno documento non valido')
    settings=number_settings(conn,kind)
    conn.execute('SELECT pg_advisory_xact_lock(783461,hashtext(%s))',(kind,))
    while True:
        value=current_last(conn,kind,issued_on.year,settings)+1
        row=conn.execute('INSERT INTO document_sequences(document_type,document_year,last_number) VALUES (%s,%s,%s) '
                         'ON CONFLICT(document_type,document_year) DO UPDATE SET last_number=GREATEST(document_sequences.last_number,EXCLUDED.last_number) RETURNING last_number',
                         (kind,issued_on.year,value)).fetchone()
        value=max(value,int(row['last_number']))
        number=formatted_number(settings,issued_on.year,value)
        if not conn.execute(f'SELECT 1 FROM {SOURCES[kind]} WHERE number=%s LIMIT 1',(number,)).fetchone():
            return number
        conn.execute('UPDATE document_sequences SET last_number=%s WHERE document_type=%s AND document_year=%s',(value,kind,issued_on.year))


def proposed_number(conn,kind,issued_on):
    """Preview only: the final number is reserved on save in the same transaction."""
    if kind not in SOURCES or not 2000 <= issued_on.year <= 2100:
        raise HTTPException(400,'Tipo o anno documento non valido')
    settings=number_settings(conn,kind)
    value=current_last(conn,kind,issued_on.year,settings)+1
    while True:
        candidate=formatted_number(settings,issued_on.year,value)
        if not conn.execute(f'SELECT 1 FROM {SOURCES[kind]} WHERE number=%s LIMIT 1',(candidate,)).fetchone():
            return candidate
        value+=1


def assert_free_number(conn,kind,number,record_id=None):
    if kind not in SOURCES:raise HTTPException(400,'Tipo documento non valido')
    conn.execute('SELECT pg_advisory_xact_lock(783460,hashtext(%s))',(kind+number,))
    row=conn.execute(f'SELECT id FROM {SOURCES[kind]} WHERE number=%s AND id<>%s LIMIT 1',
                     (number,record_id or 0)).fetchone()
    if row:raise HTTPException(409,f'Numero {number} già assegnato al documento {row["id"]}; non può essere riutilizzato')
