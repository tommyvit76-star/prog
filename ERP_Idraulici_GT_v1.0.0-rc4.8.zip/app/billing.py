"""Invoice-owned lines and payment allocation. All mutations share one DB transaction."""
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
import json

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.auth import allowed
from app.catalog import audit
from app.db import connect
from app.quotes import decimal, money, details as quote_details, calculated_unit_price, linked_invoice_for_quote
from app.stock import consume_any
from app.payments import suggested_due_date

router = APIRouter()
CENTS = Decimal('0.01')
VAT_NATURES = {'N1','N2.1','N2.2','N3.1','N3.2','N3.3','N3.4','N3.5','N3.6','N4','N5','N6.1','N6.2','N6.3','N6.4','N6.5','N6.6','N6.7','N6.8','N6.9','N7'}


class LineIn(BaseModel):
    kind: str = 'PRODUCT'
    product_id: int | None = None
    warehouse_id: int | None = None
    position: int = 0
    code: str = ''
    description: str = ''
    duplicate_reason: str = ''
    unit_code: str = 'PZ'
    quantity: str = '1'
    unit_price: str = '0'
    discount_percent: str = '0'
    discount_amount: str = '0'
    vat_rate: str = '22'
    vat_nature: str = ''
    calculation_mode: str = 'MANUAL'
    work_minutes: str = '0'
    workers: int = 1
    hourly_rate: str = '0'
    kilometers: str = '0'
    kilometer_rate: str = '0'


class InstallmentIn(BaseModel):
    percent: str
    base_days: int = 0
    end_of_month: bool = False
    extra_days: int = 0


class PlanIn(BaseModel):
    installments: list[InstallmentIn]


def line_values(data: LineIn):
    values=data.model_dump()
    if data.kind not in ('PRODUCT','SERVICE','DISCOUNT') or len(data.description)>1000:
        raise HTTPException(400,'Tipo o descrizione della riga non validi')
    if data.position<0 or len(data.code)>60 or not data.unit_code.strip():
        raise HTTPException(400,'Posizione, codice o unità non validi')
    values['quantity']=decimal(data.quantity,minimum='0.0001',places=4)
    values['unit_price']=decimal(data.unit_price,places=4)
    values['discount_percent']=decimal(data.discount_percent,maximum='100',places=2)
    values['discount_amount']=decimal(data.discount_amount,maximum='99999999999.99',places=2)
    values['vat_rate']=decimal(data.vat_rate,maximum='100',places=2)
    values['work_minutes']=decimal(data.work_minutes,maximum='99999999999.99',places=2)
    values['hourly_rate']=decimal(data.hourly_rate,maximum='99999999999.9999',places=4)
    values['kilometers']=decimal(data.kilometers,maximum='99999999999.999',places=3)
    values['kilometer_rate']=decimal(data.kilometer_rate,maximum='99999999999.9999',places=4)
    if data.calculation_mode not in ('MANUAL','LABOR','TRAVEL') or not 1<=data.workers<=1000:
        raise HTTPException(400,'Modalità di calcolo o numero addetti non valido')
    if data.calculation_mode!='MANUAL' and data.kind!='SERVICE':
        raise HTTPException(400,'Manodopera e trasferta devono essere righe prestazione')
    if data.calculation_mode=='LABOR':
        if values['work_minutes']<=0 or values['hourly_rate']<0:raise HTTPException(400,'Indica minuti, persone e tariffa della manodopera')
        values['quantity']=Decimal('1');values['unit_price']=(values['work_minutes']/60*data.workers*values['hourly_rate']).quantize(Decimal('.0001'),rounding=ROUND_HALF_UP)
    elif data.calculation_mode=='TRAVEL':
        if values['kilometers']<=0 or values['kilometer_rate']<0:raise HTTPException(400,'Indica chilometri e coefficiente della trasferta')
        values['quantity']=Decimal('1');values['unit_price']=(values['kilometers']*values['kilometer_rate']).quantize(Decimal('.0001'),rounding=ROUND_HALF_UP)
    if (values['vat_rate']==0 and data.vat_nature not in VAT_NATURES) or (values['vat_rate']>0 and data.vat_nature):
        raise HTTPException(400,'Per IVA 0 indica la natura fiscale; con IVA positiva lascia vuota la natura')
    if data.kind=='DISCOUNT':
        values['product_id']=None;values['warehouse_id']=None
        if values['discount_percent'] or values['discount_amount'] or values['unit_price']<=0:
            raise HTTPException(400,'Sconto extra: indica un importo positivo nel prezzo e l’aliquota/natura da scontare')
        taxable=-money(values['quantity']*values['unit_price'])
    else:
        if data.kind=='SERVICE':
            # A line changed from article to service must never retain hidden
            # catalogue/warehouse values. Normalising here also protects API
            # clients and imported legacy rows.
            values['product_id']=None;values['warehouse_id']=None
        if data.warehouse_id and not data.product_id:
            raise HTTPException(400,'Seleziona l’articolo associato al magazzino')
        taxable=money(values['quantity']*values['unit_price']*(1-values['discount_percent']/100)-values['discount_amount'])
        if taxable<0:raise HTTPException(400,'Gli sconti della riga superano l’importo')
    values['taxable']=taxable
    values['vat_amount']=money(taxable*values['vat_rate']/100)
    return values


def installments(total, issue_date, rules):
    if not rules:raise HTTPException(400,'Aggiungi almeno una rata')
    percents=[decimal(str(r['percent']),maximum='100',minimum='0.01',places=2) for r in rules]
    if sum(percents)!=100:raise HTTPException(400,'Le percentuali delle rate devono sommare 100%')
    if len(rules)>12:raise HTTPException(400,'Massimo 12 rate')
    allocated=Decimal('0');out=[]
    for idx,(rule,percent) in enumerate(zip(rules,percents)):
        if not (0<=rule['base_days']<=3650 and 0<=rule['extra_days']<=3650):
            raise HTTPException(400,'Giorni di scadenza non validi')
        amount=money(total*percent/100) if idx<len(rules)-1 else total-allocated
        if amount<=0:raise HTTPException(400,'Rata di importo nullo: modifica la ripartizione')
        allocated+=amount
        out.append((suggested_due_date(issue_date,rule['base_days'],rule['end_of_month'],rule['extra_days']),amount))
    return out


def invoice_totals(conn,invoice_id):
    rows=conn.execute('SELECT vat_rate,vat_nature,taxable,vat_amount FROM invoice_lines WHERE invoice_id=%s',(invoice_id,)).fetchall()
    sources=conn.execute('SELECT taxable,vat_amount FROM invoice_sources WHERE invoice_id=%s',(invoice_id,)).fetchall()
    groups={}
    for row in rows:
        key=(row['vat_rate'],row['vat_nature'])
        groups[key]=groups.get(key,Decimal('0'))+row['taxable']
    from app.workflow import delivery_line_total
    ddt_lines=conn.execute('SELECT l.quantity,l.unit_price,l.discount_percent,l.vat_rate FROM invoice_sources s '
                           'JOIN delivery_lines l ON l.delivery_id=s.delivery_id WHERE s.invoice_id=%s',(invoice_id,)).fetchall()
    for row in ddt_lines:
        key=(row['vat_rate'],'')
        groups[key]=groups.get(key,Decimal('0'))+delivery_line_total(row)
    sal_lines=conn.execute('SELECT s.taxable,p.vat_rate FROM invoice_sources s JOIN progress_certificates p ON p.id=s.sal_id '
                           'WHERE s.invoice_id=%s',(invoice_id,)).fetchall()
    for row in sal_lines:
        key=(row['vat_rate'],'')
        groups[key]=groups.get(key,Decimal('0'))+row['taxable']
    if any(value<0 for value in groups.values()):
        raise HTTPException(409,'Lo sconto supera l’imponibile della corrispondente aliquota IVA')
    taxable=sum((r['taxable'] for r in rows+sources),Decimal('0'))
    vat=sum((money(base*rate/100) for (rate,_),base in groups.items()),Decimal('0'))
    if taxable<0 or taxable+vat<0:raise HTTPException(409,'Totale fattura negativo')
    return money(taxable),money(vat)


def refresh(conn,invoice_id):
    taxable,vat=invoice_totals(conn,invoice_id)
    total=money(taxable+vat)
    allocated=conn.execute("SELECT COALESCE(sum(amount),0) AS total FROM payment_due WHERE invoice_id=%s AND active=true AND status<>'CANCELLED'",(invoice_id,)).fetchone()['total']
    if allocated>total:raise HTTPException(409,'Le scadenze superano il nuovo totale: correggile prima di modificare le righe')
    conn.execute('UPDATE invoice_register SET taxable=%s,vat_amount=%s,total=%s WHERE id=%s',(taxable,vat,total,invoice_id))
    return total


def editable(conn,invoice_id):
    inv=conn.execute('SELECT i.id,i.customer_id,i.casual_customer,i.issue_date,i.total,i.document_status,i.status,i.payment_method_id,f.status fiscal_status FROM invoice_register i JOIN fiscal_years f ON f.year=i.fiscal_year WHERE i.id=%s AND i.active=true FOR UPDATE',(invoice_id,)).fetchone()
    if not inv:raise HTTPException(404,'Fattura non trovata')
    if inv['document_status']!='DRAFT' or inv['status']!='OPEN':
        raise HTTPException(409,'Solo una fattura in bozza e aperta può essere modificata')
    if inv['fiscal_status']!='OPEN':raise HTTPException(409,'Esercizio chiuso: fattura in sola lettura')
    return inv


@router.get('/invoice-register/{invoice_id}/lines')
def list_lines(invoice_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        if not conn.execute('SELECT 1 FROM invoice_register WHERE id=%s AND active=true',(invoice_id,)).fetchone():
            raise HTTPException(404,'Fattura non trovata')
        rows=conn.execute('SELECT * FROM invoice_lines WHERE invoice_id=%s ORDER BY position,id',(invoice_id,)).fetchall()
    return [{**r,**{k:str(r[k]) for k in ('quantity','unit_price','discount_percent','discount_amount','vat_rate','taxable','vat_amount')}} for r in rows]


def save_line(invoice_id,data,user,line_id=None,refresh_totals=True):
    values=line_values(data)
    with connect() as conn:
        editable(conn,invoice_id)
        if data.product_id:
            product=conn.execute('SELECT p.code,p.unit_id FROM products p WHERE p.id=%s AND p.active=true',(data.product_id,)).fetchone()
            if not product:raise HTTPException(400,'Articolo non attivo')
            if data.warehouse_id and not conn.execute('SELECT id FROM warehouses WHERE id=%s AND active=true',(data.warehouse_id,)).fetchone():raise HTTPException(400,'Magazzino non attivo')
            duplicated=conn.execute('SELECT 1 FROM invoice_sources s JOIN delivery_lines l ON l.delivery_id=s.delivery_id '
                                    'WHERE s.invoice_id=%s AND l.product_id=%s LIMIT 1',(invoice_id,data.product_id)).fetchone()
            if duplicated and len(data.duplicate_reason.strip())<8:
                raise HTTPException(409,'Articolo già presente in un DDT collegato: indica perché va fatturato anche separatamente')
        if line_id:
            old=conn.execute('SELECT movement_id FROM invoice_lines WHERE id=%s AND invoice_id=%s FOR UPDATE',(line_id,invoice_id)).fetchone()
            if not old:raise HTTPException(404,'Riga non trovata')
            if old['movement_id']:raise HTTPException(409,'Scarico già registrato: la riga non può cambiare')
        values['invoice_id']=invoice_id
        columns=list(values)
        if line_id:
            row=conn.execute('UPDATE invoice_lines SET '+','.join(f'{c}=%s' for c in columns)+' WHERE id=%s AND invoice_id=%s RETURNING id',(*values.values(),line_id,invoice_id)).fetchone()
        else:
            row=conn.execute('INSERT INTO invoice_lines ('+','.join(columns)+') VALUES ('+','.join(['%s']*len(columns))+') RETURNING id',tuple(values.values())).fetchone()
        if refresh_totals:
            refresh(conn,invoice_id)
        audit(conn,user,'UPDATE' if line_id else 'CREATE','invoice_lines',row['id'])
        return {'id':row['id']}


@router.post('/invoice-register/{invoice_id}/lines',status_code=201)
def create_line(invoice_id:int,data:LineIn,user=Depends(allowed('ADMIN','OFFICE'))):return save_line(invoice_id,data,user)


@router.put('/invoice-register/{invoice_id}/lines/{line_id}')
def update_line(invoice_id:int,line_id:int,data:LineIn,user=Depends(allowed('ADMIN','OFFICE'))):return save_line(invoice_id,data,user,line_id)


@router.delete('/invoice-register/{invoice_id}/lines/{line_id}')
def delete_line(invoice_id:int,line_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        editable(conn,invoice_id)
        row=conn.execute('DELETE FROM invoice_lines WHERE id=%s AND invoice_id=%s AND movement_id IS NULL RETURNING id',(line_id,invoice_id)).fetchone()
        if not row:raise HTTPException(404,'Riga non trovata o già movimentata')
        refresh(conn,invoice_id);audit(conn,user,'DELETE','invoice_lines',line_id)
    return {'ok':True}


@router.post('/invoice-register/{invoice_id}/quote/{quote_id}',status_code=201)
def import_quote(invoice_id:int,quote_id:int,user=Depends(allowed('ADMIN','OFFICE')),multiple=False):
    """Import a quote into a draft invoice while preserving manual rows."""
    with connect() as conn:
        invoice=editable(conn,invoice_id)
        if not invoice['customer_id']:
            raise HTTPException(409,'Un preventivo richiede un cliente registrato')
        quote=quote_details(conn,quote_id)
        if quote['customer_id']!=invoice['customer_id']:
            raise HTTPException(409,'Il preventivo appartiene a un altro cliente')
        if linked_invoice_for_quote(conn,quote_id,invoice_id):
            raise HTTPException(409,'Il preventivo è già stato fatturato in un altro documento')
        if quote['has_ddt']:
            raise HTTPException(409,'Il preventivo è già passato da un DDT: collega quel DDT alla fattura')
        current=conn.execute('SELECT quote_id FROM invoice_register WHERE id=%s',(invoice_id,)).fetchone()
        if not multiple and current['quote_id'] and current['quote_id']!=quote_id:
            raise HTTPException(409,'Dissocia prima il preventivo già collegato')
        if not multiple and conn.execute('SELECT 1 FROM invoice_sources WHERE invoice_id=%s LIMIT 1',(invoice_id,)).fetchone():
            raise HTTPException(409,'La fattura richiama già DDT o SAL: dissociali prima di usare il preventivo diretto')
        if conn.execute('SELECT 1 FROM invoice_lines WHERE invoice_id=%s AND source_quote_id=%s LIMIT 1',(invoice_id,quote_id)).fetchone():
            raise HTTPException(409,'Preventivo già importato nella fattura')
        prepared=[]
        for position,line in enumerate(quote['lines'],1):
            product_id=line['product_id']
            warehouse_id=None
            if product_id and not conn.execute('SELECT id FROM products WHERE id=%s AND active=true',(product_id,)).fetchone():
                raise HTTPException(409,f'Articolo {line["code"] or product_id} non attivo')
            is_discount=line['kind']=='DISCOUNT'
            unit_price=abs(Decimal(str(line['total']))) if is_discount else abs(calculated_unit_price(line,quote).quantize(Decimal('0.0001'),rounding=ROUND_HALF_UP))
            prepared.append(line_values(LineIn(
                kind='DISCOUNT' if is_discount else ('SERVICE' if line['kind']=='SERVICE' else 'PRODUCT'),
                product_id=None if is_discount else product_id,warehouse_id=None if is_discount else warehouse_id,
                position=position,code=line['code'],description=line['description'],unit_code=line['unit_code'],
                quantity='1' if is_discount else str(line['quantity']),unit_price=str(unit_price),vat_rate=str(line['vat_rate'])
            )))
        for description,amount in (('Manodopera da preventivo',quote['manual_labor_cost']),('Trasferta da preventivo',quote['kilometer_total'])):
            if Decimal(str(amount))>0:
                prepared.append(line_values(LineIn(kind='SERVICE',position=len(prepared)+1,description=description,
                                                   unit_code='NR',quantity='1',unit_price=str(amount),vat_rate='22')))
        if not prepared:
            raise HTTPException(409,'Il preventivo non contiene importi fatturabili')
        for values in prepared:
            values.update(invoice_id=invoice_id,source_quote_id=quote_id)
            columns=list(values)
            conn.execute('INSERT INTO invoice_lines ('+','.join(columns)+') VALUES ('+','.join(['%s']*len(columns))+')',tuple(values.values()))
        if not multiple:conn.execute('UPDATE invoice_register SET quote_id=%s WHERE id=%s',(quote_id,invoice_id))
        refresh(conn,invoice_id)
        audit(conn,user,'LINK','invoice_quote',invoice_id,{'quote_id':quote_id})
    return {'ok':True}


@router.delete('/invoice-register/{invoice_id}/quote')
def unlink_quote(invoice_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        editable(conn,invoice_id)
        current=conn.execute('SELECT quote_id FROM invoice_register WHERE id=%s FOR UPDATE',(invoice_id,)).fetchone()
        if not current['quote_id']:
            raise HTTPException(404,'Nessun preventivo collegato')
        quote_id=current['quote_id']
        removed=conn.execute('DELETE FROM invoice_lines WHERE invoice_id=%s AND source_quote_id=%s RETURNING id',(invoice_id,quote_id)).fetchall()
        conn.execute('UPDATE invoice_register SET quote_id=NULL WHERE id=%s',(invoice_id,))
        refresh(conn,invoice_id)
        audit(conn,user,'UNLINK','invoice_quote',invoice_id,{'quote_id':quote_id,'removed_lines':len(removed)})
    return {'ok':True,'removed_lines':len(removed)}


@router.get('/payment-methods/{method_id}/installments')
def get_plan(method_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        return conn.execute('SELECT percent,base_days,end_of_month,extra_days FROM payment_method_installments WHERE payment_method_id=%s ORDER BY position',(method_id,)).fetchall()


@router.put('/payment-methods/{method_id}/installments')
def set_plan(method_id:int,data:PlanIn,user=Depends(allowed('ADMIN','OFFICE'))):
    rules=[r.model_dump() for r in data.installments]
    installments(Decimal('100.00'),date.today(),rules)
    with connect() as conn:
        if not conn.execute('SELECT 1 FROM payment_methods WHERE id=%s AND active=true FOR UPDATE',(method_id,)).fetchone():
            raise HTTPException(404,'Modalità di pagamento non trovata')
        conn.execute('DELETE FROM payment_method_installments WHERE payment_method_id=%s',(method_id,))
        for idx,rule in enumerate(rules,1):
            conn.execute('INSERT INTO payment_method_installments(payment_method_id,position,percent,base_days,end_of_month,extra_days) VALUES (%s,%s,%s,%s,%s,%s)',
                         (method_id,idx,decimal(rule['percent'],maximum='100',minimum='0.01',places=2),rule['base_days'],rule['end_of_month'],rule['extra_days']))
        audit(conn,user,'UPDATE','payment_method_installments',method_id)
    return {'ok':True}


@router.post('/invoice-register/{invoice_id}/confirm')
def confirm_invoice(invoice_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        inv=editable(conn,invoice_id)
        if not conn.execute('SELECT 1 FROM invoice_lines WHERE invoice_id=%s UNION ALL SELECT 1 FROM invoice_sources WHERE invoice_id=%s LIMIT 1',(invoice_id,invoice_id)).fetchone():
            raise HTTPException(409,'Aggiungi articoli/prestazioni oppure collega un DDT o SAL')
        has_lines=bool(conn.execute('SELECT 1 FROM invoice_lines WHERE invoice_id=%s LIMIT 1',(invoice_id,)).fetchone())
        has_sources=bool(conn.execute('SELECT 1 FROM invoice_sources WHERE invoice_id=%s LIMIT 1',(invoice_id,)).fetchone())
        total=refresh(conn,invoice_id)
        if total<=0:raise HTTPException(409,'La fattura deve avere un totale positivo')
        if conn.execute('SELECT 1 FROM payment_due WHERE invoice_id=%s AND active=true LIMIT 1',(invoice_id,)).fetchone():
            raise HTTPException(409,'Scadenze già presenti: completa o correggi le scadenze prima di confermare')
        if inv['payment_method_id']:
            rules=conn.execute('SELECT percent,base_days,end_of_month,extra_days FROM payment_method_installments WHERE payment_method_id=%s ORDER BY position',(inv['payment_method_id'],)).fetchall()
            if not rules:
                method=conn.execute('SELECT default_days AS base_days,end_of_month,extra_days FROM payment_methods WHERE id=%s',(inv['payment_method_id'],)).fetchone()
                rules=[{'percent':'100','base_days':method['base_days'],'end_of_month':method['end_of_month'],'extra_days':method['extra_days']}]
        else:rules=[{'percent':'100','base_days':0,'end_of_month':False,'extra_days':0}]
        for due_on,amount in installments(total,inv['issue_date'],rules):
            conn.execute('INSERT INTO payment_due(invoice_id,payment_method_id,due_date,amount,status,generated) VALUES (%s,%s,%s,%s,%s,true)',
                         (invoice_id,inv['payment_method_id'],due_on,amount,'OPEN'))
        lines=conn.execute("SELECT id,product_id,warehouse_id,quantity FROM invoice_lines WHERE invoice_id=%s AND kind='PRODUCT' AND product_id IS NOT NULL ORDER BY id FOR UPDATE",(invoice_id,)).fetchall()
        for line in lines:
            try:movements=consume_any(conn,product_id=line['product_id'],amount=str(line['quantity']),actor=user['username'],reason=f'Fattura immediata {invoice_id}, riga {line["id"]}')
            except ValueError as exc:raise HTTPException(409,str(exc)) from exc
            conn.execute('UPDATE invoice_lines SET movement_id=%s WHERE id=%s',(movements[0]['id'],line['id']))
        kind='MIXED' if has_lines and has_sources else 'IMMEDIATE' if has_lines else 'SUMMARY'
        company=conn.execute('SELECT name,vat_number,address,postal_code,city,province,phone,email,fiscal_regime,tax_code,country,logo_data FROM company_settings WHERE id=1').fetchone()
        customer=conn.execute('SELECT id,name,vat_number,tax_code,address,postal_code,city,province,sdi_code,pec FROM customers WHERE id=%s',(inv['customer_id'],)).fetchone() if inv['customer_id'] else inv['casual_customer']
        if not company or not customer:raise HTTPException(409,'Dati azienda o cliente mancanti')
        company_fields={key:company[key] for key in company if key!='logo_data'}
        conn.execute("UPDATE invoice_register SET document_status='CONFIRMED',invoice_kind=%s,company_snapshot=%s::jsonb,customer_snapshot=%s::jsonb,logo_snapshot=%s WHERE id=%s",
                     (kind,json.dumps(company_fields),json.dumps(dict(customer)),company['logo_data'],invoice_id))
        conn.execute("UPDATE progress_certificates p SET approval_status='INVOICED' WHERE p.id IN (SELECT s.sal_id FROM invoice_sources s WHERE s.invoice_id=%s AND s.sal_id IS NOT NULL) AND (SELECT COALESCE(sum(x.taxable),0) FROM invoice_sources x JOIN invoice_register i ON i.id=x.invoice_id WHERE x.sal_id=p.id AND i.document_status='CONFIRMED') >= p.amount+p.variation_amount-p.retention_amount-p.advance_recovery",(invoice_id,))
        audit(conn,user,'CONFIRM','invoice_register',invoice_id,{'total':str(total)})
    return {'id':invoice_id,'total':str(total)}
