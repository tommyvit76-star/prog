"""Professional transport setup, project sites and invoice-linked credit notes."""
from datetime import date
from decimal import Decimal
import json

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel

from app.auth import allowed
from app.catalog import audit
from app.db import connect
from app.numbering import next_document_number, assert_free_number
from app.quotes import decimal, money, details as quote_details, linked_invoice_for_quote
from app.stock import move, automatic_warehouse
from app.fiscal_years import assert_open

router=APIRouter()
CONFIG_TABLES={'reasons':'transport_reasons','appearances':'goods_appearances','ports':'port_terms','modes':'transport_modes'}


class ConfigIn(BaseModel):
    name:str
    invoiceable:bool=False
    stock_action:str='NONE'
    requires_return:bool=False


@router.get('/admin/transport-config/{kind}')
def config_list(kind:str,user=Depends(allowed('ADMIN','OFFICE'))):
    table=CONFIG_TABLES.get(kind)
    if not table:raise HTTPException(404,'Configurazione non trovata')
    with connect() as conn:return conn.execute(f'SELECT * FROM {table} WHERE active=true ORDER BY name').fetchall()


def save_config(kind,data,user,record_id=None):
    table=CONFIG_TABLES.get(kind)
    if not table or not data.name.strip():raise HTTPException(400,'Configurazione non valida')
    with connect() as conn:
        if kind=='reasons':
            if data.stock_action not in ('NONE','CONSUME','LOAD'):raise HTTPException(400,'Movimento magazzino non valido')
            values=(data.name.strip(),data.invoiceable,data.stock_action,data.requires_return)
            if record_id:row=conn.execute(f'UPDATE {table} SET name=%s,invoiceable=%s,stock_action=%s,requires_return=%s WHERE id=%s AND active=true RETURNING id',(*values,record_id)).fetchone()
            else:row=conn.execute(f'INSERT INTO {table}(name,invoiceable,stock_action,requires_return) VALUES (%s,%s,%s,%s) RETURNING id',values).fetchone()
        else:
            if record_id:row=conn.execute(f'UPDATE {table} SET name=%s WHERE id=%s AND active=true RETURNING id',(data.name.strip(),record_id)).fetchone()
            else:row=conn.execute(f'INSERT INTO {table}(name) VALUES (%s) RETURNING id',(data.name.strip(),)).fetchone()
        if not row:raise HTTPException(404,'Valore non trovato')
        audit(conn,user,'UPDATE' if record_id else 'CREATE',table,row['id']);return {'id':row['id']}


@router.post('/admin/transport-config/{kind}',status_code=201)
def config_add(kind:str,data:ConfigIn,user=Depends(allowed('ADMIN'))):return save_config(kind,data,user)


@router.put('/admin/transport-config/{kind}/{record_id}')
def config_edit(kind:str,record_id:int,data:ConfigIn,user=Depends(allowed('ADMIN'))):return save_config(kind,data,user,record_id)


@router.delete('/admin/transport-config/{kind}/{record_id}')
def config_archive(kind:str,record_id:int,user=Depends(allowed('ADMIN'))):
    table=CONFIG_TABLES.get(kind)
    if not table:raise HTTPException(404,'Configurazione non trovata')
    with connect() as conn:
        row=conn.execute(f'UPDATE {table} SET active=false WHERE id=%s AND active=true RETURNING id',(record_id,)).fetchone()
        if not row:raise HTTPException(404,'Valore non trovato')
        audit(conn,user,'ARCHIVE',table,record_id)
    return {'ok':True}


class CarrierIn(BaseModel):
    name:str;vat_number:str='';address:str='';postal_code:str='';city:str='';province:str='';driver_name:str='';vehicle_plate:str=''


@router.get('/carriers')
def carriers(user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:return conn.execute('SELECT * FROM carriers WHERE active=true ORDER BY name').fetchall()


def save_carrier(data,user,record_id=None):
    values=data.model_dump();values={k:v.strip() for k,v in values.items()}
    if not values['name']:raise HTTPException(400,'Ragione sociale vettore obbligatoria')
    with connect() as conn:
        cols=list(values)
        if record_id:row=conn.execute('UPDATE carriers SET '+','.join(c+'=%s' for c in cols)+' WHERE id=%s AND active=true RETURNING id',(*values.values(),record_id)).fetchone()
        else:row=conn.execute('INSERT INTO carriers('+','.join(cols)+') VALUES ('+','.join(['%s']*len(cols))+') RETURNING id',tuple(values.values())).fetchone()
        if not row:raise HTTPException(404,'Vettore non trovato')
        audit(conn,user,'UPDATE' if record_id else 'CREATE','carriers',row['id']);return {'id':row['id']}


@router.post('/carriers',status_code=201)
def carrier_add(data:CarrierIn,user=Depends(allowed('ADMIN'))):return save_carrier(data,user)
@router.put('/carriers/{record_id}')
def carrier_edit(record_id:int,data:CarrierIn,user=Depends(allowed('ADMIN'))):return save_carrier(data,user,record_id)
@router.delete('/carriers/{record_id}')
def carrier_archive(record_id:int,user=Depends(allowed('ADMIN'))):
    with connect() as conn:
        row=conn.execute('UPDATE carriers SET active=false WHERE id=%s AND active=true RETURNING id',(record_id,)).fetchone()
        if not row:raise HTTPException(404,'Vettore non trovato')
        audit(conn,user,'ARCHIVE','carriers',record_id)
    return {'ok':True}


class ProjectIn(BaseModel):
    code:str;name:str;customer_id:int;address:str='';quote_id:int|None=None;contract_value:str='0';variation_value:str='0'
    manager:str='';planned_start:date|None=None;actual_start:date|None=None;planned_end:date|None=None;actual_end:date|None=None
    status:str='PLANNED';technical_notes:str='';administrative_notes:str=''
    contract_type:str='PRIVATE';contract_number:str='';contract_date:date|None=None;cup:str='';cig:str=''
    vat_regime:str='ORDINARY';safety_costs:str='0';contract_discount_percent:str='0';advance_amount:str='0'
    retention_percent:str='0';works_director:str='';rup:str=''


def project_detail(conn,project_id):
    p=conn.execute('SELECT * FROM project_sites WHERE id=%s AND active=true',(project_id,)).fetchone()
    if not p:raise HTTPException(404,'Cantiere non trovato')
    sal=conn.execute('SELECT COALESCE(sum(amount+variation_amount-retention_amount-advance_recovery),0) amount,COALESCE(sum(percent),0) percent FROM progress_certificates WHERE project_id=%s AND active=true',(project_id,)).fetchone()
    invoiced=conn.execute('SELECT COALESCE(sum(total),0) total FROM invoice_register WHERE project_id=%s AND active=true AND document_status=%s',(project_id,'CONFIRMED')).fetchone()['total']
    credited=conn.execute("SELECT COALESCE(sum(c.total),0) total FROM credit_notes c JOIN invoice_register i ON i.id=c.original_invoice_id WHERE i.project_id=%s AND c.active=true AND c.status='CONFIRMED'",(project_id,)).fetchone()['total']
    paid=conn.execute("SELECT COALESCE(sum(d.amount),0) total FROM payment_due d JOIN invoice_register i ON i.id=d.invoice_id WHERE i.project_id=%s AND d.active=true AND d.status='PAID'",(project_id,)).fetchone()['total']
    ddt=conn.execute('SELECT count(*) count FROM delivery_notes WHERE project_id=%s AND active=true',(project_id,)).fetchone()['count']
    result=dict(p);contract=money(p['contract_value']+p['variation_value'])
    result.update(contract_total=str(contract),sal_amount=str(sal['amount']),sal_percent=str(sal['percent']),invoiced=str(invoiced-credited),credited=str(credited),paid=str(paid),
                  remaining_to_sal=str(money(max(Decimal(0),contract-sal['amount']))),ddt_count=ddt)
    result['quotes']=conn.execute('SELECT q.id,q.number,q.issue_date,q.title,q.status FROM project_quote_links l JOIN quotes q ON q.id=l.quote_id WHERE l.project_id=%s AND q.active=true ORDER BY q.issue_date,q.id',(project_id,)).fetchall()
    result['sals']=conn.execute('SELECT id,number,issued_on,sequence_no,approval_status FROM progress_certificates WHERE project_id=%s AND active=true ORDER BY sequence_no,id',(project_id,)).fetchall()
    for key in ('contract_value','variation_value'):result[key]=str(result[key])
    return result


@router.get('/projects')
def projects(user=Depends(allowed('ADMIN','OFFICE','TECHNICIAN'))):
    with connect() as conn:
        ids=conn.execute('SELECT id FROM project_sites WHERE active=true ORDER BY id DESC LIMIT 500').fetchall()
        return [project_detail(conn,r['id']) for r in ids]
@router.get('/projects/{project_id}')
def project(project_id:int,user=Depends(allowed('ADMIN','OFFICE','TECHNICIAN'))):
    with connect() as conn:return project_detail(conn,project_id)


def save_project(data,user,project_id=None):
    values=data.model_dump();values['code']=values['code'].strip();values['name']=values['name'].strip();values['contract_number']=values['contract_number'].strip()
    values['contract_value']=decimal(data.contract_value,places=2);values['variation_value']=decimal(data.variation_value,minimum='-99999999999.99',places=2)
    for key in ('safety_costs','advance_amount'):values[key]=decimal(getattr(data,key),places=2)
    for key in ('contract_discount_percent','retention_percent'):values[key]=decimal(getattr(data,key),maximum='100',places=2)
    if data.contract_type not in ('PRIVATE','PUBLIC') or data.vat_regime not in ('ORDINARY','REVERSE_CHARGE','SPLIT_PAYMENT'):
        raise HTTPException(400,'Tipo contratto o regime IVA non valido')
    if not values['code'] or not values['name'] or data.status not in ('PLANNED','OPEN','SUSPENDED','COMPLETED','INVOICED','CLOSED'):raise HTTPException(400,'Dati cantiere non validi')
    with connect() as conn:
        conn.execute('SELECT pg_advisory_xact_lock(783471)')
        if values['contract_number'] and conn.execute('SELECT 1 FROM project_sites WHERE active=true AND id<>%s AND lower(trim(contract_number))=lower(trim(%s))',(project_id or 0,values['contract_number'])).fetchone():
            raise HTTPException(409,'Numero di contratto già presente')
        old=conn.execute('SELECT quote_id,customer_id FROM project_sites WHERE id=%s AND active=true FOR UPDATE',(project_id,)).fetchone() if project_id else None
        if project_id and not old:raise HTTPException(404,'Cantiere non trovato')
        if old and (old['quote_id']!=data.quote_id or old['customer_id']!=data.customer_id) and conn.execute('SELECT 1 FROM delivery_notes WHERE project_id=%s AND active=true UNION ALL SELECT 1 FROM progress_certificates WHERE project_id=%s AND active=true UNION ALL SELECT 1 FROM invoice_register WHERE project_id=%s AND active=true LIMIT 1',(project_id,project_id,project_id)).fetchone():
            raise HTTPException(409,'Cantiere con documenti: non puoi cambiare cliente o dissociare il preventivo')
        customer=conn.execute('SELECT name FROM customers WHERE id=%s AND active=true',(data.customer_id,)).fetchone()
        if not customer:raise HTTPException(400,'Cliente non trovato')
        if data.quote_id:
            quote=quote_details(conn,data.quote_id)
            if quote['customer_id']!=data.customer_id:raise HTTPException(400,'Preventivo di un altro cliente')
            if quote['linked_invoice'] and (not old or old['quote_id']!=data.quote_id):
                raise HTTPException(409,'Preventivo già fatturato: non può essere associato a un nuovo cantiere')
            if values['contract_value']==0:values['contract_value']=Decimal(quote['subtotal'])
        values['customer_name']=customer['name'];cols=list(values)
        if project_id:row=conn.execute('UPDATE project_sites SET '+','.join(c+'=%s' for c in cols)+' WHERE id=%s AND active=true RETURNING id',(*values.values(),project_id)).fetchone()
        else:row=conn.execute('INSERT INTO project_sites('+','.join(cols)+') VALUES ('+','.join(['%s']*len(cols))+') RETURNING id',tuple(values.values())).fetchone()
        if not row:raise HTTPException(404,'Cantiere non trovato')
        if data.quote_id:conn.execute('INSERT INTO project_quote_links(project_id,quote_id) VALUES (%s,%s) ON CONFLICT DO NOTHING',(row['id'],data.quote_id))
        audit(conn,user,'UPDATE' if project_id else 'CREATE','project_sites',row['id']);return project_detail(conn,row['id'])


@router.post('/projects',status_code=201)
def project_add(data:ProjectIn,user=Depends(allowed('ADMIN','OFFICE'))):return save_project(data,user)
@router.put('/projects/{project_id}')
def project_edit(project_id:int,data:ProjectIn,user=Depends(allowed('ADMIN','OFFICE'))):return save_project(data,user,project_id)

@router.post('/projects/{project_id}/quotes/{quote_id}')
def project_link_quote(project_id:int,quote_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        project=conn.execute('SELECT customer_id FROM project_sites WHERE id=%s AND active=true',(project_id,)).fetchone()
        quote=conn.execute('SELECT customer_id FROM quotes WHERE id=%s AND active=true',(quote_id,)).fetchone()
        if not project or not quote:raise HTTPException(404,'Cantiere o preventivo non trovato')
        if project['customer_id']!=quote['customer_id']:raise HTTPException(409,'Il preventivo appartiene a un altro cliente')
        if conn.execute('SELECT 1 FROM project_quote_links WHERE project_id=%s AND quote_id=%s',(project_id,quote_id)).fetchone():
            return project_detail(conn,project_id)
        if linked_invoice_for_quote(conn,quote_id):raise HTTPException(409,'Preventivo già fatturato: non può essere associato al cantiere')
        conn.execute('INSERT INTO project_quote_links(project_id,quote_id) VALUES (%s,%s) ON CONFLICT DO NOTHING',(project_id,quote_id))
        audit(conn,user,'LINK','project_quote',project_id,{'quote_id':quote_id})
        return project_detail(conn,project_id)

@router.post('/projects/{project_id}/sals/{sal_id}')
def project_link_sal(project_id:int,sal_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        project=conn.execute('SELECT customer_id FROM project_sites WHERE id=%s AND active=true',(project_id,)).fetchone()
        sal=conn.execute('SELECT customer_id,project_id,approval_status FROM progress_certificates WHERE id=%s AND active=true FOR UPDATE',(sal_id,)).fetchone()
        if not project or not sal:raise HTTPException(404,'Cantiere o SAL non trovato')
        if project['customer_id']!=sal['customer_id']:raise HTTPException(409,'Il SAL appartiene a un altro cliente')
        if sal['project_id'] and sal['project_id']!=project_id:raise HTTPException(409,'Il SAL è già associato a un altro cantiere')
        if sal['approval_status']=='INVOICED':raise HTTPException(409,'Il SAL è già fatturato')
        conn.execute('UPDATE progress_certificates SET project_id=%s WHERE id=%s',(project_id,sal_id))
        audit(conn,user,'LINK','project_sal',project_id,{'sal_id':sal_id})
        return project_detail(conn,project_id)

@router.delete('/projects/{project_id}/quotes/{quote_id}')
def project_unlink_quote(project_id:int,quote_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        link=conn.execute('SELECT 1 FROM project_quote_links WHERE project_id=%s AND quote_id=%s FOR UPDATE',(project_id,quote_id)).fetchone()
        if not link:raise HTTPException(404,'Preventivo non associato al cantiere')
        if conn.execute('SELECT 1 FROM delivery_lines l JOIN delivery_notes d ON d.id=l.delivery_id WHERE l.quote_line_id IN (SELECT id FROM quote_lines WHERE quote_id=%s) AND d.active=true UNION ALL SELECT 1 FROM progress_certificates WHERE quote_id=%s AND active=true UNION ALL SELECT 1 FROM invoice_references WHERE quote_id=%s LIMIT 1',(quote_id,quote_id,quote_id)).fetchone():
            raise HTTPException(409,'Preventivo già usato: rimuovi prima DDT, SAL o fatture collegati')
        conn.execute('DELETE FROM project_quote_links WHERE project_id=%s AND quote_id=%s',(project_id,quote_id))
        conn.execute('UPDATE project_sites SET quote_id=NULL WHERE id=%s AND quote_id=%s',(project_id,quote_id))
        audit(conn,user,'UNLINK','project_quote',project_id,{'quote_id':quote_id})
        return project_detail(conn,project_id)

@router.delete('/projects/{project_id}/sals/{sal_id}')
def project_unlink_sal(project_id:int,sal_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        sal=conn.execute('SELECT approval_status FROM progress_certificates WHERE id=%s AND project_id=%s AND active=true FOR UPDATE',(sal_id,project_id)).fetchone()
        if not sal:raise HTTPException(404,'SAL non associato al cantiere')
        if sal['approval_status']=='INVOICED' or conn.execute('SELECT 1 FROM invoice_sources WHERE sal_id=%s UNION ALL SELECT 1 FROM invoice_references WHERE sal_id=%s LIMIT 1',(sal_id,sal_id)).fetchone():
            raise HTTPException(409,'SAL già fatturato o richiamato: non può essere dissociato')
        conn.execute('UPDATE progress_certificates SET project_id=NULL WHERE id=%s',(sal_id,))
        audit(conn,user,'UNLINK','project_sal',project_id,{'sal_id':sal_id})
        return project_detail(conn,project_id)
@router.delete('/projects/{project_id}')
def project_archive(project_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        if conn.execute('SELECT 1 FROM delivery_notes WHERE project_id=%s AND active=true UNION ALL SELECT 1 FROM progress_certificates WHERE project_id=%s AND active=true UNION ALL SELECT 1 FROM invoice_register WHERE project_id=%s AND active=true LIMIT 1',(project_id,project_id,project_id)).fetchone():raise HTTPException(409,'Cantiere con documenti: chiudilo ma non eliminarlo')
        row=conn.execute('UPDATE project_sites SET active=false WHERE id=%s AND active=true RETURNING id',(project_id,)).fetchone()
        if not row:raise HTTPException(404,'Cantiere non trovato')
        audit(conn,user,'ARCHIVE','project_sites',project_id)
    return {'ok':True}


class CreditCreate(BaseModel):
    original_invoice_id:int;issue_date:date;number:str='';cause:str;notes:str=''
class CreditLineEdit(BaseModel):
    quantity:str;restock:bool=False;warehouse_id:int|None=None


def credit_detail(conn,note_id):
    n=conn.execute('SELECT c.*,i.number original_invoice_number,i.issue_date original_invoice_date FROM credit_notes c JOIN invoice_register i ON i.id=c.original_invoice_id WHERE c.id=%s AND c.active=true',(note_id,)).fetchone()
    if not n:raise HTTPException(404,'Nota di credito non trovata')
    lines=conn.execute('SELECT * FROM credit_note_lines WHERE credit_note_id=%s ORDER BY position,id',(note_id,)).fetchall();out=dict(n)
    out['lines']=[{**r,**{k:str(r[k]) for k in ('quantity','unit_price','discount_percent','vat_rate','taxable','vat_amount')}} for r in lines]
    if n['status']=='DRAFT':
        out['taxable']=sum((r['taxable'] for r in lines),Decimal(0))
        out['vat_amount']=sum((r['vat_amount'] for r in lines),Decimal(0))
        out['total']=out['taxable']+out['vat_amount']
    for key in ('taxable','vat_amount','total'):out[key]=str(out[key])
    return out


@router.get('/credit-notes')
def credit_notes(user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        ids=conn.execute('SELECT id FROM credit_notes WHERE active=true AND fiscal_year=%s ORDER BY issue_date DESC,id DESC',(user['selected_fiscal_year'],)).fetchall();return [credit_detail(conn,r['id']) for r in ids]
@router.get('/credit-notes/{note_id}')
def credit_note(note_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:return credit_detail(conn,note_id)


@router.post('/credit-notes',status_code=201)
def credit_create(data:CreditCreate,user=Depends(allowed('ADMIN','OFFICE'))):
    if not data.cause.strip():raise HTTPException(400,'Causale nota di credito obbligatoria')
    with connect() as conn:
        assert_open(conn,data.issue_date)
        inv=conn.execute("SELECT * FROM invoice_register WHERE id=%s AND active=true AND document_status='CONFIRMED' FOR UPDATE",(data.original_invoice_id,)).fetchone()
        if not inv:raise HTTPException(409,'Seleziona una fattura confermata')
        number=data.number.strip() or next_document_number(conn,'NC',data.issue_date);assert_free_number(conn,'NC',number)
        if data.number.strip() and user['role']!='ADMIN':raise HTTPException(403,'Solo l’amministratore può forzare il numero')
        row=conn.execute('INSERT INTO credit_notes(original_invoice_id,customer_id,customer_name,number,issue_date,cause,notes,fiscal_year) VALUES (%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id',(inv['id'],inv['customer_id'],inv['customer_name'],number,data.issue_date,data.cause.strip(),data.notes,data.issue_date.year)).fetchone()
        lines=conn.execute('SELECT * FROM invoice_lines WHERE invoice_id=%s ORDER BY position,id',(inv['id'],)).fetchall()
        for line in lines:
            taxable=line['taxable'];vat=line['vat_amount']
            conn.execute('INSERT INTO credit_note_lines(credit_note_id,original_invoice_line_id,position,kind,product_id,code,description,unit_code,quantity,unit_price,discount_percent,vat_rate,vat_nature,taxable,vat_amount) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)',(row['id'],line['id'],line['position'],line['kind'],line['product_id'],line['code'],line['description'],line['unit_code'],line['quantity'],line['unit_price'],line['discount_percent'],line['vat_rate'],line['vat_nature'],taxable,vat))
        sources=conn.execute('SELECT taxable,vat_amount,CASE WHEN taxable=0 THEN 0 ELSE round(vat_amount/taxable*100,2) END vat_rate,COALESCE(d.number,p.number) number FROM invoice_sources s LEFT JOIN delivery_notes d ON d.id=s.delivery_id LEFT JOIN progress_certificates p ON p.id=s.sal_id WHERE s.invoice_id=%s',(inv['id'],)).fetchall()
        for idx,line in enumerate(sources,len(lines)+1):conn.execute("INSERT INTO credit_note_lines(credit_note_id,position,code,description,unit_code,quantity,unit_price,vat_rate,taxable,vat_amount) VALUES (%s,%s,'',%s,'NR',1,%s,%s,%s,%s)",(row['id'],idx,'Storno documento '+line['number'],line['taxable'],line['vat_rate'],line['taxable'],line['vat_amount']))
        audit(conn,user,'CREATE','credit_notes',row['id']);return credit_detail(conn,row['id'])


@router.put('/credit-notes/{note_id}/lines/{line_id}')
def credit_line(note_id:int,line_id:int,data:CreditLineEdit,user=Depends(allowed('ADMIN','OFFICE'))):
    qty=decimal(data.quantity,minimum='0.0001',places=4)
    with connect() as conn:
        note=conn.execute("SELECT c.status,f.status fiscal_status FROM credit_notes c JOIN fiscal_years f ON f.year=c.fiscal_year WHERE c.id=%s AND c.active=true FOR UPDATE",(note_id,)).fetchone()
        if note and note['fiscal_status']!='OPEN':raise HTTPException(409,'Esercizio chiuso: nota in sola lettura')
        if not note or note['status']!='DRAFT':raise HTTPException(409,'Solo la nota in bozza è modificabile')
        line=conn.execute('SELECT * FROM credit_note_lines WHERE id=%s AND credit_note_id=%s',(line_id,note_id)).fetchone()
        if not line:raise HTTPException(404,'Riga non trovata')
        if qty>line['quantity'] and line['original_invoice_line_id'] is None:raise HTTPException(409,'Quantità superiore alla riga originaria')
        original=conn.execute('SELECT quantity,unit_price,discount_percent,vat_rate,taxable FROM invoice_lines WHERE id=%s',(line['original_invoice_line_id'],)).fetchone() if line['original_invoice_line_id'] else None
        if original and qty>original['quantity']:raise HTTPException(409,'Quantità superiore alla fattura originaria')
        unit=original['unit_price'] if original else line['unit_price'];discount=original['discount_percent'] if original else line['discount_percent'];rate=original['vat_rate'] if original else line['vat_rate']
        taxable=money(original['taxable']*qty/original['quantity']) if original else money(line['taxable']*qty/line['quantity'])
        vat=money(taxable*rate/100)
        if data.restock and not line['product_id']:raise HTTPException(400,'La riga non contiene un articolo da rimettere in giacenza')
        try:warehouse_id=automatic_warehouse(conn,line['product_id']) if data.restock else None
        except ValueError as exc:raise HTTPException(400,str(exc)) from exc
        conn.execute('UPDATE credit_note_lines SET quantity=%s,restock=%s,warehouse_id=%s,taxable=%s,vat_amount=%s WHERE id=%s',(qty,data.restock,warehouse_id,taxable,vat,line_id));audit(conn,user,'UPDATE','credit_note_lines',line_id);return credit_detail(conn,note_id)


@router.delete('/credit-notes/{note_id}/lines/{line_id}')
def credit_line_delete(note_id:int,line_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        state=conn.execute('SELECT f.status FROM credit_notes c JOIN fiscal_years f ON f.year=c.fiscal_year WHERE c.id=%s',(note_id,)).fetchone()
        if state and state['status']!='OPEN':raise HTTPException(409,'Esercizio chiuso: nota in sola lettura')
        row=conn.execute("DELETE FROM credit_note_lines USING credit_notes WHERE credit_note_lines.id=%s AND credit_note_lines.credit_note_id=%s AND credit_notes.id=credit_note_lines.credit_note_id AND credit_notes.status='DRAFT' RETURNING credit_note_lines.id",(line_id,note_id)).fetchone()
        if not row:raise HTTPException(409,'Riga non trovata o nota già confermata')
        audit(conn,user,'DELETE','credit_note_lines',line_id)
    return {'ok':True}


@router.post('/credit-notes/{note_id}/confirm')
def credit_confirm(note_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        note=conn.execute("SELECT c.* FROM credit_notes c JOIN fiscal_years f ON f.year=c.fiscal_year WHERE c.id=%s AND c.active=true AND f.status='OPEN' FOR UPDATE",(note_id,)).fetchone()
        if not note or note['status']!='DRAFT':raise HTTPException(409,'Nota non trovata o già confermata')
        inv=conn.execute('SELECT * FROM invoice_register WHERE id=%s FOR UPDATE',(note['original_invoice_id'],)).fetchone()
        lines=conn.execute('SELECT * FROM credit_note_lines WHERE credit_note_id=%s ORDER BY id FOR UPDATE',(note_id,)).fetchall()
        if not lines:raise HTTPException(409,'La nota di credito non contiene righe')
        taxable=money(sum((r['taxable'] for r in lines),Decimal(0)));vat=money(sum((r['vat_amount'] for r in lines),Decimal(0)));total=money(taxable+vat)
        already=conn.execute("SELECT COALESCE(sum(total),0) total FROM credit_notes WHERE original_invoice_id=%s AND status='CONFIRMED' AND active=true",(inv['id'],)).fetchone()['total']
        if total<=0 or already+total>inv['total']:raise HTTPException(409,'Importo superiore al residuo accreditabile della fattura')
        for line in lines:
            if line['original_invoice_line_id']:
                used=conn.execute("SELECT COALESCE(sum(l.quantity),0) qty FROM credit_note_lines l JOIN credit_notes c ON c.id=l.credit_note_id WHERE l.original_invoice_line_id=%s AND c.status='CONFIRMED' AND c.active=true",(line['original_invoice_line_id'],)).fetchone()['qty']
                original=conn.execute('SELECT quantity FROM invoice_lines WHERE id=%s',(line['original_invoice_line_id'],)).fetchone()
                if used+line['quantity']>original['quantity']:raise HTTPException(409,'Una riga supera la quantità ancora accreditabile')
            if line['restock']:
                movement=move(conn,product_id=line['product_id'],source_id=None,destination_id=line['warehouse_id'],amount=str(line['quantity']),kind='LOAD',actor=user['username'],reason=f'Nota di credito {note["number"]}, riga {line["id"]}')
                conn.execute('UPDATE credit_note_lines SET movement_id=%s WHERE id=%s',(movement['id'],line['id']))
        remaining=total
        dues=conn.execute("SELECT id,amount FROM payment_due WHERE invoice_id=%s AND active=true AND status='OPEN' ORDER BY due_date DESC,id DESC FOR UPDATE",(inv['id'],)).fetchall()
        for due in dues:
            if remaining<=0:break
            if remaining>=due['amount']:
                conn.execute("UPDATE payment_due SET status='CANCELLED',notes=concat_ws(' · ',NULLIF(notes,''),%s) WHERE id=%s",(f'Stornata da nota {note["number"]}',due['id']));remaining-=due['amount']
            else:
                conn.execute('UPDATE payment_due SET amount=amount-%s,date_overridden=true,notes=concat_ws(\' · \',NULLIF(notes,\'\'),%s) WHERE id=%s',(remaining,f'Ridotta da nota {note["number"]}',due['id']));remaining=Decimal(0)
        if remaining>0:conn.execute('INSERT INTO customer_credits(customer_id,credit_note_id,amount,remaining) VALUES (%s,%s,%s,%s)',(note['customer_id'],note_id,remaining,remaining))
        company=conn.execute('SELECT name,vat_number,address,postal_code,city,province,phone,email,fiscal_regime,tax_code,country,logo_data FROM company_settings WHERE id=1').fetchone();customer=conn.execute('SELECT id,name,vat_number,tax_code,address,postal_code,city,province,sdi_code,pec FROM customers WHERE id=%s',(note['customer_id'],)).fetchone() if note['customer_id'] else (inv['customer_snapshot'] or inv['casual_customer'])
        company_fields={k:company[k] for k in company if k!='logo_data'}
        conn.execute("UPDATE credit_notes SET status='CONFIRMED',taxable=%s,vat_amount=%s,total=%s,company_snapshot=%s::jsonb,customer_snapshot=%s::jsonb,logo_snapshot=%s WHERE id=%s",(taxable,vat,total,json.dumps(company_fields),json.dumps(dict(customer)),company['logo_data'],note_id))
        audit(conn,user,'CONFIRM','credit_notes',note_id,{'total':str(total),'invoice_id':inv['id']});return credit_detail(conn,note_id)


@router.get('/credit-notes/{note_id}/xml-preview')
def credit_xml(note_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    from app.fiscal_xml import create_xml
    with connect() as conn:
        note=conn.execute("SELECT * FROM credit_notes WHERE id=%s AND active=true AND status='CONFIRMED'",(note_id,)).fetchone()
        if not note:raise HTTPException(409,'Conferma prima la nota di credito')
        lines=conn.execute("SELECT position,code,description,unit_code,quantity,unit_price,discount_percent,0::numeric discount_amount,vat_rate,vat_nature,taxable,vat_amount FROM credit_note_lines WHERE credit_note_id=%s ORDER BY position,id",(note_id,)).fetchall()
        invoice={**dict(note),'id':note['id'],'document_status':'CONFIRMED','fiscal_document_type':'TD04','customer_id':note['customer_id'],'payment_type':'OTHER','bank_iban':'','issue_date':note['issue_date']}
        due=[{'due_date':note['issue_date'],'amount':note['total']}]
        payload=create_xml(invoice,note['company_snapshot'],note['customer_snapshot'],lines,[],{}, {},due)
    return Response(payload,media_type='application/xml',headers={'Content-Disposition':f'attachment; filename="nota-{note["number"]}.xml"','X-ERP-Validation':'internal-only; official-XSD-test-required'})


@router.delete('/credit-notes/{note_id}')
def credit_archive(note_id:int,user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        state=conn.execute('SELECT f.status FROM credit_notes c JOIN fiscal_years f ON f.year=c.fiscal_year WHERE c.id=%s',(note_id,)).fetchone()
        if state and state['status']!='OPEN':raise HTTPException(409,'Esercizio chiuso: nota in sola lettura')
        row=conn.execute("UPDATE credit_notes SET active=false WHERE id=%s AND active=true AND status='DRAFT' RETURNING id",(note_id,)).fetchone()
        if not row:raise HTTPException(409,'Solo una nota in bozza può essere archiviata')
        audit(conn,user,'ARCHIVE','credit_notes',note_id)
    return {'ok':True}
