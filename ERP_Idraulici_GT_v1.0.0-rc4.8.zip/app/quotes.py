"""Editable estimates based on the supplied costing workbook; no stock movement."""
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from app.auth import allowed
from app.db import connect
from app.catalog import audit
from app.numbering import next_document_number, assert_free_number
from app.locale_numbers import normalized, quantized_input
from app.fiscal_years import assert_open

router = APIRouter()
CENT = Decimal('0.01')
THREE = Decimal('0.001')


def decimal(value, maximum='99999999999.9999', minimum='0', places=4):
    try:
        if not isinstance(value, str):
            raise ValueError()
        result = Decimal(normalized(value))
        if not result.is_finite() or result < Decimal(minimum) or result > Decimal(maximum):
            raise ValueError()
        return quantized_input(result, places)
    except (ValueError, InvalidOperation, TypeError) as exc:
        raise HTTPException(400, f'Numero non valido: {value}') from exc


def money(value):
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


def calculated_unit_price(line, quote):
    """Three supplier discounts are sequential; manual unit price overrides the cost build."""
    if line['kind'] == 'DISCOUNT':
        return Decimal(str(line['fixed_adjustment']))
    gross = Decimal(str(line['purchase_gross']))
    net = gross
    for key in ('discount_1', 'discount_2', 'discount_3'):
        net *= 1 - Decimal(str(line[key])) / 100
    price = Decimal(str(line['unit_price']))
    mode = line.get('pricing_mode') or ('MANUAL' if price else 'COST')
    if mode == 'COST' or not price:
        price = net * (1 + Decimal(str(line['markup_percent'])) / 100)
        band=int(line.get('labor_band') or 0)
        labor_rate=quote['labor_rate_'+str(band)] if band else quote['labor_rate']
        price += Decimal(str(line['labor_minutes'])) / 60 * Decimal(str(labor_rate))
        price += Decimal(str(line['technician_hours'])) * Decimal(str(quote['technician_rate']))
    price += Decimal(str(line['fixed_adjustment']))
    for key in ('sale_discount_1', 'sale_discount_2', 'sale_discount_3'):
        price *= 1 - Decimal(str(line.get(key, 0))) / 100
    return price


def line_price(line, quote):
    return money(calculated_unit_price(line, quote) * Decimal(str(line['quantity'])))


def serialize(quote, lines):
    output = dict(quote)
    result, subtotal, vat = [], Decimal(0), Decimal(0)
    for line in lines:
        item = dict(line)
        total = line_price(item, output)
        subtotal += total
        vat += money(total * Decimal(str(item['vat_rate'])) / 100)
        item['total'] = str(total)
        item['display_unit_price'] = str(calculated_unit_price(item, output).quantize(THREE, rounding=ROUND_HALF_UP))
        for key, value in item.items():
            if isinstance(value, Decimal):
                item[key] = str(value)
        result.append(item)
    workdays=Decimal(str(output['working_days']))
    if output.get('auto_working_days'):
        minutes=sum(Decimal(str(line['labor_minutes']))*Decimal(str(line['quantity'])) for line in lines)
        workdays=minutes/(Decimal(str(output['minutes_per_day']))*Decimal(str(output['workers'])))
    output['working_days_effective']=str(workdays.quantize(THREE,rounding=ROUND_HALF_UP))
    labor = money(Decimal(str(output.get('manual_labor_cost', 0))))
    subtotal += labor
    vat += money(labor * Decimal('0.22'))
    output['manual_labor_cost']=str(labor)
    output['total_without_km']=str(money(subtotal + vat))
    mileage = money(Decimal(str(output['kilometers'])) * Decimal(str(output['kilometer_rate'])) * workdays)
    subtotal += mileage
    vat += money(mileage * Decimal('0.22'))
    output['lines'] = result
    output['kilometer_total'] = str(mileage)
    output['subtotal'] = str(money(subtotal))
    output['vat_total'] = str(money(vat))
    output['total'] = str(money(subtotal + vat))
    for key, value in output.items():
        if isinstance(value, Decimal):
            output[key] = str(value)
        elif isinstance(value, date):
            output[key] = value.isoformat()
    return output


HEADER_NUM = {'labor_rate': ('99999999999.9999', '0'), 'technician_rate': ('99999999999.9999', '0'),
              'labor_rate_1':('99999999999.9999','0'),'labor_rate_2':('99999999999.9999','0'),
              'labor_rate_3':('99999999999.9999','0'),'minutes_per_day':('99999999999.9999','0.0001'),
              'kilometers': ('99999999999.9999', '0'), 'kilometer_rate': ('99999999999.9999', '0'),
              'working_days': ('99999999999.9999', '0.0001'),
              'manual_labor_cost': ('99999999999.9999', '0')}
LINE_NUM = {'quantity': ('99999999999.9999', '0.0001', 4),
            'purchase_gross': ('99999999999.9999', '0', 4),
            'discount_1': ('100', '0', 2), 'discount_2': ('100', '0', 2), 'discount_3': ('100', '0', 2),
            'sale_discount_1': ('100', '0', 2), 'sale_discount_2': ('100', '0', 2),
            'sale_discount_3': ('100', '0', 2),
            'markup_percent': ('1000', '0', 2), 'labor_minutes': ('99999999999.9999', '0', 4),
            'technician_hours': ('99999999999.9999', '0', 4), 'unit_price': ('99999999999.9999', '0', 4),
            'vat_rate': ('100', '0', 2)}


class QuoteIn(BaseModel):
    number: str = ''
    party_type: str = 'CUSTOMER'
    customer_id: int | None = None
    supplier_id: int | None = None
    payment_method_id: int | None = None
    title: str = ''
    intervention: str = ''
    issue_date: date
    valid_days: int = 10
    status: str = 'DRAFT'
    introduction: str = ''
    exclusions: str = ''
    payment_terms: str = ''
    labor_rate: str = '32'
    labor_rate_1: str = '25'
    labor_rate_2: str = '28'
    labor_rate_3: str = '35'
    workers: int = 2
    minutes_per_day: str = '600'
    auto_working_days: bool = False
    technician_rate: str = '40'
    kilometers: str = '0'
    kilometer_rate: str = '0.68'
    working_days: str = '1'
    manual_labor_cost: str = '0'
    notes: str = ''


class LineIn(BaseModel):
    position: int = 0
    product_id: int | None = None
    code: str = ''
    description: str
    unit_code: str = 'PZ'
    quantity: str = '1'
    purchase_gross: str = '0'
    discount_1: str = '0'
    discount_2: str = '0'
    discount_3: str = '0'
    pricing_mode: str = 'COST'
    sale_discount_1: str = '0'
    sale_discount_2: str = '0'
    sale_discount_3: str = '0'
    markup_percent: str = '0'
    labor_minutes: str = '0'
    labor_band: int = 0
    technician_hours: str = '0'
    unit_price: str = '0'
    fixed_adjustment: str = '0'
    vat_rate: str = '22'
    kind: str = 'MATERIAL'
    notes: str = ''


class FullQuoteIn(BaseModel):
    header: QuoteIn
    lines: list[LineIn]


def validated(model, line=False):
    values = model.model_dump()
    for key, (maximum, minimum, *places) in (LINE_NUM if line else HEADER_NUM).items():
        values[key] = decimal(values[key], maximum, minimum, places[0] if places else 4)
    if line:
        values['fixed_adjustment'] = decimal(values['fixed_adjustment'], minimum='-99999999999.9999')
        if (values['kind'] not in ('MATERIAL','SERVICE','DISCOUNT')
                or values['pricing_mode'] not in ('COST','LIST','MANUAL')
                or values['position'] < 0 or values['labor_band'] not in (0,1,2,3)):
            raise HTTPException(400, 'Riga non valida')
        if values['kind'] == 'DISCOUNT' and values['fixed_adjustment'] >= 0:
            raise HTTPException(400, 'Lo sconto extra deve avere importo negativo')
    elif values['party_type'] not in ('CUSTOMER','SUPPLIER') or bool(values['customer_id'])==bool(values['supplier_id']):
        raise HTTPException(400,'Scegli un cliente oppure un fornitore')
    elif values['party_type']=='CUSTOMER' and not values['customer_id'] or values['party_type']=='SUPPLIER' and not values['supplier_id']:
        raise HTTPException(400,'L’anagrafica scelta non corrisponde al tipo indicato')
    elif not values['title'].strip() or values['status'] not in ('DRAFT','SENT','ACCEPTED','REJECTED') or not 0 <= values['valid_days'] <= 3650 or not 1 <= values['workers'] <= 100:
        raise HTTPException(400, 'Titolo, stato o validità non validi')
    return values


def linked_invoice_for_quote(conn, quote_id, exclude_invoice_id=0):
    """Return the active invoice that already consumed a quote in any supported flow."""
    row=conn.execute(
        'SELECT i.id,i.number,i.document_status FROM invoice_register i '
        'WHERE i.active=true AND i.id<>%s AND ('
        'i.quote_id=%s OR EXISTS (SELECT 1 FROM invoice_lines l WHERE l.invoice_id=i.id AND l.source_quote_id=%s) '
        'OR EXISTS (SELECT 1 FROM invoice_references r WHERE r.invoice_id=i.id AND r.quote_id=%s)) '
        'ORDER BY i.id DESC LIMIT 1',(exclude_invoice_id,quote_id,quote_id,quote_id)).fetchone()
    return dict(row) if row else None


def details(conn, quote_id):
    quote = conn.execute('SELECT q.*,m.name AS payment_method_name FROM quotes q LEFT JOIN payment_methods m ON m.id=q.payment_method_id WHERE q.id=%s AND q.active=true', (quote_id,)).fetchone()
    if not quote:
        raise HTTPException(404, 'Preventivo non trovato')
    lines = conn.execute('SELECT ql.*,COALESCE(s.stock,0) AS available_stock,COALESCE(ddt.delivered,0) AS delivered_quantity '
                         'FROM quote_lines ql LEFT JOIN (SELECT product_id,sum(quantity) AS stock FROM balances GROUP BY product_id) s '
                         'ON s.product_id=ql.product_id LEFT JOIN (SELECT dl.quote_line_id,sum(dl.quantity) delivered FROM delivery_lines dl JOIN delivery_notes d ON d.id=dl.delivery_id WHERE d.active=true GROUP BY dl.quote_line_id) ddt '
                         'ON ddt.quote_line_id=ql.id WHERE ql.quote_id=%s ORDER BY ql.position,ql.id', (quote_id,)).fetchall()
    result=serialize(quote, lines)
    for line in result['lines']:
        line['available']=line['product_id'] is None or Decimal(line['available_stock']) >= Decimal(line['quantity'])
        line['remaining_quantity']=str(max(Decimal('0'),Decimal(line['quantity'])-Decimal(line['delivered_quantity'])))
    result['has_ddt']=bool(conn.execute('SELECT 1 FROM delivery_notes WHERE quote_id=%s AND active=true LIMIT 1',(quote_id,)).fetchone())
    project=conn.execute('SELECT p.id,p.code,p.name,p.status FROM project_sites p WHERE p.active=true AND '
                         '(p.quote_id=%s OR EXISTS (SELECT 1 FROM project_quote_links l WHERE l.project_id=p.id AND l.quote_id=%s)) '
                         'ORDER BY p.id DESC LIMIT 1',(quote_id,quote_id)).fetchone()
    result['linked_invoice']=linked_invoice_for_quote(conn,quote_id)
    result['linked_project']=dict(project) if project else None
    result['can_direct_invoice']=not result['has_ddt'] and not result['linked_project'] and not result['linked_invoice']
    return result


@router.get('/quotes')
def list_quotes(user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        rows = conn.execute('SELECT id FROM quotes WHERE active=true AND fiscal_year=%s ORDER BY id DESC LIMIT 500',(user['selected_fiscal_year'],)).fetchall()
        return [details(conn, row['id']) for row in rows]


@router.get('/quotes/{quote_id}')
def get_quote(quote_id: int, user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        return details(conn, quote_id)


def save_quote(data, user, quote_id=None):
    values = validated(data)
    with connect() as conn:
        assert_open(conn,data.issue_date)
        values['fiscal_year']=data.issue_date.year
        existing=conn.execute('SELECT number,status FROM quotes WHERE id=%s AND active=true FOR UPDATE',(quote_id,)).fetchone() if quote_id else None
        if quote_id and not existing:raise HTTPException(404,'Preventivo non trovato')
        if quote_id and conn.execute('SELECT 1 FROM delivery_notes WHERE quote_id=%s AND active=true',(quote_id,)).fetchone():
            raise HTTPException(409,'Preventivo già collegato a DDT: non è più modificabile direttamente')
        requested=values['number'].strip()
        if requested and requested != (existing['number'] if existing else '') and user['role']!='ADMIN':
            raise HTTPException(403,'Solo l’amministratore può forzare il numero')
        if existing and requested and requested!=existing['number'] and existing['status']!='DRAFT':
            raise HTTPException(409,'Solo il preventivo in bozza può cambiare numero')
        values['number']=requested or (existing['number'] if existing else next_document_number(conn,'PRE',values['issue_date']))
        assert_free_number(conn,'PRE',values['number'],quote_id)
        table='customers' if values['party_type']=='CUSTOMER' else 'suppliers'
        party_id=values['customer_id'] if values['party_type']=='CUSTOMER' else values['supplier_id']
        party = conn.execute(f'SELECT name,address,city,vat_number FROM {table} WHERE id=%s AND active=true', (party_id,)).fetchone()
        if not party:
            raise HTTPException(400, 'Cliente o fornitore non attivo')
        if values['payment_method_id'] is not None and not conn.execute('SELECT 1 FROM payment_methods WHERE id=%s AND active=true',(values['payment_method_id'],)).fetchone():
            raise HTTPException(400,'Modalità di pagamento non valida')
        old = conn.execute('SELECT party_type,customer_id,supplier_id FROM quotes WHERE id=%s AND active=true', (quote_id,)).fetchone() if quote_id is not None else None
        if quote_id is None or old and (old['party_type'],old['customer_id'],old['supplier_id']) != (values['party_type'],values['customer_id'],values['supplier_id']):
            values.update(customer_name=party['name'],customer_address=party['address'],
                          customer_city=party.get('city',''),customer_vat=party['vat_number'])
        cols = list(values)
        if quote_id is None:
            row = conn.execute(f"INSERT INTO quotes ({','.join(cols)}) VALUES ({','.join(['%s']*len(cols))}) RETURNING id", tuple(values.values())).fetchone()
        else:
            row = conn.execute(f"UPDATE quotes SET {','.join(c+'=%s' for c in cols)} WHERE id=%s AND active=true RETURNING id", (*values.values(), quote_id)).fetchone()
            if not row:
                raise HTTPException(404, 'Preventivo non trovato')
        audit(conn, user, 'CREATE' if quote_id is None else 'UPDATE', 'quotes', row['id'])
        return details(conn, row['id'])


@router.post('/quotes', status_code=201)
def create_quote(data: QuoteIn, user=Depends(allowed('ADMIN','OFFICE'))):
    return save_quote(data, user)


@router.post('/quotes/full',status_code=201)
def create_full_quote(data:FullQuoteIn,user=Depends(allowed('ADMIN','OFFICE'))):
    header=validated(data.header)
    if not data.lines or len(data.lines)>300:
        raise HTTPException(400,'Inserisci da 1 a 300 righe nel preventivo')
    lines=[validated(line,line=True) for line in data.lines]
    with connect() as conn:
        assert_open(conn,data.header.issue_date)
        header['fiscal_year']=data.header.issue_date.year
        requested=header['number'].strip()
        if requested and user['role']!='ADMIN':raise HTTPException(403,'Solo l’amministratore può forzare il numero')
        header['number']=requested or next_document_number(conn,'PRE',header['issue_date'])
        assert_free_number(conn,'PRE',header['number'])
        table='customers' if header['party_type']=='CUSTOMER' else 'suppliers'
        party_id=header['customer_id'] if header['party_type']=='CUSTOMER' else header['supplier_id']
        customer=conn.execute(f'SELECT name,address,city,vat_number FROM {table} WHERE id=%s AND active=true',(party_id,)).fetchone()
        if not customer:raise HTTPException(400,'Cliente o fornitore non attivo')
        if header['payment_method_id'] is not None and not conn.execute('SELECT 1 FROM payment_methods WHERE id=%s AND active=true',(header['payment_method_id'],)).fetchone():
            raise HTTPException(400,'Modalità di pagamento non valida')
        header.update(customer_name=customer['name'],customer_address=customer['address'],
                      customer_city=customer['city'],customer_vat=customer['vat_number'])
        cols=list(header)
        quote=conn.execute(f"INSERT INTO quotes ({','.join(cols)}) VALUES ({','.join(['%s']*len(cols))}) RETURNING id",tuple(header.values())).fetchone()
        for line in lines:
            if line['product_id'] is not None and not conn.execute('SELECT 1 FROM products WHERE id=%s AND active=true',(line['product_id'],)).fetchone():
                raise HTTPException(400,'Articolo non attivo')
            fields=list(line)
            created=conn.execute(f"INSERT INTO quote_lines (quote_id,{','.join(fields)}) VALUES (%s,{','.join(['%s']*len(fields))}) RETURNING id",
                                 (quote['id'],*line.values())).fetchone()
            audit(conn,user,'CREATE','quote_lines',created['id'])
        audit(conn,user,'CREATE','quotes',quote['id'])
        return details(conn,quote['id'])


@router.put('/quotes/{quote_id}')
def update_quote(quote_id: int, data: QuoteIn, user=Depends(allowed('ADMIN','OFFICE'))):
    return save_quote(data, user, quote_id)


@router.delete('/quotes/{quote_id}')
def archive_quote(quote_id: int, user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        dated=conn.execute('SELECT issue_date FROM quotes WHERE id=%s AND active=true FOR UPDATE',(quote_id,)).fetchone()
        if dated:assert_open(conn,dated['issue_date'])
        if conn.execute('SELECT 1 FROM delivery_notes WHERE quote_id=%s AND active=true',(quote_id,)).fetchone():
            raise HTTPException(409,'Preventivo collegato a uno o più DDT: non può essere archiviato')
        if conn.execute('SELECT 1 FROM invoice_register WHERE quote_id=%s AND active=true',(quote_id,)).fetchone():
            raise HTTPException(409,'Preventivo collegato a una fattura: dissocialo prima dalla fattura in bozza')
        if conn.execute('SELECT 1 FROM project_sites WHERE quote_id=%s AND active=true UNION ALL SELECT 1 FROM project_quote_links l JOIN project_sites p ON p.id=l.project_id WHERE l.quote_id=%s AND p.active=true',(quote_id,quote_id)).fetchone():
            raise HTTPException(409,'Preventivo collegato a un cantiere: dissocialo prima dal cantiere')
        row = conn.execute('UPDATE quotes SET active=false WHERE id=%s AND active=true RETURNING id', (quote_id,)).fetchone()
        if not row:
            raise HTTPException(404, 'Preventivo non trovato')
        audit(conn, user, 'ARCHIVE', 'quotes', quote_id)
    return {'ok': True}


def save_line(quote_id, data, user, line_id=None):
    values = validated(data, line=True)
    with connect() as conn:
        quote=conn.execute('SELECT issue_date FROM quotes WHERE id=%s AND active=true FOR UPDATE', (quote_id,)).fetchone()
        if not quote:
            raise HTTPException(404, 'Preventivo non trovato')
        assert_open(conn,quote['issue_date'])
        if conn.execute('SELECT 1 FROM delivery_notes WHERE quote_id=%s AND active=true',(quote_id,)).fetchone():
            raise HTTPException(409,'Preventivo collegato a DDT: le righe sono bloccate')
        if values['product_id'] is not None and not conn.execute('SELECT 1 FROM products WHERE id=%s AND active=true', (values['product_id'],)).fetchone():
            raise HTTPException(400, 'Articolo non attivo')
        cols = list(values)
        if line_id is None:
            row = conn.execute(f"INSERT INTO quote_lines (quote_id,{','.join(cols)}) VALUES (%s,{','.join(['%s']*len(cols))}) RETURNING id", (quote_id,*values.values())).fetchone()
        else:
            row = conn.execute(f"UPDATE quote_lines SET {','.join(c+'=%s' for c in cols)} WHERE id=%s AND quote_id=%s RETURNING id", (*values.values(), line_id, quote_id)).fetchone()
            if not row:
                raise HTTPException(404, 'Riga non trovata')
        audit(conn, user, 'CREATE' if line_id is None else 'UPDATE', 'quote_lines', row['id'])
        return details(conn, quote_id)


@router.post('/quotes/{quote_id}/lines', status_code=201)
def create_line(quote_id: int, data: LineIn, user=Depends(allowed('ADMIN','OFFICE'))):
    return save_line(quote_id, data, user)


@router.put('/quotes/{quote_id}/lines/{line_id}')
def update_line(quote_id: int, line_id: int, data: LineIn, user=Depends(allowed('ADMIN','OFFICE'))):
    return save_line(quote_id, data, user, line_id)


@router.delete('/quotes/{quote_id}/lines/{line_id}')
def delete_line(quote_id: int, line_id: int, user=Depends(allowed('ADMIN','OFFICE'))):
    with connect() as conn:
        quote=conn.execute('SELECT issue_date FROM quotes WHERE id=%s AND active=true FOR UPDATE', (quote_id,)).fetchone()
        if not quote:
            raise HTTPException(404, 'Preventivo non trovato')
        assert_open(conn,quote['issue_date'])
        if conn.execute('SELECT 1 FROM delivery_notes WHERE quote_id=%s AND active=true',(quote_id,)).fetchone():
            raise HTTPException(409,'Preventivo collegato a DDT: le righe sono bloccate')
        row = conn.execute('DELETE FROM quote_lines WHERE id=%s AND quote_id=%s RETURNING id', (line_id, quote_id)).fetchone()
        if not row:
            raise HTTPException(404, 'Riga non trovata')
        audit(conn, user, 'DELETE', 'quote_lines', line_id)
        return details(conn, quote_id)
