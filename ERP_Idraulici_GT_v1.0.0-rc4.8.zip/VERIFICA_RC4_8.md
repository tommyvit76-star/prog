# Verifica ERP G&T v1.0.0-rc4.8

Data verifica locale: 28/09/2026

- 110 test Python superati.
- Sintassi di tutti i file JavaScript modificati verificata con `node --check`.
- Compilazione di tutti i moduli Python completata con `compileall`.
- Verificata la ricerca articolo per prefisso e l'apertura separata della ricerca dettagliata.
- Verificata la ricerca cliente con codice e ragione sociale sincronizzati in tutte le maschere condivise.
- Verificato che note e valori globali della fattura siano dopo le righe.
- Verificato il ritorno all'elenco dopo la conferma e lo stato visibile durante l'apertura della nota di credito.
- Verificata l'individuazione di un preventivo fatturato tramite intestazione, righe importate o riferimenti multipli.
- Verificati i blocchi server per nuove associazioni a cantiere, DDT, SAL e fattura.
- Verificata la traduzione degli stati in interfaccia e PDF.
- Nessuna nuova migrazione; nessuna istruzione di cancellazione dati.

Il collaudo conclusivo con PostgreSQL, browser e PDF del NAS deve essere eseguito dopo l'installazione seguendo `AGGIORNAMENTO_NAS_RC4_8.md`.
