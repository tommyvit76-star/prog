'use strict';
async function renderReports(){
  let balances,movements;
  try{[balances,movements]=await Promise.all([api('/balances'),api('/movement-report')])}
  catch(error){notice(error.message,true);return}
  const products=new Map((refs.products||[]).map(p=>[p.id,p]));
  const warehouses=new Map((refs.warehouses||[]).map(w=>[w.id,w]));
  const pane=el('section',undefined,'panel');pane.append(el('h3','Analisi magazzino'),el('p','Valori indicativi calcolati ai prezzi di acquisto degli articoli. Le quantità derivano dalle giacenze registrate.','muted'));
  const filters=el('div',undefined,'grid no-print');
  const warehouse=el('select'),category=el('select'),from=el('input'),to=el('input');from.type=to.type='date';
  for(const [id,label] of [['','Tutti i magazzini'],...(refs.warehouses||[]).map(w=>[w.id,w.name])]){const option=el('option',label);option.value=id;warehouse.append(option)}
  for(const [name,label] of [['','Tutte le categorie'],...(refs['product-categories']||[]).map(c=>[c.name,c.name])]){const option=el('option',label);option.value=name;category.append(option)}
  for(const [label,input] of [['Magazzino',warehouse],['Categoria',category],['Movimenti dal',from],['Movimenti al',to]]){const wrap=el('label',label);wrap.append(input);filters.append(wrap)}
  pane.append(filters);const output=el('div');pane.append(output);view.append(pane);
  function build(){output.replaceChildren();const rows=balances.filter(b=>{
      const p=products.get(b.product_id);return p&&Number(b.quantity)>0&&(!warehouse.value||String(b.warehouse_id)===warehouse.value)&&(!category.value||p.category===category.value)
    });
    const byWarehouse=new Map();for(const b of rows){const p=products.get(b.product_id),item=byWarehouse.get(b.warehouse_id)||{count:0,value:0};item.count++;if(p.purchase_price===undefined)item.hidden=true;else item.value+=Number(b.quantity)*Number(p.purchase_price||0);byWarehouse.set(b.warehouse_id,item)}
    const summary=el('div',undefined,'stats');for(const [id,data] of byWarehouse){const metric=el('div',undefined,'metric');metric.append(el('strong',warehouses.get(id)?.name||'Magazzino'),el('span',`${data.count} righe · ${data.hidden?'valore non disponibile per i tuoi permessi':'valore indicativo € '+displayIt(data.value,2)}`));summary.append(metric)}output.append(summary);
    const low=[...new Set(rows.map(b=>b.product_id))].map(id=>products.get(id)).filter(p=>Number(p.total_stock)<Number(p.min_stock));output.append(el('h3',`Articoli sotto scorta: ${low.length}`));for(const p of low)output.append(el('div',`${p.code} · ${p.description} · giacenza ${displayIt(p.total_stock,4)} ${p.unit_code} · minimo ${displayIt(p.min_stock,4)} ${p.unit_code}`,'record'));
    const selected=movements.filter(m=>(!warehouse.value||String(m.source_id)===warehouse.value||String(m.destination_id)===warehouse.value)&&(!category.value||products.get(m.product_id)?.category===category.value)&&(!from.value||m.created_at.slice(0,10)>=from.value)&&(!to.value||m.created_at.slice(0,10)<=to.value));
    const kinds=new Map();for(const row of selected)kinds.set(row.kind,(kinds.get(row.kind)||0)+1);output.append(el('h3',`Movimenti nel periodo: ${selected.length}`));for(const [kind,count] of kinds)output.append(el('div',`${movementName(kind)}: ${count}`,'record'));
    output.append(btn('Stampa inventario A4 verticale',()=>{const params=new URLSearchParams({warehouse_id:warehouse.value,category:category.value});openPdfForPrint('/pdf/inventory?'+params)}),btn('Stampa movimenti A4 verticale',()=>{const params=new URLSearchParams({warehouse_id:warehouse.value,date_from:from.value,date_to:to.value});openPdfForPrint('/pdf/movements?'+params)}));
  }
  for(const input of [warehouse,category,from,to])input.onchange=build;build();
}
