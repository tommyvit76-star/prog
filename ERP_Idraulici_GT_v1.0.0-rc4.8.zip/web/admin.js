'use strict';
let companyState=null;
const moduleNames={customers:'Clienti',suppliers:'Fornitori',units:'Unità di misura',products:'Articoli',warehouses:'Magazzini',balances:'Giacenze',movements:'Movimenti',reports:'Report', 'price-lists':'Listini',quotes:'Preventivi',payments:'Pagamenti e scadenze',invoices:'Fatture'};

async function refreshBrand(){try{companyState=await api('/company');$('brandName').textContent=companyState.name;const mark=$('companyLogo');if(companyState.has_logo){mark.src='/company/logo?t='+Date.now();mark.classList.remove('hidden')}else{mark.classList.add('hidden');mark.removeAttribute('src')}}catch{}}
refreshBrand();

function renderSettingsHome(){
 if(user.role!=='ADMIN')return notice('Accesso riservato all’amministratore',true);
 const intro=el('p','Scegli la configurazione da gestire. Le operazioni sensibili restano nel menu Amministrazione.','muted'),grid=el('div',undefined,'module-grid');
 const entries=[
  ['Impostazioni DDT e trasporto','Causali, aspetto beni, porto, vettori e modalità di trasporto',async()=>{await render('admin');document.querySelector('#transportSettings')?.scrollIntoView({behavior:'smooth'})}],
  ['Modalità di pagamento','Regole, rate e visualizzazione IBAN in fattura',()=>render('payments')],
  ['Conti correnti','Conti aziendali selezionabili nei documenti',async()=>{await render('admin');document.querySelector('#companyBanks')?.scrollIntoView({behavior:'smooth'})}],
  ['Progressivi documenti','Serie e prossimo numero per l’esercizio',async()=>{await render('admin');document.querySelector('#numberSettings')?.scrollIntoView({behavior:'smooth'})}],
  ['Listini e sconti','Sconto semplice o tre sconti in sequenza',()=>render('price-lists')],
  ['Anagrafiche','Clienti, fornitori, articoli e condizioni predefinite',()=>openMenuGroup('records')]
 ];
 for(const [title,description,action] of entries){const card=btn('',action,'module-card');card.append(el('strong',title),el('span',description));grid.append(card)}
 view.append(intro,grid)
}

async function renderAdmin(){if(user.role!=='ADMIN')return notice('Accesso riservato all’amministratore',true);let users,modules,company;try{[users,modules,company]=await Promise.all([api('/admin/users'),api('/admin/modules'),api('/company')])}catch(e){notice(e.message,true);return}const section=el('section',undefined,'panel');section.append(el('h3','Azienda gestita'));const form=el('form',undefined,'grid');const fields=[['name','Nome azienda'],['vat_number','Partita IVA'],['address','Indirizzo'],['postal_code','CAP'],['city','Città'],['province','Provincia'],['phone','Telefono'],['email','Email'],['fiscal_regime','Regime fiscale (es. RF01)'],['tax_code','Codice fiscale azienda'],['country','Paese (IT)']];for(const [key,label] of fields){const wrap=el('label',label),input=el('input');input.name=key;input.value=company[key]||'';if(key==='name')input.required=true;wrap.append(input);form.append(wrap)}const save=el('button','Salva dati azienda');form.append(save);form.onsubmit=async event=>{event.preventDefault();try{await api('/admin/company','PUT',Object.fromEntries(new FormData(form)));await refreshBrand();delete form.dataset.dirty;notice('Dati aziendali aggiornati')}catch(e){notice(e.message,true)}};section.append(form);const logo=el('div',undefined,'panel'),picker=el('input');picker.type='file';picker.accept='image/png,image/jpeg,image/webp';logo.append(el('h3','Logo della tua azienda'),el('p','PNG, JPG o WebP, massimo 2 MB. Apparirà su ogni schermata e sui preventivi.','muted'),picker,btn('Carica logo',async()=>{const selected=picker.files?.[0];if(!selected||selected.size>2097152)return notice('Scegli un file di massimo 2 MB',true);try{const base64=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result.split(',')[1]);reader.onerror=reject;reader.readAsDataURL(selected)});await api('/admin/company/logo','PUT',{mime_type:selected.type,data:base64});await refreshBrand();notice('Logo caricato')}catch(e){notice(e.message,true)}}),btn('Rimuovi logo',async()=>{if(!confirm('Rimuovere il logo aziendale?'))return;try{await api('/admin/company/logo','DELETE');await refreshBrand();notice('Logo rimosso')}catch(e){notice(e.message,true)}},'danger'));section.append(logo);view.append(section);
await renderCompanyBanks();await renderBackups();await renderNumberSettings();renderTestReset();const people=el('section',undefined,'panel');people.append(el('h3','Utenti e competenze'),el('p','La tua password admin resta la stessa. Le autorizzazioni si applicano subito alle API; una nuova password termina le sessioni dell’utente.','muted'));people.append(btn('＋ Aggiungi utente',()=>accountForm(null,modules,people)));for(const entry of users){const line=el('div',undefined,'record'),summary=el('span',`${entry.username} · ${entry.role}${entry.active?'':' · DISATTIVATO'}`),actions=el('div',undefined,'actions');if(entry.active){actions.append(btn('Modifica / competenze',()=>accountForm(entry,modules,people)));if(entry.id!==user.id)actions.append(btn('Disattiva',async()=>{if(!confirm(`Disattivare ${entry.username}? La cronologia rimarrà disponibile.`))return;try{await api(`/admin/users/${entry.id}`,'DELETE');await render('admin');notice('Utente disattivato')}catch(e){notice(e.message,true)}},'danger'))}else actions.append(btn('Riattiva',async()=>{try{await api(`/admin/users/${entry.id}/restore`,'POST');await render('admin');notice('Utente riattivato: controlla i permessi e la password')}catch(e){notice(e.message,true)}}));line.append(summary,actions);people.append(line)}view.append(people)}

async function renderNumberSettings(){const panel=el('section',undefined,'panel');panel.id='numberSettings';panel.append(el('h3',`Progressivi documenti · esercizio ${fiscalYear}`),el('p','Formato predefinito: PREFISSO-000001-ANNO. Dopo l’emissione puoi soltanto avanzare il progressivo; i numeri usati non vengono recuperati.','muted'));let rows;try{rows=await api(`/admin/document-number-settings?year=${fiscalYear}`)}catch(error){panel.append(el('p',error.message,'error'));view.append(panel);return}const names={FT:'Fatture',DDT:'DDT',PRE:'Preventivi',SAL:'SAL',NC:'Note di credito'};for(const row of rows){const block=el('section',undefined,'form-section'),form=el('form',undefined,'grid');block.append(el('h4',`${names[row.document_type]} · prossimo: ${row.preview}`));for(const [name,label,type,options] of [['prefix','Prefisso'],['separator','Separatore','select',[['-','Trattino -'],['/','Barra /'],['.','Punto .']]],['sequence_digits','Cifre progressivo','number'],['year_position','Posizione anno','select',[['SUFFIX','Alla fine'],['PREFIX','All’inizio']]],['next_number','Prossimo numero','number']]){const wrap=el('label',label),input=el(type==='select'?'select':'input');input.name=name;if(type==='select')for(const [value,text] of options){const option=el('option',text);option.value=value;input.append(option)}else input.type=type||'text';input.value=row[name];input.required=true;wrap.append(input);form.append(wrap)}const reset=el('label',undefined,'check'),check=el('input');check.type='checkbox';check.checked=row.reset_yearly;reset.append(check,el('span','Riparti da 1 a ogni esercizio'));form.append(reset,el('button','Salva progressivo'));form.onsubmit=async event=>{event.preventDefault();const values=Object.fromEntries(new FormData(form));values.sequence_digits=Number(values.sequence_digits);values.next_number=Number(values.next_number);values.reset_yearly=check.checked;try{const result=await api(`/admin/document-number-settings/${row.document_type}?year=${fiscalYear}`,'PUT',values);await render('admin');notice(`Progressivo salvato: ${result.preview}`)}catch(error){showFormError(form,error)}};block.append(form);panel.append(block)}view.append(panel)}

function renderTestReset(){
 const panel=el('section',undefined,'panel maintenance-panel');
 panel.append(el('h3','Manutenzione · azzeramento dati'),el('p','L’azzeramento standard elimina documenti, scadenze, cantieri, movimenti, giacenze, registri e progressivi. Conserva utenti, azienda, clienti, fornitori, articoli, magazzini e configurazioni. Prima viene creato un backup completo.','danger-text'));
 const form=el('form',undefined,'grid'),password=el('input'),confirmation=el('input'),fullLabel=el('label',undefined,'check'),full=el('input');
 password.name='password';password.type='password';password.required=true;password.autocomplete='current-password';
 full.type='checkbox';fullLabel.append(full,el('span','Elimina anche anagrafiche clienti/fornitori, articoli, categorie, magazzini e listini'));
 confirmation.name='confirmation';confirmation.required=true;
 const lp=el('label','Password amministratore'),lc=el('label','Frase di conferma');lp.append(password);lc.append(confirmation);
 const submit=el('button','Azzera dati di prova','danger');
 function scope(){const all=full.checked;confirmation.placeholder=all?'AZZERA TUTTO':'AZZERA DATI DI PROVA';confirmation.value='';submit.textContent=all?'Azzera tutto':'Azzera dati di prova'}
 full.onchange=scope;scope();form.append(lp,fullLabel,lc,submit);
 form.onsubmit=async event=>{event.preventDefault();const all=full.checked,message=all?'Confermi anche la cancellazione di tutte le anagrafiche e del catalogo? Utenti, password e dati azienda saranno conservati.':'Confermi l’azzeramento dei documenti e dei dati operativi?';if(!confirm(message+' Verrà prima creato un backup completo.'))return;submit.disabled=true;try{const result=await api('/admin/reset-test-data','POST',{password:password.value,confirmation:confirmation.value,scope:all?'ALL_MASTER':'OPERATIONS'});await loadRefs();await renderHome();notice(`Azzeramento completato. Backup creato con successo: ${result.backup}`)}catch(error){showFormError(form,error)}finally{submit.disabled=false}};
 panel.append(form);view.append(panel)
}

function accountForm(account, modules, container) {
  $('accountEditor')?.remove();
  const section = el('section', undefined, 'panel');
  section.id = 'accountEditor';
  section.append(el('h3', account ? `Modifica ${account.username}` : 'Nuovo utente'));
  const form = el('form', undefined, 'grid');
  for (const [name, label, type, value] of [
    ['username', 'Nome utente', 'text', account?.username || ''],
    ['password', account ? 'Nuova password (vuoto = invariata)' : 'Password (almeno 6 caratteri)', 'password', '']
  ]) {
    const wrap = el('label', label), input = el('input');
    input.name = name;
    input.type = type;
    input.value = value;
    input.autocomplete = name === 'password' ? 'new-password' : 'off';
    input.required = name === 'username' || !account;
    if (name === 'password') input.minLength = 6;
    wrap.append(input);
    form.append(wrap);
  }
  const role = el('label', 'Ruolo'), roles = el('select');
  roles.name = 'role';
  for (const [value, label] of [['OFFICE','Ufficio'],['WAREHOUSE','Magazzino'],['TECHNICIAN','Operatore'],['ADMIN','Amministratore']]) {
    const option = el('option', label); option.value = value; roles.append(option);
  }
  roles.value = account?.role || 'OFFICE';
  role.append(roles); form.append(role);
  const toolbar = el('div', undefined, 'full actions');
  const rights = el('div', undefined, 'full scroll'), table = el('table', undefined, 'module-table'), header = el('tr');
  for (const title of ['Modulo installato', 'Può consultare', 'Può modificare / eliminare']) header.append(el('th', title));
  table.append(header);
  for (const module of modules) {
    const row = el('tr'), stored = account?.permissions?.find(item => item.module === module);
    row.append(el('td', moduleNames[module] || module));
    for (const level of ['view', 'edit']) {
      const cell = el('td'), check = el('input');
      check.type = 'checkbox';
      check.dataset.module = module;
      check.dataset.level = level;
      check.checked = Boolean(stored?.[level]);
      cell.append(check); row.append(cell);
    }
    table.append(row);
  }
  toolbar.append(btn('Seleziona tutti', () => {
    rights.querySelectorAll('input[type="checkbox"]').forEach(check => { check.checked = true });
  }), btn('Deseleziona tutti', () => {
    rights.querySelectorAll('input[type="checkbox"]').forEach(check => { check.checked = false });
  }));
  rights.append(table); form.append(toolbar, rights);
  const buttons = el('div', undefined, 'full actions'), submit = el('button', 'Salva utente');
  submit.type = 'submit';
  buttons.append(submit, btn('Annulla', () => section.remove()));
  form.append(buttons);
  const feedback = el('p', '', 'full');
  feedback.setAttribute('role', 'status');
  form.append(feedback);
  form.onsubmit = async event => {
    event.preventDefault();
    feedback.className = 'full';
    feedback.textContent = 'Salvataggio in corso…';
    submit.disabled = true;
    try {
      const raw = Object.fromEntries(new FormData(form));
      const permissions = modules.map(module => ({module, view: false, edit: false}));
      const byModule = new Map(permissions.map(item => [item.module, item]));
      rights.querySelectorAll('input[type="checkbox"]').forEach(check => {
        const entry = byModule.get(check.dataset.module);
        if (entry) entry[check.dataset.level] = check.checked;
      });
      const payload = {username: raw.username.trim(), role: raw.role,
                       password: raw.password || null, permissions};
      await api(account ? `/admin/users/${account.id}` : '/admin/users', account ? 'PUT' : 'POST', payload);
      if (account?.id === user.id && payload.password) {
        showLogin(); notice('Password aggiornata: accedi di nuovo'); return;
      }
      await render('admin'); notice('Utente salvato');
    } catch (error) {
      feedback.textContent = error.message || 'Salvataggio non riuscito';
      feedback.className = 'full error';
      notice(feedback.textContent, true);
    } finally { submit.disabled = false; }
  };
  section.append(form); container.append(section); section.scrollIntoView({behavior:'smooth'});
}

function appendCompanyBrand(doc){if(!companyState)return;const block=doc.createElement('div');block.style.cssText='display:flex;align-items:center;gap:12px;margin-bottom:15px';if(companyState.has_logo){const image=doc.createElement('img');image.src=window.location.origin+'/company/logo';image.alt='Logo azienda';image.style.cssText='max-width:110px;max-height:60px';block.append(image)}const name=doc.createElement('strong');name.textContent=companyState.name;block.append(name);const details=doc.createElement('span');details.textContent=[companyState.address,[companyState.postal_code,companyState.city,companyState.province].filter(Boolean).join(' '),companyState.vat_number?'P.IVA '+companyState.vat_number:'',companyState.phone,companyState.email].filter(Boolean).join(' · ');details.style.cssText='display:block;font-size:12px;color:#456';block.append(details);doc.body.prepend(block)}

async function renderBackups(){
  const panel=el('section',undefined,'panel');panel.append(el('h3','Backup del database aziendale'),el('p','Il backup comprende tutti i dati del database attuale: anagrafiche, utenti, articoli, documenti e impostazioni. Orario italiano (Europe/Rome). I file restano nella cartella backup del NAS: scaricane periodicamente una copia esterna.','muted'));
  let state;try{state=await api('/admin/backups')}catch(error){panel.append(el('p',error.message,'error'));view.append(panel);return}
  const schedule=el('form',undefined,'grid'),on=el('label','Backup automatico giornaliero'),check=el('input');check.type='checkbox';check.checked=state.schedule.enabled;on.append(check);const at=el('label','Ora del backup (Italia)'),clock=el('input');clock.type='time';clock.required=true;clock.value=(state.schedule.backup_time||'02:00').slice(0,5);at.append(clock);const submit=el('button','Salva orario');submit.type='submit';schedule.append(on,at,submit);schedule.onsubmit=async event=>{event.preventDefault();try{await api('/admin/backups/schedule','PUT',{enabled:check.checked,backup_time:clock.value});notice('Pianificazione salvata');await render('admin')}catch(error){notice(error.message,true)}};panel.append(schedule);
  if(state.schedule.last_success_at)panel.append(el('p',`Ultimo backup automatico: ${new Date(state.schedule.last_success_at).toLocaleString('it-IT')}`));
  if(state.schedule.last_error)panel.append(el('p',`Ultimo errore: ${state.schedule.last_error}`,'error'));
  const actions=el('div',undefined,'actions');const manual=btn('Crea backup ora',async()=>{manual.disabled=true;try{const result=await api('/admin/backups/create','POST');await render('admin');notice(`Backup creato con successo: ${result.name}`)}catch(error){notice(error.message,true)}finally{manual.disabled=false}});actions.append(manual);
  const upload=el('input');upload.type='file';upload.accept='.dump,application/octet-stream';upload.setAttribute('aria-label','Seleziona il file di backup da ripristinare');actions.append(upload);
  const restore=btn('Ripristina da file',async()=>{const file=upload.files?.[0];if(!file)return notice('Seleziona prima un file .dump',true);if(file.size>8*1024*1024*1024)return notice('Il file supera 8 GB',true);if(!confirm('Ripristinare tutto il database aziendale dal file selezionato? I dati attuali verranno sostituiti. Verrà creato automaticamente un backup prima del ripristino. Esegui questa operazione quando nessun altro utente sta lavorando.'))return;restore.disabled=true;try{const response=await fetch('/admin/backups/restore',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/octet-stream'},body:file});const result=await response.json();if(!response.ok)throw Error(result.detail||'Ripristino non riuscito');showLogin();notice('Database ripristinato. Accedi di nuovo.')}catch(error){notice(error.message,true)}finally{restore.disabled=false}},'danger');actions.append(restore);panel.append(actions);
  panel.append(el('h4','Backup disponibili sul NAS'));
  for(const item of state.files){const record=el('div',undefined,'record'),label=el('span',`${new Date(item.created_at).toLocaleString('it-IT')} · ${(item.size/1048576).toFixed(1)} MB · ${item.name}`);record.append(label,btn('Scarica',async()=>{try{const response=await fetch('/admin/backups/'+encodeURIComponent(item.name),{headers:{Authorization:'Bearer '+token}});if(!response.ok)throw Error('Download non riuscito');const url=URL.createObjectURL(await response.blob()),a=el('a');a.href=url;a.download=item.name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000)}catch(error){notice(error.message,true)}}));panel.append(record)}
  if(!state.files.length)panel.append(el('p','Nessun backup presente.','muted'));view.append(panel);
}

async function renderCompanyBanks(){const panel=el('section',undefined,'panel');panel.id='companyBanks';panel.append(el('h3','Conti correnti aziendali'),el('p','Il conto selezionato viene riportato nelle bozze fattura.','muted'));let rows;try{rows=await api('/company-bank-accounts')}catch(e){notice(e.message,true);return}panel.append(btn('＋ Aggiungi conto',()=>bankEditor(panel)));for(const row of rows){const record=el('div',undefined,'record'),actions=el('div',undefined,'actions');record.append(el('span',`${row.label} · ${row.bank_name} · ${row.holder} · ${row.iban}`));actions.append(btn('Modifica',()=>bankEditor(panel,row)),btn('Archivia',async()=>{if(!confirm('Archiviare questo conto? Le bozze fattura già registrate conservano i dati.'))return;try{await api(`/company-bank-accounts/${row.id}`,'DELETE');await render('admin')}catch(e){notice(e.message,true)}},'danger'));record.append(actions);panel.append(record)}view.append(panel)}
function bankEditor(panel,record){panel.querySelector('#bankEditor')?.remove();const section=el('section',undefined,'panel'),form=el('form',undefined,'grid');section.id='bankEditor';section.append(el('h3',record?'Modifica conto':'Nuovo conto'));for(const [key,label] of [['label','Nome conto'],['bank_name','Banca'],['holder','Intestatario'],['iban','IBAN']]){const wrap=el('label',label),input=el('input');input.name=key;input.value=record?.[key]||'';input.required=key!=='bank_name';wrap.append(input);form.append(wrap)}form.append(el('button','Salva conto'));form.onsubmit=async event=>{event.preventDefault();try{await api(record?`/company-bank-accounts/${record.id}`:'/company-bank-accounts',record?'PUT':'POST',Object.fromEntries(new FormData(form)));await render('admin');notice('Conto salvato')}catch(e){notice(e.message,true)}};section.append(form);panel.append(section);section.scrollIntoView({behavior:'smooth'})}

