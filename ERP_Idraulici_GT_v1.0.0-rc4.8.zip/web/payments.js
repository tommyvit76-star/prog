'use strict';
function paymentForm(fields,values,save,title){const section=el('section',undefined,'panel'),form=el('form',undefined,'grid');form.dataset.saveOnExit='true';section.append(el('h3',title));for(const [name,label,type] of fields){const wrap=el('label',label);let input;if(type==='select'||type==='status'||type==='method'||type==='invoice'||type==='bank'||type==='paymenttype'||type==='quote'||type==='warehouse'||type==='salstatus'||type==='fiscaltype'){input=el('select');const options=type==='fiscaltype'?[['TD01','TD01 · fattura immediata'],['TD24','TD24 · fattura differita con DDT']]:type==='select'?refs.customers.map(x=>[x.id,`${x.code?x.code+' · ':''}${x.name}`]):type==='warehouse'?refs.warehouses.map(x=>[x.id,x.name]):type==='salstatus'?[['PARTIAL','Parziale'],['COMPLETED','Completato']]:type==='bank'?[['','Nessuno'],...(refs['company-bank-accounts']||[]).map(x=>[x.id,`${x.label} · ${x.iban}`])]:type==='paymenttype'?[['OTHER','Altro'],['TRANSFER','Bonifico'],['RIBA','Ri.Ba.']]:type==='method'?[['','Nessuna'],...(refs['payment-methods']||[]).map(x=>[x.id,x.name])]:type==='invoice'?(refs['invoice-register']||[]).map(x=>[x.id,`${x.number} · ${x.customer_name}`]):type==='quote'?[['','Nessuno'],...(refs.quotes||[]).map(x=>[x.id,`${x.id} · ${x.title}`])]:[['OPEN','Da pagare'],['PAID','Pagata'],['CANCELLED','Annullata']];for(const [value,text] of options){const choice=el('option',text);choice.value=value;input.append(choice)}}else{input=el('input');input.type=type==='date'?'date':type==='checkbox'?'checkbox':'text';if(['amount','total','taxable','vat_amount'].includes(name))input.inputMode='decimal'}input.name=name;if(name==='number')input.placeholder='Lascia vuoto per il progressivo automatico';if(type==='checkbox')input.checked=Boolean(values?.[name]);else input.value=input.inputMode==='decimal'?decimalInput(values?.[name]??''):values?.[name]??'';if(input.tagName==='SELECT'&&input.selectedIndex<0&&input.options.length)input.selectedIndex=0;if(['name','due_date','issue_date','issued_on','total','amount','customer_id','warehouse_id'].includes(name))input.required=true;wrap.append(input);if(name==='customer_id')attachRegistrySearch(wrap,input,'Cerca cliente per nome o iniziali');form.append(wrap)}const row=el('div',undefined,'full actions');row.append(el('button','Salva'),btn('Annulla',()=>section.remove()));form.append(row);form.onsubmit=async event=>{event.preventDefault();if(!form.checkValidity()){form.reportValidity();return}const data=Object.fromEntries(new FormData(form));for(const [name,value] of Object.entries(data))if(form.elements[name]?.inputMode==='decimal')data[name]=String(parseIt(value));for(const [name,,type] of fields)if(type==='checkbox')data[name]=form.elements[name].checked;for(const key of ['customer_id','payment_method_id','bank_account_id','invoice_id','quote_id','warehouse_id'])if(key in data)data[key]=data[key]?Number(data[key]):null;try{await save(data);delete form.dataset.dirty;form.dispatchEvent(new Event('erp:saved'))}catch(error){showFormError(form,error);form.dispatchEvent(new Event('erp:save-failed'))}};section.append(form);return section}
function dueEditor(fields,values,save,title){paymentEditor(fields,values,save,title);const form=$('paymentEditor')?.querySelector('form');if(!form)return;const apply=()=>{const invoice=(refs['invoice-register']||[]).find(x=>x.id===Number(form.elements.invoice_id.value));if(!invoice)return;const method=(refs['payment-methods']||[]).find(x=>x.id===Number(form.elements.payment_method_id.value));const date=new Date(invoice.issue_date+'T12:00:00');date.setDate(date.getDate()+Number(method?.default_days||0));if(method?.end_of_month)date.setMonth(date.getMonth()+1,0);date.setDate(date.getDate()+Number(method?.extra_days||0));form.elements.due_date.value=date.toISOString().slice(0,10)};form.elements.invoice_id.onchange=()=>{const invoice=(refs['invoice-register']||[]).find(x=>x.id===Number(form.elements.invoice_id.value));if(invoice)form.elements.payment_method_id.value=invoice.payment_method_id||'';apply()};form.elements.payment_method_id.onchange=apply;if(!values?.due_date)form.elements.invoice_id.onchange()}
function paymentEditor(fields,values,save,title){$('paymentEditor')?.remove();const section=paymentForm(fields,values,save,title);section.id='paymentEditor';view.append(section);if(fields.some(([key])=>key==='number'))attachNumberPreview(section.querySelector('form'),title.includes('DDT')?'DDT':title.includes('SAL')?'SAL':'FT',title.includes('fattura')?'issue_date':'issued_on',Boolean(values?.id));section.scrollIntoView({behavior:'smooth'})}
async function renderPayments() {
  let methods;
  try { methods = await api('/payment-methods') }
  catch (error) { notice(error.message, true); return }
  refs['payment-methods'] = methods;
  try{refs['company-bank-accounts']=await api('/company-bank-accounts')}catch{refs['company-bank-accounts']=[]}
  const editing = hasAccess('payments', true);
  const methodFields = [['name','Nome modalità'],['description','Descrizione'],['default_days','Giorni base dalla data fattura'],['end_of_month','Fine mese','checkbox'],['extra_days','Giorni aggiuntivi dopo i giorni base o fine mese'],['payment_type','Tipo pagamento','paymenttype'],['bank_account_id','Conto aziendale predefinito','bank'],['show_iban','Mostra IBAN aziendale in fattura','checkbox']];
  view.append(el('h3','Modalità di pagamento'));
  if (editing) view.append(btn('＋ Nuova modalità', () => paymentEditor(methodFields,{default_days:0,end_of_month:false,extra_days:0,payment_type:'OTHER',show_iban:true},async data => {
    await api('/payment-methods','POST',data); await render('payments'); notice('Modalità creata');
  },'Nuova modalità')));
  for (const method of methods) {
    const row = el('div',undefined,'record'),actions=el('div',undefined,'actions');
    row.append(el('span',`${method.name} · ${method.description} · ${method.default_days} giorni base${method.end_of_month?' · fine mese':''}${method.extra_days?' · +'+method.extra_days+' gg':''} · ${method.payment_type==='RIBA'?'Ri.Ba.':method.payment_type==='TRANSFER'?'Bonifico':'Altro'}${method.bank_account_id?' · '+(refs['company-bank-accounts']||[]).find(x=>x.id===method.bank_account_id)?.label:''}${method.show_iban?' · IBAN visibile':' · IBAN nascosto'}`));
    if (editing) actions.append(btn('Configura rate',()=>installmentEditor(method)),btn('Modifica',()=>paymentEditor(methodFields,method,async data=>{
      await api(`/payment-methods/${method.id}`,'PUT',data); await render('payments'); notice('Modalità aggiornata');
    },'Modifica modalità')),btn('Archivia',async()=>{
      if(!confirm('Archiviare questa modalità? Le fatture esistenti la manterranno.'))return;
      try{await api(`/payment-methods/${method.id}`,'DELETE');await render('payments')}
      catch(error){notice(error.message,true)}
    },'danger'));
    row.append(actions);view.append(row);
  }
  view.append(el('h3','Scadenziario fatture'));
  const dueFields=[['invoice_id','Fattura','invoice'],['payment_method_id','Modalità','method'],
                   ['due_date','Scadenza','date'],['amount','Importo €'],['status','Stato','status'],
                   ['paid_at','Data pagamento','date'],['notes','Note']];
  if(editing)view.append(btn('＋ Nuova scadenza',()=>dueEditor(dueFields,{status:'OPEN'},async data=>{
    await api('/payment-due','POST',data);await render('payments');notice('Scadenza creata');
  },'Nuova scadenza')));
  const filters=el('div',undefined,'grid no-print'),query={};
  function selection(name,label,options){const wrap=el('label',label),input=el('select');
    for(const [value,title] of options){const option=el('option',title);option.value=value;input.append(option)}
    wrap.append(input);filters.append(wrap);query[name]=input}
  function dateField(name,label){const wrap=el('label',label),input=el('input');input.type='date';wrap.append(input);filters.append(wrap);query[name]=input}
  selection('customer_id','Cliente',[['','Tutti'],...(refs.customers||[]).map(x=>[x.id,x.name])]);
  selection('invoice_id','Fattura',[['','Tutte'],...(refs['invoice-register']||[]).map(x=>[x.id,`${x.number} · ${x.customer_name}`])]);
  selection('status','Stato',[['','Tutti'],['OPEN','Da pagare'],['PAID','Pagate'],['CANCELLED','Annullate']]);
  dateField('due_from','Scadenza dal');dateField('due_to','Scadenza al');
  const overdue=el('label',undefined,'check'),overdueInput=el('input');overdueInput.type='checkbox';
  overdue.append(overdueInput,el('span','Solo scadute'));filters.append(overdue);
  const actions=el('div',undefined,'full actions');
  function dueQuery(){const params=new URLSearchParams();for(const [key,input] of Object.entries(query))if(input.value)params.set(key,input.value);if(overdueInput.checked)params.set('overdue','true');return params}
  actions.append(btn('Filtra scadenze',loadDue),btn('Stampa elenco filtrato',()=>openPdfForPrint('/pdf/payment-due?'+dueQuery())),btn('Esporta PDF filtrato',()=>downloadPdf('/pdf/payment-due?'+dueQuery(),'scadenziario-filtrato.pdf')),
                 btn('Azzera filtri',()=>render('payments')));
  filters.append(actions);view.append(filters);
  const summary=el('div',undefined,'stats'),list=el('div');view.append(summary,list);
  let visibleDue=[];
  async function loadDue(){const params=dueQuery();
    try{visibleDue=await api('/payment-due?'+params.toString());drawDue()}
    catch(error){notice(error.message,true)}}
  function drawDue(){list.replaceChildren();summary.replaceChildren();const open=visibleDue.filter(x=>x.status==='OPEN');
    const today=new Date().toISOString().slice(0,10);
    for(const [label,value] of [['Righe',visibleDue.length],['Da incassare €',displayIt(open.reduce((sum,x)=>sum+Number(x.amount),0))],
      ['Scaduto €',displayIt(open.filter(x=>x.due_date<today).reduce((sum,x)=>sum+Number(x.amount),0))]]){
      const item=el('div',undefined,'metric');item.append(el('strong',value),el('span',label));summary.append(item)}
    for(const due of visibleDue){const card=el('div',undefined,'record'),info=el('div',undefined,'summary'),row=el('div',undefined,'actions');
      info.append(el('strong',`${due.invoice_number} · ${due.customer_name} · € ${displayIt(due.amount)}`),el('br'),
                  el('small',`Scadenza ${due.due_date} · ${statusText(due.status)} · ${due.payment_method_name||'Nessuna modalità'}`));
      if(due.status==='OPEN'&&due.due_date<today)info.append(el('div','SCADUTA','danger-text'));
      if(editing){row.append(btn('Modifica / sposta data',()=>paymentEditor(dueFields,due,async data=>{
        await api(`/payment-due/${due.id}`,'PUT',data);await loadDue();$('paymentEditor')?.remove();notice('Scadenza aggiornata');
      },'Modifica scadenza')));
        if(due.status==='OPEN')row.append(btn('Segna pagata',async()=>{
          try{await api(`/payment-due/${due.id}`,'PUT',{invoice_id:due.invoice_id,payment_method_id:due.payment_method_id,
            due_date:due.due_date,amount:due.amount,status:'PAID',paid_at:null,notes:due.notes});await loadDue();notice('Pagamento registrato')}
          catch(error){notice(error.message,true)}}));
        row.append(btn('Archivia',async()=>{if(!confirm('Archiviare questa scadenza?'))return;
          try{await api(`/payment-due/${due.id}`,'DELETE');await loadDue()}catch(error){notice(error.message,true)}},'danger'))}
      card.append(info,row);list.append(card)}
    if(!visibleDue.length)list.append(el('p','Nessuna scadenza per i filtri selezionati.','muted'))}
  await loadDue();
}

function printDue(rows){if(!rows.length)return notice('Nessuna scadenza da stampare',true);
  const win=window.open('','_blank');if(!win)return notice('Consenti le finestre popup per stampare',true);
  const doc=win.document;doc.title='Scadenziario fatture';appendCompanyBrand(doc);
  doc.body.append(el('h1','Scadenziario fatture'),el('p',`Stampato il ${new Date().toLocaleString('it-IT')} · ${rows.length} scadenze`));
  const table=el('table'),head=el('tr');table.style.cssText='border-collapse:collapse;width:100%';
  for(const title of ['Cliente','Fattura','Scadenza','Importo €','Stato','Pagamento'])head.append(el('th',title));table.append(head);
  for(const due of rows){const tr=el('tr');for(const value of [due.customer_name,due.invoice_number,due.due_date,displayIt(due.amount),statusText(due.status),due.payment_method_name||''])tr.append(el('td',value));table.append(tr)}
  for(const cell of table.querySelectorAll('td,th'))cell.style.cssText='border:1px solid #bbb;padding:6px;text-align:left';
  doc.body.append(table);win.print();
}
async function renderInvoices(){let rows;try{refs['company-bank-accounts']=await api('/company-bank-accounts');refs['payment-methods']=await api('/payment-methods');rows=await api('/invoice-register')}catch(e){notice(e.message,true);return}refs['invoice-register']=rows;view.append(el('p','Crea una bozza, aggiungi articoli, manodopera e sconti oppure collega DDT/SAL dello stesso cliente. Controlla il totale e conferma: le rate verranno create automaticamente.','muted'));const fields=[['customer_id','Cliente','select'],['number','Numero fattura'],['issue_date','Data fattura','date'],['fiscal_document_type','Tipo fiscale','fiscaltype'],['taxable','Imponibile €'],['vat_amount','IVA €'],['total','Totale €'],['payment_method_id','Modalità pagamento','method'],['bank_account_id','Conto aziendale per la fattura','bank'],['status','Stato','status'],['notes','Note']];if(hasAccess('invoices',true))view.append(btn('＋ Crea fattura (bozza)',()=>invoiceEditor(fields.filter(([name])=>!['taxable','vat_amount','total','status'].includes(name)),{issue_date:new Date().toISOString().slice(0,10)},async data=>{const created=await api('/invoice-register','POST',data);await render('invoices');await invoiceLinePanel(created.id);notice('Bozza creata: aggiungi righe o collega DDT/SAL')},'Crea fattura (bozza)')));for(const invoice of rows){const record=el('div',undefined,'record'),actions=el('div',undefined,'actions');record.append(el('span',`${invoice.number} · ${invoice.customer_name} · ${invoice.issue_date} · € ${displayIt(invoice.total)} · ${invoice.document_status==='CONFIRMED'?'Confermata':'Bozza'} · ${statusText(invoice.status)}`));if(invoice.document_status!=='CONFIRMED'&&hasAccess('invoices',true))actions.append(btn('Modifica',()=>invoiceEditor(fields.filter(([name])=>!['taxable','vat_amount','total','status'].includes(name)),invoice,async data=>{await api(`/invoice-register/${invoice.id}`,'PUT',data);await render('invoices');notice('Fattura aggiornata')},'Modifica fattura')),btn('Archivia',async()=>{if(!confirm('Archiviare la registrazione della fattura?'))return;try{await api(`/invoice-register/${invoice.id}`,'DELETE');await render('invoices')}catch(e){notice(e.message,true)}},'danger'));actions.append(btn('Righe e conferma',()=>invoiceLinePanel(invoice.id)),...(invoice.document_status==='DRAFT'?[btn('Aggiungi DDT / SAL',()=>invoiceSources(invoice.id))]:[]),btn('Stampa',()=>openPdfForPrint(`/pdf/invoices/${invoice.id}`)),btn('Esporta PDF',()=>downloadPdf(`/pdf/invoices/${invoice.id}`,`Fattura-${invoice.number}.pdf`)),...(invoice.document_status==='CONFIRMED'?[btn('Esporta XML per verifica',()=>downloadPdf(`/invoice-register/${invoice.id}/xml-preview`,`IT-fattura-${invoice.number}.xml`))]:[]));if(hasAccess('payments'))actions.append(btn('Scadenze',()=>render('payments')));record.append(actions);view.append(record)}if(!rows.length)view.append(el('p','Nessuna fattura registrata.','muted'))}

function invoiceEditor(fields,values,save,title){paymentEditor(fields,values,save,title);const form=$('paymentEditor')?.querySelector('form');if(!form)return;for(const [caption,names] of [['1. Documento',['number','issue_date','customer_id','fiscal_document_type']],['2. Importi',['taxable','vat_amount','total']],['3. Pagamento e note',['payment_method_id','bank_account_id','status','notes']]]){const section=el('div',undefined,'form-section full'),grid=el('div',undefined,'grid');section.append(el('h3',caption));for(const name of names){const input=form.elements[name];if(input)grid.append(input.closest('label'))}if(grid.childElementCount){section.append(grid);form.insertBefore(section,form.lastElementChild)}}form.elements.payment_method_id.onchange=()=>{const method=(refs['payment-methods']||[]).find(x=>x.id===Number(form.elements.payment_method_id.value));if(method)form.elements.bank_account_id.value=method.bank_account_id||''}}


