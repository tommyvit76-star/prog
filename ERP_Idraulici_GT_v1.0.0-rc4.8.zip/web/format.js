'use strict';
function displayIt(value,digits=2){const number=Number(value);return Number.isFinite(number)?new Intl.NumberFormat('it-IT',{minimumFractionDigits:digits,maximumFractionDigits:digits}).format(number):String(value??'')}
function decimalInput(value){return String(value??'').replace('.',',')}
function parseIt(value){const text=String(value??'').trim();return Number(text.includes(',')?text.replace(/\./g,'').replace(',','.'):text)}
const twoDecimalFields=new Set(['discount_percent','discount_amount','vat_rate','work_minutes','amount','percent','variation_amount','retention_amount','advance_recovery','global_labor','global_labor_vat','global_travel','global_travel_vat','global_service','global_service_vat','global_discount','global_discount_vat','safety_costs','contract_discount_percent','advance_amount','retention_percent','discount_1','discount_2','discount_3','sale_discount_1','sale_discount_2','sale_discount_3','markup_percent']);
const threeDecimalFields=new Set(['kilometers','gross_weight','net_weight']);
function canonicalDecimal(value,field='',places=null){const number=parseIt(value);if(!Number.isFinite(number))return String(value??'');const digits=places??(twoDecimalFields.has(field)?2:threeDecimalFields.has(field)?3:4);return number.toFixed(digits).replace(/\.?0+$/,'')||'0'}
const documentStatusLabels={DRAFT:'Bozza',PLANNED:'Pianificato',OPEN:'Aperto',SENT:'Inviato',ISSUED:'Emesso',PARTIAL:'Parziale',PENDING:'In attesa',CONFIRMED:'Confermato',APPROVED:'Approvato',ACCEPTED:'Accettato',COMPLETED:'Completato',PAID:'Pagato',INVOICED:'Fatturato',CLOSED:'Chiuso',ARCHIVED:'Archiviato',CANCELLED:'Annullato',REJECTED:'Rifiutato',DISPUTED:'Contestato',SUSPENDED:'Sospeso',OVERDUE:'Scaduto'};
const positiveStatuses=new Set(['CONFIRMED','APPROVED','ACCEPTED','COMPLETED','PAID']),warningStatuses=new Set(['PARTIAL','PENDING','OPEN']),dangerStatuses=new Set(['CANCELLED','REJECTED','DISPUTED','SUSPENDED','OVERDUE']),finalStatuses=new Set(['INVOICED','CLOSED','ARCHIVED']);
function statusText(value){const code=String(value??'').toLocaleUpperCase('it-IT');return documentStatusLabels[code]||String(value??'')}
function statusClass(value){const code=String(value??'').toLocaleUpperCase('it-IT');return positiveStatuses.has(code)?'status-positive':warningStatuses.has(code)?'status-warning':dangerStatuses.has(code)?'status-danger':finalStatuses.has(code)?'status-final':code==='SENT'||code==='ISSUED'?'status-open':'status-neutral'}
function statusBadge(value){const badge=document.createElement('span');badge.className=`status-badge ${statusClass(value)}`;badge.textContent=statusText(value);badge.dataset.status=String(value??'');return badge}
const movementNames={LOAD:'Carico',TRANSFER:'Trasferimento',CONSUME:'Scarico',RETURN:'Rientro',SUPPLIER_RETURN:'Reso al fornitore',ADJUST:'Rettifica',REVERSAL:'Movimento di storno'};
function movementName(code){return movementNames[code]||code}
function stockStatus(quantity,minimum){const qty=parseIt(quantity),limit=parseIt(minimum);return qty<=0?['Esaurito','out']:qty<limit?['Sottoscorta','low']:['Disponibile','ok']}
function attachNumberPreview(form,kind,dateName,existing){
 const input=form.elements.number,date=form.elements[dateName];if(!input||!date)return;
 const label=input.closest('label'),preview=el('output',existing?input.value:'Caricamento…','document-number-value document-number-preview'),info=el('small',existing?'Numero registrato':'Il numero mostrato sarà confermato al salvataggio.','muted');label.append(preview,info);
 input.readOnly=true;input.placeholder='';input.hidden=!existing;if(existing)preview.hidden=true;
 if(user?.role==='ADMIN')label.append(btn('Modifica numero',()=>{input.hidden=false;preview.hidden=true;if(!input.value&&preview.value&&!preview.value.includes('Caricamento'))input.value=preview.value;input.readOnly=false;input.focus()}));
 if(existing)return;
 let latest=0;async function update(){const requested=++latest;if(!date.value){preview.value='Scegli la data';return}preview.value='Caricamento…';try{const result=await api(`/document-number/preview?kind=${kind}&issued_on=${date.value}`);if(requested===latest)preview.value=result.number}catch(error){if(requested===latest){preview.value='Numero non disponibile';info.textContent=error.message}}}
 date.addEventListener('change',update);update();
}
