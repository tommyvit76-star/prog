"use strict";
defs.jobs = { title: "Cantieri", fields: [] };
defs["credit-notes"] = { title: "Note di credito", fields: [] };
moduleNames.jobs = "Cantieri";
moduleNames["credit-notes"] = "Note di credito";

function professionalForm(title, fields, values, save) {
  const section = el("section", undefined, "panel"),
    form = el("form", undefined, "grid");
  form.dataset.saveOnExit = "true";
  section.append(el("h3", title));
  for (const spec of fields) {
    const [name, label, type, options] = spec,
      wrap = el("label", label);
    let input;
    if (type === "select") {
      input = el("select");
      for (const [value, text] of options || []) {
        const option = el("option", text);
        option.value = value;
        input.append(option);
      }
    } else {
      input = el(type === "textarea" ? "textarea" : "input");
      if (type && type !== "textarea") input.type = type;
      if (type === "decimal") input.inputMode = "decimal";
    }
    input.name = name;
    if (type === "checkbox") input.checked = Boolean(values?.[name]);
    else
      input.value =
        type === "decimal"
          ? decimalInput(values?.[name] ?? "")
          : (values?.[name] ?? "");
    if (["code", "name", "customer_id", "cause", "issue_date"].includes(name))
      input.required = true;
    wrap.append(input);
    if(name==='customer_id')attachRegistrySearch(wrap,input,'Cerca cliente per nome o iniziali');
    form.append(wrap);
  }
  const actions = el("div", undefined, "full actions"),
    submit = el("button", "Salva");
  submit.type = "submit";
  actions.append(
    submit,
    btn("Annulla", () => section.remove()),
  );
  form.append(actions);
  form.onsubmit = async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    for (const [name, , type] of fields) {
      if (type === "decimal") data[name] = String(parseIt(data[name]));
      if (type === "checkbox") data[name] = form.elements[name].checked;
      if (type === "date" && !data[name]) data[name] = null;
    }
    for (const name of [
      "customer_id",
      "quote_id",
      "project_id",
      "original_invoice_id",
      "warehouse_id",
    ])
      if (name in data) data[name] = data[name] ? Number(data[name]) : null;
    try {
      await save(data);
      delete form.dataset.dirty;
      form.dispatchEvent(new Event("erp:saved"));
    } catch (error) {
      showFormError(form, error);
      form.dispatchEvent(new Event("erp:save-failed"));
    }
  };
  section.append(form);
  view.append(section);
  section.scrollIntoView({ behavior: "smooth" });
  return form;
}

async function renderProjects() {
  let rows;
  try {
    rows = await api("/projects");
    refs.projects = rows;
    refs.quotes = await api("/quotes");
  } catch (error) {
    return notice(error.message, true);
  }
  const customers = (refs.customers || []).map((x) => [x.id, `${x.code ? x.code + ' · ' : ''}${x.name}`]),
    quotes = [
      ["", "Nessuno"],
      ...(refs.quotes || []).map((x) => [x.id, `${x.number} · ${x.title}`]),
    ],
    states = [
      ["PLANNED", "Da iniziare"],
      ["OPEN", "Aperto"],
      ["SUSPENDED", "Sospeso"],
      ["COMPLETED", "Terminato"],
      ["INVOICED", "Fatturato"],
      ["CLOSED", "Chiuso"],
    ];
  const fields = [
    ["code", "Codice cantiere"],
    ["name", "Nome cantiere"],
    ["customer_id", "Cliente", "select", customers],
    ["address", "Indirizzo cantiere"],
    ["quote_id", "Preventivo di origine", "select", quotes],
    ["contract_value", "Valore contratto €", "decimal"],
    ["variation_value", "Varianti €", "decimal"],
    ["contract_type", "Tipo contratto", "select", [["PRIVATE","Privato"],["PUBLIC","Pubblico"]]],
    ["contract_number", "Numero contratto"],
    ["contract_date", "Data contratto", "date"],
    ["vat_regime", "Regime IVA", "select", [["ORDINARY","Ordinario"],["REVERSE_CHARGE","Reverse charge edilizia"],["SPLIT_PAYMENT","Split payment PA"]]],
    ["cup", "CUP"],
    ["cig", "CIG"],
    ["safety_costs", "Oneri sicurezza €", "decimal"],
    ["contract_discount_percent", "Ribasso contratto %", "decimal"],
    ["advance_amount", "Anticipo €", "decimal"],
    ["retention_percent", "Ritenuta garanzia %", "decimal"],
    ["works_director", "Direttore lavori"],
    ["rup", "RUP"],
    ["manager", "Responsabile"],
    ["planned_start", "Inizio previsto", "date"],
    ["actual_start", "Inizio effettivo", "date"],
    ["planned_end", "Fine prevista", "date"],
    ["actual_end", "Fine effettiva", "date"],
    ["status", "Stato", "select", states],
    ["technical_notes", "Note tecniche", "textarea"],
    ["administrative_notes", "Note amministrative", "textarea"],
  ];
  if (hasAccess("jobs", true))
    view.append(
      btn("＋ Nuovo cantiere", () =>
        professionalForm(
          "Nuovo cantiere",
          fields,
          { status: "PLANNED", contract_value: "0", variation_value: "0",contract_type:"PRIVATE",vat_regime:"ORDINARY",safety_costs:"0",contract_discount_percent:"0",advance_amount:"0",retention_percent:"0" },
          async (data) => {
            await api("/projects", "POST", data);
            await render("jobs");
            notice("Cantiere creato");
          },
        ),
      ),
    );
  for (const p of rows) {
    const record = el("div", undefined, "record"),
      info = el("div", undefined, "summary"),
      actions = el("div", undefined, "actions");
    info.append(
      el("strong", `${p.code} · ${p.name}`),
      el("br"),
      el("span", `${p.customer_name} · `),statusBadge(p.status),
      el("br"),
      el(
        "small",
        `Contratto € ${displayIt(p.contract_total)} · SAL € ${displayIt(p.sal_amount)} · Fatturato € ${displayIt(p.invoiced)} · Residuo € ${displayIt(p.remaining_to_sal)} · DDT ${p.ddt_count}`,
      ),
    );
    actions.append(
      btn("Situazione PDF", () =>
        downloadPdf(`/pdf/projects/${p.id}`, `Cantiere-${p.code}.pdf`),
      ),
    );
    const links=el("div",undefined,"project-links");
    for(const q of p.quotes||[]){const line=el("div",undefined,"document-reference"),text=el("span",`Preventivo ${q.number} del ${q.issue_date}`);line.append(text);if(hasAccess("jobs",true))line.append(btn("Dissocia",async()=>{if(!confirm(`Dissociare il preventivo ${q.number} dal cantiere?`))return;try{await api(`/projects/${p.id}/quotes/${q.id}`,'DELETE');await render('jobs');notice('Documento dissociato correttamente')}catch(error){notice(`Impossibile dissociare il documento: ${error.message}`,true)}},"document-remove"));links.append(line)}
    for(const s of p.sals||[]){const line=el("div",undefined,"document-reference"),text=el("span",`SAL ${s.number} del ${s.issued_on}`);line.append(text);if(hasAccess("jobs",true)&&s.approval_status!=="INVOICED")line.append(btn("Dissocia",async()=>{if(!confirm(`Dissociare il SAL ${s.number} dal cantiere?`))return;try{await api(`/projects/${p.id}/sals/${s.id}`,'DELETE');await render('jobs');notice('Documento dissociato correttamente')}catch(error){notice(`Impossibile dissociare il documento: ${error.message}`,true)}},"document-remove"));links.append(line)}
    if(links.childElementCount)info.append(links);
    if (hasAccess("jobs", true))
      actions.append(
        btn("Modifica", () =>
          professionalForm("Modifica cantiere", fields, p, async (data) => {
            await api(`/projects/${p.id}`, "PUT", data);
            await render("jobs");
            notice("Cantiere aggiornato");
          }),
        ),
        btn("Associa preventivo", () => projectQuotePicker(p)),
        btn("Crea SAL", () => salDocumentPage(null,{project_id:p.id,customer_id:p.customer_id,quote_id:p.quote_id||null})),
        btn("Associa SAL esistente", () => projectSalPicker(p)),
        btn("Apri DDT", () => render("ddt")),
      );
    record.append(info, actions);
    view.append(record);
  }
  if (!rows.length)
    view.append(
      el(
        "p",
        "Nessun cantiere. Crea la commessa prima di collegare DDT e SAL.",
        "muted",
      ),
    );
}

function projectPicker(title,rows,label,save){const section=el('section',undefined,'panel project-picker');section.append(el('h3',title));const select=el('select');select.append(el('option','Seleziona…'));for(const row of rows){const option=el('option',label(row));option.value=row.id;select.append(option)}const actions=el('div',undefined,'actions');actions.append(select,btn('Associa',async()=>{if(!select.value)return;try{await save(Number(select.value));await render('jobs');notice('Documento associato al cantiere')}catch(error){notice(error.message,true)}}),btn('Annulla',()=>section.remove(),'secondary'));section.append(actions);view.prepend(section);section.scrollIntoView({behavior:'smooth'})}
function projectQuotePicker(project){const linked=new Set((project.quotes||[]).map(x=>x.id));projectPicker(`Associa preventivo a ${project.code}`,(refs.quotes||[]).filter(q=>q.customer_id===project.customer_id&&!linked.has(q.id)&&q.status!=='REJECTED'&&!q.linked_invoice),q=>`${q.number} · ${q.title}`,id=>api(`/projects/${project.id}/quotes/${id}`,'POST'))}
async function projectSalPicker(project){const rows=(refs.salRecords||await api('/progress-certificates')).filter(s=>s.customer_id===project.customer_id&&!s.project_id&&s.approval_status!=='INVOICED');projectPicker(`Associa SAL a ${project.code}`,rows,s=>`${s.number} · ${s.issued_on} · ${statusText(s.approval_status)}`,id=>api(`/projects/${project.id}/sals/${id}`,'POST'))}

async function renderCreditNotes() {
  let notes, invoices;
  try {
    [notes, invoices] = await Promise.all([
      api("/credit-notes"),
      api("/invoice-register"),
    ]);
  } catch (error) {
    return notice(error.message, true);
  }
  const confirmed = invoices.filter((x) => x.document_status === "CONFIRMED"),
    fields = [
      [
        "original_invoice_id",
        "Fattura da accreditare",
        "select",
        confirmed.map((x) => [
          x.id,
          `${x.number} · ${x.customer_name} · € ${displayIt(x.total)}`,
        ]),
      ],
      ["issue_date", "Data nota", "date"],
      ["number", "Numero nota"],
      ["cause", "Causale"],
      ["notes", "Note", "textarea"],
    ];
  if (hasAccess("credit-notes", true))
    view.append(
      btn("＋ Nuova nota di credito", () =>
        professionalForm(
          "Nuova nota di credito TD04",
          fields,
          { issue_date: new Date().toISOString().slice(0, 10) },
          async (data) => {
            const note = await api("/credit-notes", "POST", data);
            await render("credit-notes");
            await creditDetail(note.id);
            notice("Nota creata in bozza: controlla le righe");
          },
        ),
      ),
    );
  for (const note of notes) {
    const row = el("div", undefined, "record"),
      actions = el("div", undefined, "actions");
    row.append(
      el(
        "span",
        `${note.number} · ${note.customer_name} · fattura ${note.original_invoice_number} · € ${displayIt(note.total)} · ${statusText(note.status)}`,
      ),
    );
    actions.append(
      btn("Scheda", () => creditDetail(note.id)),
      btn("Esporta PDF", () =>
        downloadPdf(
          `/pdf/credit-notes/${note.id}`,
          `Nota-credito-${note.number}.pdf`,
        ),
      ),
    );
    if (note.status === "CONFIRMED")
      actions.append(
        btn("XML TD04 per verifica", () =>
          downloadPdf(
            `/credit-notes/${note.id}/xml-preview`,
            `Nota-credito-${note.number}.xml`,
          ),
        ),
      );
    row.append(actions);
    view.append(row);
  }
  if (!notes.length) view.append(el("p", "Nessuna nota di credito.", "muted"));
}

async function creditDetail(id) {
  let note;
  try {
    note = await api(`/credit-notes/${id}`);
  } catch (error) {
    return notice(error.message, true);
  }
  $("detail")?.remove();
  const pane = el("section", undefined, "panel");
  pane.id = "detail";
  pane.append(
    el("h3", `Nota di credito ${note.number}`),
    el(
      "p",
      `Fattura originaria ${note.original_invoice_number} del ${note.original_invoice_date} · ${note.cause}`,
    ),
  );
  for (const line of note.lines) {
    const row = el("div", undefined, "record"),
      info = el(
        "span",
        `${line.code} · ${line.description} · ${displayIt(line.quantity, 4)} ${line.unit_code} · imponibile € ${displayIt(line.taxable)} · IVA € ${displayIt(line.vat_amount)}`,
      ),
      actions = el("div", undefined, "actions");
    if (note.status === "DRAFT" && hasAccess("credit-notes", true)) {
      actions.append(
        btn("Modifica quantità / rientro", () =>
          creditLineEditor(note, line, pane),
        ),
        btn(
          "Rimuovi",
          async () => {
            if (!confirm("Rimuovere la riga dalla nota?")) return;
            await api(`/credit-notes/${note.id}/lines/${line.id}`, "DELETE");
            await creditDetail(note.id);
          },
          "danger",
        ),
      );
    }
    row.append(info, actions);
    pane.append(row);
  }
  pane.append(
    el(
      "p",
      `Imponibile € ${displayIt(note.taxable)} · IVA € ${displayIt(note.vat_amount)} · Totale € ${displayIt(note.total)}`,
      "quote-total",
    ),
  );
  if (note.status === "DRAFT" && hasAccess("credit-notes", true))
    pane.append(
      btn("Conferma nota e aggiorna scadenze", async () => {
        if (
          !confirm(
            "Confermare la nota? Le scadenze aperte saranno ridotte e gli eventuali rientri registrati.",
          )
        )
          return;
        try {
          await api(`/credit-notes/${note.id}/confirm`, "POST");
          await render("credit-notes");
          await creditDetail(note.id);
          notice("Nota di credito confermata");
        } catch (error) {
          notice(error.message, true);
        }
      }),
      btn(
        "Archivia bozza",
        async () => {
          if (!confirm("Archiviare la bozza?")) return;
          await api(`/credit-notes/${note.id}`, "DELETE");
          await render("credit-notes");
        },
        "danger",
      ),
    );
  view.append(pane);
  pane.scrollIntoView({ behavior: "smooth" });
}

function creditLineEditor(note, line, pane) {
  pane.querySelector("#creditLineEditor")?.remove();
  const warehouses = [
      ["", "Nessuno"],
      ...(refs.warehouses || []).map((x) => [x.id, x.name]),
    ],
    form = professionalForm(
      "Riga nota di credito",
      [
        ["quantity", "Quantità da accreditare", "decimal"],
        ["restock", "Rientra in magazzino", "checkbox"],
        ["warehouse_id", "Magazzino di rientro", "select", warehouses],
      ],
      line,
      async (data) => {
        await api(`/credit-notes/${note.id}/lines/${line.id}`, "PUT", data);
        await render("credit-notes");
        await creditDetail(note.id);
        notice("Riga aggiornata");
      },
    );
  form.closest("section").id = "creditLineEditor";
}

async function renderTransportAdmin() {
  const panel = el("section", undefined, "panel");
  panel.id = "transportSettings";
  panel.append(
    el("h3", "Configurazione DDT e trasporti"),
    el(
      "p",
      "Questi valori vengono selezionati nelle DDT. Le proprietà della causale determinano fatturazione e movimento di magazzino.",
      "muted",
    ),
  );
  const kinds = [
    ["reasons", "Causali di trasporto"],
    ["appearances", "Aspetto dei beni"],
    ["ports", "Tipi di porto"],
    ["modes", "Modalità di trasporto"],
  ];
  function configEditor(kind, row = null) {
    const fields = [["name", "Nome"]];
    if (kind === "reasons")
      fields.push(
        ["invoiceable", "Fatturabile", "checkbox"],
        [
          "stock_action",
          "Movimento magazzino",
          "select",
          [
            ["NONE", "Nessuno"],
            ["CONSUME", "Scarico"],
            ["LOAD", "Carico / reso"],
          ],
        ],
        ["requires_return", "Richiede rientro", "checkbox"],
      );
    professionalForm(
      row ? "Modifica configurazione" : "Nuova configurazione",
      fields,
      row || { stock_action: "NONE" },
      async (data) => {
        await api(
          row
            ? `/admin/transport-config/${kind}/${row.id}`
            : `/admin/transport-config/${kind}`,
          row ? "PUT" : "POST",
          data,
        );
        await render("admin");
      },
    );
  }
  for (const [kind, label] of kinds) {
    const block = el("div", undefined, "form-section"),
      list = el("div");
    block.append(el("h4", label), list);
    let rows = [];
    try {
      rows = await api(`/admin/transport-config/${kind}`);
    } catch (error) {
      list.append(el("p", error.message, "error"));
    }
    for (const row of rows) {
      const record = el("div", undefined, "record"),
        text =
          kind === "reasons"
            ? `${row.name} · ${row.invoiceable ? "fatturabile" : "non fatturabile"} · magazzino ${row.stock_action} ${row.requires_return ? "· richiede rientro" : ""}`
            : row.name;
      record.append(
        el("span", text),
        btn("Modifica", () => configEditor(kind, row)),
        btn(
          "Archivia",
          async () => {
            if (!confirm("Archiviare questo valore?")) return;
            await api(`/admin/transport-config/${kind}/${row.id}`, "DELETE");
            await render("admin");
          },
          "danger",
        ),
      );
      list.append(record);
    }
    block.append(btn("＋ Aggiungi", () => configEditor(kind)));
    panel.append(block);
  }
  const carriers = await api("/carriers");
  const carriersBlock = el("div", undefined, "form-section");
  carriersBlock.append(el("h4", "Vettori"));
  const carrierFields = [
    ["name", "Ragione sociale"],
    ["vat_number", "Partita IVA"],
    ["address", "Indirizzo"],
    ["postal_code", "CAP"],
    ["city", "Città"],
    ["province", "Provincia"],
    ["driver_name", "Autista"],
    ["vehicle_plate", "Targa"],
  ];
  function carrierEditor(carrier = null) {
    professionalForm(
      carrier ? "Modifica vettore" : "Nuovo vettore",
      carrierFields,
      carrier || {},
      async (data) => {
        await api(
          carrier ? `/carriers/${carrier.id}` : "/carriers",
          carrier ? "PUT" : "POST",
          data,
        );
        await render("admin");
      },
    );
  }
  for (const carrier of carriers) {
    const record = el("div", undefined, "record"),
      actions = el("div", undefined, "actions");
    record.append(
      el(
        "span",
        `${carrier.name} · ${carrier.vat_number} · ${carrier.city} · ${carrier.vehicle_plate}`,
      ),
    );
    actions.append(
      btn("Modifica", () => carrierEditor(carrier)),
      btn(
        "Archivia",
        async () => {
          if (!confirm("Archiviare il vettore?")) return;
          await api(`/carriers/${carrier.id}`, "DELETE");
          await render("admin");
        },
        "danger",
      ),
    );
    record.append(actions);
    carriersBlock.append(record);
  }
  carriersBlock.append(btn("＋ Nuovo vettore", () => carrierEditor()));
  panel.append(carriersBlock);
  view.append(panel);
}

async function renderFiscalAdmin() {
  const panel = el("section", undefined, "panel");
  panel.append(
    el("h3", "Gestione esercizi"),
    el("p", "La chiusura crea prima un backup, blocca l'anno in sola lettura e apre l'esercizio successivo. Anagrafiche, giacenze, cantieri e partite aperte restano collegate.", "muted"),
  );
  let state;
  try { state = await api("/fiscal-years"); } catch (error) { panel.append(el("p", error.message, "error")); view.append(panel); return; }
  for (const year of state.years) {
    const row = el("div", undefined, "record"), info = el("span", `${year.year} · ${year.status === "CLOSED" ? "Chiuso" : "Aperto"} · ${year.starts_on} / ${year.ends_on}`), actions = el("div", undefined, "actions");
    actions.append(btn("Controlla", async () => {
      try {
        const result = await api(`/admin/fiscal-years/${year.year}/precheck`);
        const lines = [...result.blockers.map(x => `BLOCCANTE: ${x.label} (${x.count})`), ...result.warnings.map(x => `DA RIPORTARE: ${x.label} (${x.count})`)];
        notice(lines.length ? lines.join(" · ") : `Esercizio ${year.year} pronto per la chiusura`, Boolean(result.blockers.length));
      } catch (error) { notice(error.message, true); }
    }));
    if (year.status === "OPEN") actions.append(btn("Chiudi esercizio", async () => {
      const check = await api(`/admin/fiscal-years/${year.year}/precheck`);
      if (check.blockers.length) return notice("Completa prima: " + check.blockers.map(x => `${x.label} (${x.count})`).join(", "), true);
      const warningText = check.warnings.map(x => `${x.label} (${x.count})`).join(", ");
      if (!confirm(`Chiudere definitivamente il ${year.year}? Verrà creato un backup e aperto il ${year.year + 1}.${warningText ? " Saranno riportati: " + warningText : ""}`)) return;
      const notes = prompt("Nota di chiusura (facoltativa)", "Chiusura esercizio") || "";
      try { await api(`/admin/fiscal-years/${year.year}/close`, "POST", {notes, accept_warnings: true}); await loadFiscalYears(); await render("admin"); notice(`Esercizio ${year.year} chiuso e ${year.year + 1} aperto`); } catch (error) { notice(error.message, true); }
    }, "danger"));
    else actions.append(btn("Riapri", async () => {
      const reason = prompt("Motivazione obbligatoria per la riapertura"); if (!reason) return;
      try { await api(`/admin/fiscal-years/${year.year}/reopen`, "POST", {notes: reason, accept_warnings: false}); await loadFiscalYears(); await render("admin"); } catch (error) { notice(error.message, true); }
    }));
    row.append(info, actions); panel.append(row);
  }
  view.append(panel);
}

const baseRender = render;
render = async function (key) {
  if (key === "jobs") {
    active = key;
    clear("Cantieri");
    await loadRefs();
    return renderProjects();
  }
  if (key === "credit-notes") {
    active = key;
    clear("Note di credito");
    await loadRefs();
    return renderCreditNotes();
  }
  return baseRender(key);
};
const baseAdmin = renderAdmin;
renderAdmin = async function () {
  await baseAdmin();
  if (user.role === "ADMIN") { await renderTransportAdmin(); await renderFiscalAdmin(); }
};

async function loadTransportRefs() {
  for (const [key, path] of [
    ["transport-reasons", "reasons"],
    ["goods-appearances", "appearances"],
    ["port-terms", "ports"],
    ["transport-modes", "modes"],
  ]) {
    try {
      refs[key] = await api("/admin/transport-config/" + path);
    } catch {
      refs[key] = [];
    }
  }
  try {
    refs.carriers = await api("/carriers");
  } catch {
    refs.carriers = [];
  }
  try {
    refs.projects = await api("/projects");
  } catch {
    refs.projects = [];
  }
}
function replaceFieldSelect(form, name, rows, empty = "Seleziona") {
  const old = form.elements[name];
  if (!old) return null;
  const select = el("select");
  select.name = name;
  const first = el("option", empty);
  first.value = "";
  select.append(first);
  for (const [value, label] of rows) {
    const option = el("option", label);
    option.value = value;
    select.append(option);
  }
  select.value = old.value || "";
  old.replaceWith(select);
  return select;
}
const baseDeliveries = renderDeliveries;
renderDeliveries = async function () {
  await loadTransportRefs();
  return baseDeliveries();
};

async function salDocumentPage(id = null) {
  clear(id ? "Stato avanzamento lavori" : "Nuovo SAL"); await loadRefs(); refs.projects = await api("/projects"); refs.quotes = await api("/quotes");
  const rows = await api("/progress-certificates"), record = id ? rows.find(x => x.id === id) : null; refs.salRecords = rows;
  const top = el("div", undefined, "actions no-print"); top.append(btn("← Torna all'elenco SAL", () => navigateTo("sal"))); if (record) top.append(btn("Stampa", () => openPdfForPrint(`/pdf/sal/${record.id}`)), btn("Esporta PDF", () => downloadPdf(`/pdf/sal/${record.id}`, `SAL-${record.number}.pdf`))); view.append(top);
  if (id && !record) return notice("SAL non trovato nell'esercizio selezionato", true);
  salEditor(salFields, record || {issued_on:defaultFiscalDate(),percent:"25",vat_rate:"22",status:"PARTIAL",approval_status:"DRAFT",sequence_no:1}, async data => {
    data.quote_id=data.quote_id||null; await api(record?`/progress-certificates/${record.id}`:"/progress-certificates",record?"PUT":"POST",data); await render("sal"); notice("SAL salvato e aggiunto all’elenco");
  }, record ? "Modifica SAL" : "Nuovo SAL");
  const cancel=$("paymentEditor")?.querySelector("button.secondary"); if(cancel)cancel.onclick=()=>render("sal");
  if(record)view.append(el("p",`Avanzamento precedente ${displayIt(record.previous_percent)}% · corrente ${displayIt(record.percent)}% · cumulato ${displayIt(parseIt(record.previous_percent)+parseIt(record.percent))}% · stato ${statusText(record.approval_status)}`,"quote-total"));
}

renderSal = async function () {
  try { refs.projects=await api("/projects"); refs.quotes=await api("/quotes"); refs.salRecords=await api("/progress-certificates"); } catch(error){return notice(error.message,true)}
  view.append(el("p",`SAL dell'esercizio ${fiscalYear}. Ogni SAL si apre in una pagina separata ed è collegabile a un cantiere.`,"muted"));
  if(hasAccess("sal",true)&&fiscalYears.find(x=>x.year===fiscalYear)?.status==="OPEN")view.append(btn("＋ Nuovo SAL",()=>salDocumentPage()));
  for(const item of refs.salRecords){const row=el("div",undefined,"record"),summary=el("div",undefined,"summary"),actions=el("div",undefined,"actions"),linked=Boolean(item.linked_invoice_id);summary.append(el("span",`${item.number} · ${item.project_code?"Cantiere "+item.project_code:item.customer_name} · SAL n. ${item.sequence_no} · ${displayIt(item.percent)}%${linked?" · Fattura "+item.linked_invoice_number:""}`),statusBadge(item.approval_status));row.append(summary);actions.append(btn("Apri",()=>salDocumentPage(item.id)),btn("Stampa",()=>openPdfForPrint(`/pdf/sal/${item.id}`)),btn("Esporta PDF",()=>downloadPdf(`/pdf/sal/${item.id}`,`SAL-${item.number}.pdf`)));if(linked)actions.append(btn("Apri fattura collegata",()=>invoiceDocumentPage(item.linked_invoice_id)));else if(hasAccess("sal",true))actions.append(btn("Archivia",async()=>{if(!confirm("Archiviare il SAL non collegato?"))return;try{await api(`/progress-certificates/${item.id}`,"DELETE");await render("sal")}catch(error){notice(error.message,true)}},"danger"));row.append(actions);view.append(row)}if(!refs.salRecords.length)view.append(el("p","Nessun SAL nell'esercizio selezionato.","muted"));
};

async function creditDocumentPage(id=null){
  clear(id?"Nota di credito":"Nuova nota di credito");await loadRefs();const notes=await api("/credit-notes"),invoices=await api("/invoice-register"),note=id?notes.find(x=>x.id===id):null;
  const top=el("div",undefined,"actions no-print");top.append(btn("← Torna alle note di credito",()=>navigateTo("credit-notes")));if(note)top.append(btn("Stampa",()=>openPdfForPrint(`/pdf/credit-notes/${note.id}`)),btn("Esporta PDF",()=>downloadPdf(`/pdf/credit-notes/${note.id}`,`Nota-credito-${note.number}.pdf`)));view.append(top);
  if(id){if(!note)return notice("Nota non trovata nell'esercizio selezionato",true);await creditDetail(note.id);return}
  const confirmed=invoices.filter(x=>x.document_status==="CONFIRMED"),fields=[["original_invoice_id","Fattura da accreditare","select",confirmed.map(x=>[x.id,`${x.number} · ${x.customer_name} · € ${displayIt(x.total)}`])],["issue_date","Data nota","date"],["number","Numero nota"],["cause","Causale"],["notes","Note","textarea"]];
  const form=professionalForm("Nuova nota di credito TD04",fields,{issue_date:defaultFiscalDate()},async data=>{const created=await api("/credit-notes","POST",data);await creditDocumentPage(created.id);notice("Nota creata in bozza: controlla le righe")});const cancel=form.querySelector("button.secondary");if(cancel)cancel.onclick=()=>render("credit-notes");
}

renderCreditNotes=async function(){let notes;try{notes=await api("/credit-notes")}catch(error){return notice(error.message,true)}view.append(el("p",`Note di credito dell'esercizio ${fiscalYear}. Ogni documento si apre in una pagina separata.`,"muted"));if(hasAccess("credit-notes",true)&&fiscalYears.find(x=>x.year===fiscalYear)?.status==="OPEN")view.append(btn("＋ Nuova nota di credito",()=>creditDocumentPage()));for(const note of notes){const row=el("div",undefined,"record"),summary=el("div",undefined,"summary"),actions=el("div",undefined,"actions");summary.append(el("span",`${note.number} · ${note.customer_name} · fattura ${note.original_invoice_number} · € ${displayIt(note.total)}`),statusBadge(note.status));row.append(summary);actions.append(...(note.status==="DRAFT"?[btn("Conferma",()=>creditDocumentPage(note.id))]:[]),btn("Apri",()=>creditDocumentPage(note.id)),btn("Stampa",()=>openPdfForPrint(`/pdf/credit-notes/${note.id}`)),btn("Esporta PDF",()=>downloadPdf(`/pdf/credit-notes/${note.id}`,`Nota-credito-${note.number}.pdf`)));row.append(actions);view.append(row)}if(!notes.length)view.append(el("p","Nessuna nota di credito nell'esercizio selezionato.","muted"))};
const baseDeliveryEditor = deliveryEditor;
deliveryEditor = function (fields, values, save, title) {
  const normalizedSave = async (data) => {
    for (const key of [
      "quote_id",
      "project_id",
      "transport_reason_id",
      "goods_appearance_id",
      "port_term_id",
      "transport_mode_id",
      "carrier_id",
    ])
      data[key] = data[key] ? Number(data[key]) : null;
    for (const key of [
      "transport_date",
      "transport_time",
      "return_due_date",
    ])
      data[key] = data[key] || null;
    data.package_count = Number(data.package_count || 0);
    await save(data);
  };
  baseDeliveryEditor(fields, values, normalizedSave, title);
  const form = $("paymentEditor")?.querySelector("form");
  if (!form) return;
  replaceFieldSelect(
    form,
    "quote_id",
    (refs.quotes || []).map((x) => [x.id, `${x.number} · ${x.title} · ${x.customer_name}`]),
    "Nessun preventivo",
  );
  replaceFieldSelect(
    form,
    "project_id",
    (refs.projects || [])
      .filter(
        (x) =>
          !values?.customer_id || x.customer_id === Number(values.customer_id),
      )
      .map((x) => [x.id, `${x.code} · ${x.name}`]),
    "Nessun cantiere",
  );
  replaceFieldSelect(
    form,
    "transport_reason_id",
    (refs["transport-reasons"] || []).map((x) => [x.id, x.name]),
  );
  replaceFieldSelect(
    form,
    "goods_appearance_id",
    (refs["goods-appearances"] || []).map((x) => [x.id, x.name]),
  );
  replaceFieldSelect(
    form,
    "port_term_id",
    (refs["port-terms"] || []).map((x) => [x.id, x.name]),
  );
  const mode = replaceFieldSelect(
    form,
    "transport_mode_id",
    (refs["transport-modes"] || []).map((x) => [x.id, x.name]),
  );
  const carrier = replaceFieldSelect(
    form,
    "carrier_id",
    (refs.carriers || []).map((x) => [
      x.id,
      `${x.name}${x.vehicle_plate ? " · " + x.vehicle_plate : ""}`,
    ]),
    "Nessun vettore",
  );
  for (const name of ["gross_weight", "net_weight"])
    form.elements[name].inputMode = "decimal";
  form.elements.package_count.type = "number";
  form.elements.package_count.min = "1";
  for (const name of ["customer_id", "issued_on", "warehouse_id", "shipping_address", "transport_reason_id", "goods_appearance_id", "port_term_id", "transport_mode_id", "package_count"])
    if (form.elements[name]) form.elements[name].required = true;
  form.elements.weight_unit.value = form.elements.weight_unit.value || "kg";
  function toggle() {
    const selected = (refs["transport-modes"] || []).find(
      (x) => x.id === Number(mode.value),
    );
    carrier
      .closest("label")
      .classList.toggle("hidden", selected?.name !== "Vettore");
    carrier.required = selected?.name === "Vettore";
  }
  mode.onchange = toggle;
  toggle();
};
const baseSal = renderSal;
renderSal = async function () {
  try {
    refs.projects = await api("/projects");
  } catch {
    refs.projects = [];
  }
  return baseSal();
};
const baseSalEditor = salEditor;
salEditor = function (fields, values, save, title) {
  const normalizedSave = async (data) => {
    data.project_id = data.project_id ? Number(data.project_id) : null;
    data.sequence_no = Number(data.sequence_no || 1);
    await save(data);
  };
  baseSalEditor(fields, values, normalizedSave, title);
  const form = $("paymentEditor")?.querySelector("form");
  if (!form) return;
  replaceFieldSelect(
    form,
    "project_id",
    (refs.projects || [])
      .filter(
        (x) =>
          !values?.customer_id || x.customer_id === Number(values.customer_id),
      )
      .map((x) => [x.id, `${x.code} · ${x.name}`]),
    "Nessun cantiere",
  );
  replaceFieldSelect(form, "approval_status", [
    ["DRAFT", "Bozza"],
    ["ISSUED", "Emesso"],
    ["APPROVED", "Approvato"],
    ["DISPUTED", "Contestato"],
    ["INVOICED", "Fatturato"],
  ]);
  for (const name of [
    "variation_amount",
    "retention_amount",
    "advance_recovery",
  ])
    form.elements[name].inputMode = "decimal";
  form.elements.sequence_no.type = "number";
  form.elements.sequence_no.min = "1";
};

const baseInvoiceEditor = invoiceEditor;
invoiceEditor = function (fields, values, save, title) {
  const extended = fields.some(([name]) => name === "project_id")
    ? fields
    : [...fields, ["project_id", "Cantiere collegato"]];
  const normalizedSave = async (data) => {
    data.project_id = data.project_id ? Number(data.project_id) : null;
    await save(data);
  };
  baseInvoiceEditor(extended, values, normalizedSave, title);
  const form = $("paymentEditor")?.querySelector("form");
  if (!form) return;
  replaceFieldSelect(
    form,
    "project_id",
    (refs.projects || [])
      .filter(
        (x) =>
          !values?.customer_id || x.customer_id === Number(values.customer_id),
      )
      .map((x) => [x.id, `${x.code} · ${x.name}`]),
    "Nessun cantiere",
  );
};

async function deliveryDocumentPage(id = null) {
  clear(id ? "Documento di trasporto" : "Nuovo DDT");
  await loadRefs(); await loadTransportRefs();
  const docs = await api("/delivery-notes"), doc = id ? docs.find(x => x.id === id) : null;
  const top = el("div", undefined, "actions no-print"); top.append(btn("← Torna all'elenco DDT", () => render("ddt")));
  if (doc) top.append(btn("Stampa", () => openPdfForPrint(`/pdf/ddt/${doc.id}`)), btn("Esporta PDF", () => downloadPdf(`/pdf/ddt/${doc.id}`, `DDT-${doc.number}.pdf`)));
  view.append(top);
  if (id && !doc) return notice("DDT non trovato nell'esercizio selezionato", true);
  if (!doc || doc.status === "DRAFT") {
    deliveryEditor(deliveryFields, doc || {issued_on: defaultFiscalDate()}, async data => {
      const saved = await api(doc ? `/delivery-notes/${doc.id}` : "/delivery-notes", doc ? "PUT" : "POST", data);
      await deliveryDocumentPage(doc?.id || saved.id); notice("Intestazione DDT salvata: ora puoi aggiungere le righe");
    }, doc ? "Intestazione DDT" : "Nuovo DDT");
    const cancel = $("paymentEditor")?.querySelector("button.secondary"); if (cancel) cancel.onclick = () => render("ddt");
  }
  if (doc) await deliveryDetail(doc.id);
  else view.append(el("p", "Salva l'intestazione: le righe articolo appariranno nella stessa pagina.", "muted"));
}

renderDeliveries = async function () {
  await loadTransportRefs(); let documents;
  try { documents = await api("/delivery-notes"); } catch (error) { return notice(error.message, true); }
  view.append(el("p", `DDT dell'esercizio ${fiscalYear}. Ogni documento si apre in una pagina separata.`, "muted"));
  if (hasAccess("ddt", true) && fiscalYears.find(x => x.year === fiscalYear)?.status === "OPEN") view.append(btn("＋ Nuovo DDT", () => deliveryDocumentPage()));
  for (const doc of documents) {
    const row = el("div", undefined, "record"), actions = el("div", undefined, "actions");
    const summary=el("div",undefined,"summary");summary.append(el("strong", `${doc.number} · ${doc.customer_name} · ${doc.issued_on} · ${doc.lines.length} righe`),statusBadge(doc.status));row.append(summary);
    actions.append(btn("Apri", () => deliveryDocumentPage(doc.id)), btn("Stampa", () => openPdfForPrint(`/pdf/ddt/${doc.id}`)), btn("Esporta PDF", () => downloadPdf(`/pdf/ddt/${doc.id}`, `DDT-${doc.number}.pdf`)));
    if (doc.status === "DRAFT" && hasAccess("ddt", true)) actions.append(btn("Archivia", async () => { if (!confirm("Archiviare la bozza DDT?")) return; try { await api(`/delivery-notes/${doc.id}`, "DELETE"); await render("ddt"); } catch (error) { notice(error.message, true); } }, "danger"));
    row.append(actions); view.append(row);
  }
  if (!documents.length) view.append(el("p", "Nessun DDT nell'esercizio selezionato.", "muted"));
};

/* RC4.1: the DDT header, commercial rows, transport data and totals live in one editor. */
deliveryDocumentPage = async function (id = null) {
  clear(id ? "Documento di trasporto" : "Nuovo DDT");
  await loadRefs(); await loadTransportRefs(); refs.quotes=await api("/quotes");
  const docs=await api("/delivery-notes"),doc=id?docs.find(x=>x.id===id):null;
  const top=el("div",undefined,"actions no-print");top.append(btn("← Torna all'elenco DDT",()=>navigateTo("ddt")));
  if(doc)top.append(btn("Stampa",()=>openPdfForPrint(`/pdf/ddt/${doc.id}`)),btn("Esporta PDF",()=>downloadPdf(`/pdf/ddt/${doc.id}`,`DDT-${doc.number}.pdf`)));
  view.append(top);
  if(id&&!doc)return notice("DDT non trovato nell'esercizio selezionato",true);
  if(doc?.status==="CONFIRMED"){await deliveryDetail(doc.id);return}

  let draftLines=(doc?.lines||[]).map(line=>({...line,code:line.product_code||""}));
  deliveryEditor(deliveryFields,doc||{issued_on:defaultFiscalDate(),weight_unit:"kg",package_count:1},async header=>{
    if(!draftLines.length)throw Error("Aggiungi almeno una riga di materiale, manodopera, trasferta o sconto");
    const payload={header,lines:draftLines.map(line=>({
      id:line.id||null,product_id:line.product_id?Number(line.product_id):null,quote_line_id:line.quote_line_id?Number(line.quote_line_id):null,
      kind:line.kind||"PRODUCT",code:line.code||line.product_code||"",description:line.description||"",unit_code:line.unit_code||"NR",
      quantity:canonicalDecimal(line.quantity||"1","quantity"),unit_price:canonicalDecimal(line.unit_price||"0","unit_price"),discount_percent:canonicalDecimal(line.discount_percent||"0","discount_percent"),vat_rate:canonicalDecimal(line.vat_rate||"22","vat_rate"),
      calculation_mode:line.calculation_mode||"MANUAL",work_minutes:canonicalDecimal(line.work_minutes||"0","work_minutes"),workers:Number(line.workers||1),hourly_rate:canonicalDecimal(line.hourly_rate||"0","hourly_rate"),kilometers:canonicalDecimal(line.kilometers||"0","kilometers"),kilometer_rate:canonicalDecimal(line.kilometer_rate||"0","kilometer_rate")
    }))};
    const saved=await api(doc?`/delivery-notes/${doc.id}/full`:"/delivery-notes/full",doc?"PUT":"POST",payload);
    await deliveryDocumentPage(saved.id);notice("DDT completo salvato")
  },doc?"DDT completo":"Nuovo DDT completo");
  const section=$("paymentEditor"),form=section?.querySelector("form");if(!form)return;
  section.classList.add("document-editor");form.dataset.saveOnExit="true";
  const submit=[...form.querySelectorAll("button")].find(x=>x.type!=="button"||x.textContent==="Salva");if(submit)submit.textContent="Salva DDT completo";
  const cancel=[...form.querySelectorAll("button")].find(x=>x.textContent==="Annulla");if(cancel)cancel.onclick=()=>render("ddt");
  const rowsSection=el("section",undefined,"form-section full document-lines"),rowsList=el("div"),lineEditor=el("div"),totals=el("div",undefined,"document-totals");
  rowsSection.append(el("h3","Righe materiali, manodopera e trasferta"),el("p","Inserisci qui tutte le voci del DDT. I totali vengono aggiornati immediatamente.","muted"));
  const rowActions=el("div",undefined,"actions no-print");
  for(const [label,kind,mode] of [["＋ Materiale","PRODUCT","MANUAL"],["＋ Manodopera","SERVICE","LABOR"],["＋ Trasferta / km","TRAVEL","TRAVEL"],["＋ Sconto","DISCOUNT","MANUAL"]])rowActions.append(btn(label,()=>editLine(null,kind,mode)));
  rowsSection.append(rowActions,rowsList,lineEditor,totals);form.insertBefore(rowsSection,form.lastElementChild);

  const quoteSelect=form.elements.quote_id;
  let selectedQuote=String(doc?.quote_id||"");
  async function importQuote(){const quote=(refs.quotes||[]).find(x=>x.id===Number(quoteSelect.value));if(!quote){if(!selectedQuote)return;if(!confirm("Dissociare il preventivo dal DDT in bozza?")){quoteSelect.value=selectedQuote;return}const imported=draftLines.filter(x=>x.quote_line_id);if(imported.length){const keep=confirm("Vuoi conservare le righe importate come righe manuali?\nOK = conserva; Annulla = rimuovi le righe importate.");if(keep)draftLines=draftLines.map(x=>x.quote_line_id?{...x,quote_line_id:null}:x);else draftLines=draftLines.filter(x=>!x.quote_line_id)}selectedQuote="";drawLines();form.dataset.dirty="true";notice("Preventivo dissociato dalla bozza DDT");return}
    if(draftLines.length&&!confirm("Sostituire le righe attuali con le quantità ancora da consegnare del preventivo?")){quoteSelect.value=doc?.quote_id||"";return}
    form.elements.customer_id.value=String(quote.customer_id);form.elements.customer_id.dispatchEvent(new Event("change"));
    draftLines=quote.lines.filter(x=>parseIt(x.remaining_quantity)>0).map(x=>({quote_line_id:x.id,product_id:x.product_id,kind:x.kind==="MATERIAL"?"PRODUCT":x.kind==="DISCOUNT"?"DISCOUNT":"SERVICE",code:x.code,description:x.description,unit_code:x.unit_code,quantity:canonicalDecimal(x.remaining_quantity,"quantity"),unit_price:canonicalDecimal(Math.abs(parseIt(x.display_unit_price)),"unit_price"),discount_percent:"0",vat_rate:canonicalDecimal(x.vat_rate,"vat_rate"),calculation_mode:"MANUAL",work_minutes:"0",workers:1,hourly_rate:"0",kilometers:"0",kilometer_rate:"0"}));
    if(parseIt(quote.manual_labor_cost)>0)draftLines.push({kind:"SERVICE",description:"Manodopera da preventivo",unit_code:"NR",quantity:"1",unit_price:quote.manual_labor_cost,discount_percent:"0",vat_rate:"22",calculation_mode:"MANUAL",workers:1});
    if(parseIt(quote.kilometer_total)>0)draftLines.push({kind:"TRAVEL",description:"Trasferta da preventivo",unit_code:"NR",quantity:"1",unit_price:quote.kilometer_total,discount_percent:"0",vat_rate:"22",calculation_mode:"MANUAL",workers:1});
    selectedQuote=String(quote.id);drawLines();notice("Preventivo caricato: la fattura dovrà richiamare questo DDT")
  }
  quoteSelect.onchange=importQuote;

  function signedTotal(line){const value=parseIt(line.quantity||"1")*parseIt(line.unit_price||"0")*(1-parseIt(line.discount_percent||"0")/100);return line.kind==="DISCOUNT"?-value:value}
  function drawLines(){rowsList.replaceChildren();let material=0,labor=0,travel=0,discount=0,taxable=0,vat=0;
    draftLines.forEach((line,index)=>{const total=signedTotal(line);taxable+=total;vat+=total*parseIt(line.vat_rate||"0")/100;if(line.kind==="DISCOUNT")discount+=total;else if(line.kind==="TRAVEL"||line.calculation_mode==="TRAVEL")travel+=total;else if(line.kind==="SERVICE"||line.calculation_mode==="LABOR")labor+=total;else material+=total;
      const row=el("div",undefined,"record"),info=el("div",undefined,"summary"),actions=el("div",undefined,"actions no-print");info.append(el("strong",`${line.kind==="PRODUCT"?"Materiale":line.kind==="SERVICE"?"Manodopera":line.kind==="TRAVEL"?"Trasferta":"Sconto"} · ${line.code||""} ${line.description}`),el("br"),el("small",`${displayIt(line.quantity||1,4)} ${line.unit_code||"NR"} × € ${displayIt(line.unit_price||0,3)} · sconto ${displayIt(line.discount_percent||0)}% · € ${displayIt(total)}`));actions.append(btn("Modifica",()=>editLine(index)),btn("Rimuovi",()=>{draftLines.splice(index,1);drawLines();form.dataset.dirty="true"},"danger"));row.append(info,actions);rowsList.append(row)});
    if(!draftLines.length)rowsList.append(el("p","Nessuna riga inserita.","muted"));totals.replaceChildren();for(const [label,value,cls] of [["Materiali",material,"materials"],["Manodopera",labor,"labor"],["Trasporto / km",travel,"travel"],["Sconti",discount,"discount"],["Imponibile",taxable,"taxable"],["IVA",vat,"vat"],["Totale",taxable+vat,"grand"]]){const box=el("div",undefined,"total-box "+cls);box.append(el("span",label),el("strong","€ "+displayIt(value)));totals.append(box)}}

  function editLine(index,initialKind="PRODUCT",initialMode="MANUAL"){lineEditor.replaceChildren();const current=index===null?{kind:initialKind,calculation_mode:initialMode,quantity:"1",unit_price:"0",discount_percent:"0",vat_rate:"22",unit_code:initialKind==="PRODUCT"?"PZ":"NR",workers:1,work_minutes:"0",hourly_rate:"0",kilometers:"0",kilometer_rate:"0"}:{...draftLines[index]};
    const box=el("section",undefined,"line-editor grid"),inputs={};box.append(el("h3",index===null?"Nuova riga":"Modifica riga"));
    const specs=[["kind","Tipo",[["PRODUCT","Materiale"],["SERVICE","Manodopera / prestazione"],["TRAVEL","Trasferta"],["DISCOUNT","Sconto"]]],["calculation_mode","Calcolo",[["MANUAL","Manuale"],["LABOR","Minuti × persone × tariffa"],["TRAVEL","Km × coefficiente"]]],["product_id","Articolo",[["","Nessun articolo"],...(refs.products||[]).map(p=>[p.id,`${p.code} · ${p.description}`])]],["description","Descrizione"],["unit_code","Unità"],["quantity","Quantità"],["work_minutes","Minuti"],["workers","Persone"],["hourly_rate","Tariffa oraria €"],["kilometers","Chilometri"],["kilometer_rate","Coefficiente €/km"],["unit_price","Prezzo / totale €"],["discount_percent","Sconto %"],["vat_rate","IVA %"]];
    for(const [name,label,options] of specs){const wrap=el("label",label),input=el(options?"select":"input");input.name=name;if(options)for(const [value,text] of options){const option=el("option",text);option.value=value;input.append(option)}else if(!["description","unit_code"].includes(name))input.inputMode="decimal";input.value=current[name]??"";input.title=ddtHelp[name]||label;wrap.append(input);box.append(wrap);inputs[name]=input}
    function calculate(changed){const mode=inputs.calculation_mode.value;if(mode==="LABOR"){const minutes=parseIt(inputs.work_minutes.value),people=Number(inputs.workers.value||1);if(changed==="total"&&minutes>0)inputs.hourly_rate.value=decimalInput(parseIt(inputs.unit_price.value)*60/minutes/people);else inputs.unit_price.value=decimalInput(minutes*people*parseIt(inputs.hourly_rate.value)/60)}else if(mode==="TRAVEL"){const km=parseIt(inputs.kilometers.value);if(changed==="total"&&km>0)inputs.kilometer_rate.value=decimalInput(parseIt(inputs.unit_price.value)/km);else inputs.unit_price.value=decimalInput(km*parseIt(inputs.kilometer_rate.value))}}
    function toggle(){const mode=inputs.calculation_mode.value;for(const name of ["work_minutes","workers","hourly_rate"])inputs[name].closest("label").classList.toggle("hidden",mode!=="LABOR");for(const name of ["kilometers","kilometer_rate"])inputs[name].closest("label").classList.toggle("hidden",mode!=="TRAVEL");inputs.product_id.closest("label").classList.toggle("hidden",inputs.kind.value!=="PRODUCT");calculate()}
    inputs.kind.onchange=()=>{if(inputs.kind.value!=="PRODUCT")inputs.product_id.value="";toggle()};inputs.calculation_mode.onchange=()=>{if(inputs.calculation_mode.value==="LABOR")inputs.kind.value="SERVICE";if(inputs.calculation_mode.value==="TRAVEL")inputs.kind.value="TRAVEL";toggle()};inputs.product_id.onchange=()=>{const p=(refs.products||[]).find(x=>x.id===Number(inputs.product_id.value));if(p){inputs.description.value=p.description;inputs.unit_code.value=p.unit_code;inputs.unit_price.value=decimalInput(p.list_price);inputs.vat_rate.value=decimalInput(p.vat_rate)}};for(const name of ["work_minutes","workers","hourly_rate","kilometers","kilometer_rate"])inputs[name].oninput=()=>calculate();inputs.unit_price.oninput=()=>calculate("total");toggle();
    const actions=el("div",undefined,"actions full");actions.append(btn("Salva riga",()=>{if(inputs.kind.value==="PRODUCT"&&!inputs.product_id.value)return notice("Seleziona l'articolo",true);if(!inputs.description.value.trim())return notice("Inserisci la descrizione della riga",true);const updated={...current};for(const [name,input] of Object.entries(inputs))updated[name]=input.value;updated.product_id=updated.product_id?Number(updated.product_id):null;updated.workers=Number(updated.workers||1);if(index===null)draftLines.push(updated);else draftLines[index]=updated;lineEditor.replaceChildren();drawLines();form.dataset.dirty="true"}),btn("Annulla riga",()=>lineEditor.replaceChildren()));box.append(actions);lineEditor.append(box);box.scrollIntoView({behavior:"smooth",block:"center"})}
  drawLines();
  if(doc){const confirmRow=el("div",undefined,"actions no-print");confirmRow.append(btn("Conferma definitivamente il DDT",async()=>{if(form.dataset.dirty==="true")return notice("Salva prima tutte le modifiche del DDT",true);if(!confirm("Confermare il DDT? Il documento non sarà più modificabile e verranno registrati i movimenti di magazzino."))return;try{await api(`/delivery-notes/${doc.id}/confirm`,"POST");await render("ddt");notice("DDT confermato e aggiunto all’elenco")}catch(error){notice(error.message,true)}}));section.append(confirmRow)}
};

const ddtHelp={quote_id:"Seleziona il preventivo da trasformare in DDT. Le quantità già consegnate non verranno riproposte.",project_id:"Collega il DDT al cantiere quando la consegna riguarda una commessa.",transport_reason_id:"La causale stabilisce se il DDT sarà fatturabile e se movimenterà il magazzino.",goods_appearance_id:"Descrivi come si presenta la merce: colli, pallet, scatole o altro.",port_term_id:"Franco: trasporto a carico del mittente. Assegnato: trasporto a carico del destinatario.",product_id:"Cerca e seleziona un articolo del magazzino.",work_minutes:"Durata complessiva del lavoro in minuti.",workers:"Numero di operatori impiegati.",hourly_rate:"Costo orario applicato a ciascun operatore.",kilometers:"Chilometri della trasferta.",kilometer_rate:"Coefficiente applicato a ogni chilometro.",unit_price:"Prezzo unitario oppure totale calcolato per manodopera e trasferta."};

