"use strict";
const deliveryFields = [
  ["customer_id", "Cliente", "select"],
  ["quote_id", "Preventivo collegato"],
  ["project_id", "Cantiere"],
  ["number", "Numero DDT"],
  ["issued_on", "Data DDT", "date"],
  ["warehouse_id", "Magazzino interessato", "warehouse"],
  ["shipping_address", "Indirizzo di consegna"],
  ["transport_reason_id", "Causale trasporto"],
  ["goods_appearance_id", "Aspetto dei beni"],
  ["port_term_id", "Porto"],
  ["transport_mode_id", "Trasporto a cura di"],
  ["carrier_id", "Vettore"],
  ["transport_date", "Data inizio trasporto", "date"],
  ["transport_time", "Ora inizio trasporto", "time"],
  ["package_count", "Numero colli"],
  ["gross_weight", "Peso lordo"],
  ["net_weight", "Peso netto"],
  ["weight_unit", "Unità peso"],
  ["return_due_date", "Rientro previsto", "date"],
  ["notes", "Note"],
];
const salFields = [
  ["customer_id", "Cliente", "select"],
  ["project_id", "Cantiere"],
  ["quote_id", "Preventivo collegato", "quote"],
  ["number", "Numero SAL"],
  ["sequence_no", "Numero SAL nel cantiere"],
  ["issued_on", "Data SAL", "date"],
  ["period_from", "Periodo dal", "date"],
  ["period_to", "Periodo al", "date"],
  ["description", "Lavori eseguiti"],
  ["percent", "Avanzamento corrente %"],
  ["amount", "Importo lavori corrente €"],
  ["variation_amount", "Varianti €"],
  ["retention_amount", "Ritenuta di garanzia €"],
  ["advance_recovery", "Recupero anticipo €"],
  ["vat_rate", "IVA %"],
  ["status", "Avanzamento", "salstatus"],
  ["approval_status", "Approvazione"],
  ["approved_on", "Data approvazione", "date"],
  ["notes", "Note"],
];

async function renderDeliveries() {
  let documents;
  try {
    documents = await api("/delivery-notes");
  } catch (e) {
    notice(e.message, true);
    return;
  }
  if (hasAccess("ddt", true)) view.append(btn("＋ Nuovo DDT", () => deliveryDocumentPage()));
  for (const doc of documents) {
    const record = el("div", undefined, "record"),
      actions = el("div", undefined, "actions");
    record.append(
      el(
        "strong",
        `${doc.number} · ${doc.customer_name} · ${doc.issued_on} · ${statusText(doc.status)} · ${doc.lines.length} righe`,
      ),
    );
    actions.append(
      btn("Apri", () => deliveryDocumentPage(doc.id)),
      btn("Stampa DDT", () => printDelivery(doc)),
      btn("Esporta PDF", () =>
        downloadPdf(`/pdf/ddt/${doc.id}`, `DDT-${doc.number}.pdf`),
      ),
    );
    if (doc.status === "DRAFT" && hasAccess("ddt", true))
      actions.append(
        btn("Conferma", () => deliveryDocumentPage(doc.id)),
        btn("Modifica", () => deliveryDocumentPage(doc.id)),
        btn(
          "Archivia",
          async () => {
            if (!confirm("Archiviare la bozza DDT?")) return;
            try {
              await api(`/delivery-notes/${doc.id}`, "DELETE");
              await render("ddt");
            } catch (e) {
              notice(e.message, true);
            }
          },
          "danger",
        ),
      );
    record.append(actions);
    view.append(record);
  }
  if (!documents.length) view.append(el("p", "Nessun DDT.", "muted"));
}

function deliveryEditor(fields, values, save, title) {
  paymentEditor(fields, values, save, title);
  const form = $("paymentEditor")?.querySelector("form");
  if (!form) return;
  const label = el("label", "Destinazione merce salvata nel cliente"),
    select = el("select");
  label.append(select);
  form.elements.shipping_address.closest("label").before(label);
  async function load() {
    const customerId = Number(form.elements.customer_id.value);
    select.replaceChildren();
    const empty = el("option", "Indirizzo principale / inserimento manuale");
    empty.value = "";
    select.append(empty);
    if (!customerId) return;
    try {
      const rows = await api(`/customers/${customerId}/addresses`);
      for (const row of rows) {
        const option = el(
          "option",
          `${row.label}${row.is_default ? " · Predefinita" : ""} · ${row.address}, ${row.postal_code} ${row.city} ${row.province}`,
        );
        option.value = row.id;
        option.dataset.address = [
          row.label,
          row.address,
          `${row.postal_code} ${row.city} ${row.province}`.trim(),
        ]
          .filter(Boolean)
          .join(", ");
        select.append(option);
      }
      if (!values?.id && rows.length) {
        const option =
          [...select.options].find((o) =>
            o.textContent.includes("Predefinita"),
          ) || select.options[1];
        select.value = option.value;
        form.elements.shipping_address.value = option.dataset.address;
      }
    } catch (error) {
      notice(error.message, true);
    }
  }
  select.onchange = () => {
    if (select.value)
      form.elements.shipping_address.value =
        select.selectedOptions[0].dataset.address;
  };
  form.elements.customer_id.addEventListener("change", () => {
    form.elements.shipping_address.value = "";
    load();
  });
  load();
}

async function deliveryDetail(id) {
  let doc;
  try {
    doc = (await api("/delivery-notes")).find((x) => x.id === id);
  } catch (e) {
    notice(e.message, true);
    return;
  }
  if (!doc) return notice("DDT non trovato", true);
  $("detail")?.remove();
  const pane = el("section", undefined, "panel");
  pane.id = "detail";
  pane.append(
    el("h3", `DDT ${doc.number} · ${doc.customer_name}`),
    el(
      "p",
      `Uscita da ${doc.warehouse_name} · Stato ${statusText(doc.status)} · Consegnare a: ${doc.shipping_address || "indirizzo cliente"}`,
    ),
    el(
      "p",
      [
        doc.project_code && `Cantiere ${doc.project_code}`,
        doc.transport_reason_name && `Causale: ${doc.transport_reason_name}`,
        doc.goods_appearance_name && `Aspetto: ${doc.goods_appearance_name}`,
        doc.port_term_name && `Porto: ${doc.port_term_name}`,
        doc.transport_mode_name && `Trasporto: ${doc.transport_mode_name}`,
        `Colli: ${doc.package_count ?? 0}`,
        doc.gross_weight && `Peso lordo ${displayIt(doc.gross_weight, 3)} ${doc.weight_unit || "kg"}`,
        doc.net_weight && `Peso netto ${displayIt(doc.net_weight, 3)} ${doc.weight_unit || "kg"}`,
      ]
        .filter(Boolean)
        .join(" · "),
      "muted",
    ),
  );
  if(doc.linked_invoice)pane.append(el('p',`Collegato alla fattura ${doc.linked_invoice.number} · ${statusText(doc.linked_invoice.document_status)}`,'muted'),btn('Apri fattura collegata',()=>invoiceDocumentPage(doc.linked_invoice.id)));
  for (const line of doc.lines) {
    const record = el("div", undefined, "record"),
      actions = el("div", undefined, "actions");
    record.append(
      el(
        "span",
        `${line.kind === "SERVICE" ? "Manodopera" : line.kind === "TRAVEL" ? "Trasferta" : line.kind === "DISCOUNT" ? "Sconto" : line.product_code || "Materiale"} · ${line.description} · ${displayIt(line.quantity, 4)} ${line.unit_code} · Prezzo € ${displayIt(line.unit_price, 3)} · Sconto ${displayIt(line.discount_percent)}% · Netto € ${displayIt(line.total)}`,
      ),
    );
    if (doc.status === "DRAFT" && hasAccess("ddt", true))
      actions.append(
        btn("Modifica", () => deliveryLineEditor(doc, line, pane)),
        btn(
          "Elimina",
          async () => {
            if (!confirm("Eliminare la riga DDT?")) return;
            try {
              await api(`/delivery-notes/${doc.id}/lines/${line.id}`, "DELETE");
              await deliveryDetail(id);
            } catch (e) {
              notice(e.message, true);
            }
          },
          "danger",
        ),
      );
    record.append(actions);
    pane.append(record);
  }
  if (doc.totals) {
    const summary = el("div", undefined, "document-totals");
    for (const [label, key, cls] of [["Materiali","materials","materials"],["Manodopera","labor","labor"],["Trasporto / km","travel","travel"],["Sconti","discounts","discount"],["Imponibile","taxable","taxable"],["IVA","vat","vat"],["Totale","total","grand"]]) {
      const box=el("div",undefined,"total-box "+cls);box.append(el("span",label),el("strong","€ "+displayIt(doc.totals[key])));summary.append(box)
    }
    pane.append(summary)
  }
  if (doc.status === "DRAFT" && hasAccess("ddt", true))
    pane.append(
      btn("＋ Aggiungi articolo", () => deliveryLineEditor(doc, null, pane)),
      btn("Conferma DDT", async () => {
        if (
          !confirm(
            "Confermare il DDT? Verrà applicato il movimento di magazzino previsto dalla causale e il documento non sarà più modificabile.",
          )
        )
          return;
        try {
          await api(`/delivery-notes/${id}/confirm`, "POST");
          await render("ddt");
          notice("DDT confermato e aggiunto all’elenco");
        } catch (e) {
          notice(e.message, true);
        }
      }),
    );
  view.append(pane);
  pane.scrollIntoView({ behavior: "smooth" });
}

function deliveryLineEditor(doc, line, pane) {
  pane.querySelector("#deliveryEditor")?.remove();
  const section = el("section", undefined, "panel"),
    form = el("form", undefined, "grid");
  form.dataset.saveOnExit = "true";
  section.id = "deliveryEditor";
  section.append(
    el("h3", line ? "Modifica articolo DDT" : "Nuovo articolo DDT"),
  );
  const fields = [
    ["product_id", "Articolo", "product"],
    ["quantity", "Quantità"],
    ["unit_price", "Prezzo unitario lordo €"],
    ["discount_percent", "Sconto cliente %"],
    ["vat_rate", "IVA %"],
  ];
  for (const [name, label, type] of fields) {
    const wrap = el("label", label),
      input = type === "product" ? el("select") : el("input");
    input.name = name;
    if (type === "product") {
      const initial = el("option", "Seleziona articolo");
      initial.value = "";
      input.append(initial);
      for (const p of refs.products) {
        const o = el("option", `${p.code} · ${p.description}`);
        o.value = p.id;
        input.append(o);
      }
      input.required = true;
    }
    input.value =
      line?.[name] ??
      (name === "quantity" ? "1" : name === "vat_rate" ? "22" : "0");
    if (type === "product" && input.selectedIndex < 0 && input.options.length)
      input.selectedIndex = 0;
    wrap.append(input);
    if (type === "product") attachProductSearch(wrap, input);
    form.append(wrap);
  }
  form.elements.product_id.onchange = async () => {
    const p = refs.products.find(
      (x) => x.id === Number(form.elements.product_id.value),
    );
    if (p) {
      form.elements.unit_price.value = p.list_price || "0";
      form.elements.discount_percent.value = "0";
      form.elements.vat_rate.value = p.vat_rate || "22";
      try {
        const price = await api(`/customers/${doc.customer_id}/prices/${p.id}`);
        if (Number(form.elements.product_id.value) === p.id) {
          form.elements.unit_price.value = (
            Number(price.list_price) *
            (1 - Number(price.list_discount_percent || 0) / 100)
          ).toFixed(4);
          form.elements.discount_percent.value = price.discount_percent;
        }
      } catch {}
    }
  };
  const submit = el("button", "Salva riga");
  form.append(submit);
  form.onsubmit = async (event) => {
    event.preventDefault();
    const values = Object.fromEntries(new FormData(form));
    for (const key of [
      "quantity",
      "unit_price",
      "discount_percent",
      "vat_rate",
    ])
      values[key] = String(parseIt(values[key]));
    values.product_id = Number(values.product_id);
    try {
      await api(
        `/delivery-notes/${doc.id}/lines${line ? "/" + line.id : ""}`,
        line ? "PUT" : "POST",
        values,
      );
      await deliveryDetail(doc.id);
      notice("Riga DDT salvata");
      form.dispatchEvent(new Event("erp:saved"));
    } catch (e) {
      notice(e.message, true);
      form.dispatchEvent(new Event("erp:save-failed"));
    }
  };
  section.append(form);
  pane.append(section);
  if (!line && form.elements.product_id.options.length)
    form.elements.product_id.onchange();
  section.scrollIntoView({ behavior: "smooth" });
}

async function renderSal() {
  let records;
  try {
    records = await api("/progress-certificates");
    refs.quotes = await api("/quotes");
    refs.salRecords = records;
  } catch (e) {
    notice(e.message, true);
    return;
  }
  const fields = salFields;
  if (hasAccess("sal", true)) view.append(btn("＋ Nuovo SAL", () => salDocumentPage()));
  for (const item of records) {
    const row = el("div", undefined, "record"),
      actions = el("div", undefined, "actions");
    const net =
      parseIt(item.amount) +
      parseIt(item.variation_amount) -
      parseIt(item.retention_amount) -
      parseIt(item.advance_recovery);
    row.append(
      el(
        "span",
        `${item.number} · ${item.project_code ? `Cantiere ${item.project_code} · SAL n. ${item.sequence_no}` : item.customer_name} · ${item.issued_on} · avanzamento precedente ${displayIt(item.previous_percent)}% + corrente ${displayIt(item.percent)}% = ${displayIt(parseIt(item.previous_percent) + parseIt(item.percent))}% · netto SAL € ${displayIt(net)} · ${statusText(item.approval_status)} · ${item.description}`,
      ),
    );
    actions.append(
      ...(item.approval_status === "DRAFT" && hasAccess("sal", true) ? [btn("Conferma", () => salDocumentPage(item.id))] : []),
      btn("Esporta PDF", () =>
        downloadPdf(`/pdf/sal/${item.id}`, `SAL-${item.number}.pdf`),
      ),
    );
    if (hasAccess("sal", true))
      actions.append(
        btn("Modifica", () => salDocumentPage(item.id)),
        btn(
          "Archivia",
          async () => {
            if (!confirm("Archiviare il SAL?")) return;
            try {
              await api(`/progress-certificates/${item.id}`, "DELETE");
              await render("sal");
            } catch (e) {
              notice(e.message, true);
            }
          },
          "danger",
        ),
      );
    row.append(actions);
    view.append(row);
  }
  if (!records.length) view.append(el("p", "Nessun SAL.", "muted"));
}

function salEditor(fields, values, save, title) {
  paymentEditor(fields, values, save, title);
  const form = $("paymentEditor")?.querySelector("form");
  if (!form) return;
  const hint = el("p", "", "muted full");
  form.prepend(hint);
  let changed = "percent";
  function update() {
    const selected = (refs.quotes || []).find(
      (q) => q.id === Number(form.elements.quote_id.value),
    );
    if (!selected) {
      hint.textContent =
        "Scegli un preventivo per il calcolo automatico oppure inserisci percentuale e importo.";
      return;
    }
    const prior = (refs.salRecords || []).filter(
        (s) => s.quote_id === selected.id && s.id !== values?.id,
      ),
      used = prior.reduce((sum, s) => sum + parseIt(s.percent), 0),
      total = parseIt(selected.subtotal),
      available = Math.max(0, 100 - used);
    hint.textContent = `Preventivo imponibile € ${displayIt(total)} · già registrato ${displayIt(used)}% · disponibile ${displayIt(available)}%. L'importo del SAL è imponibile, l'IVA viene aggiunta in fattura.`;
    if (
      changed === "percent" &&
      form.elements.percent.value &&
      total > 0 &&
      (!values?.id || form.dataset.salEdited)
    )
      form.elements.amount.value = decimalInput(
        ((total * parseIt(form.elements.percent.value)) / 100).toFixed(2),
      );
    if (
      changed === "amount" &&
      form.elements.amount.value &&
      total > 0 &&
      form.dataset.salEdited
    )
      form.elements.percent.value = decimalInput(
        ((parseIt(form.elements.amount.value) / total) * 100).toFixed(2),
      );
    const percent = parseIt(form.elements.percent.value);
    hint.classList.toggle(
      "error",
      Number.isFinite(percent) && percent > available + 0.005,
    );
  }
  form.elements.quote_id.onchange = () => {
    form.dataset.salEdited = "1";
    changed = "percent";
    update();
  };
  form.elements.percent.oninput = () => {
    form.dataset.salEdited = "1";
    changed = "percent";
    update();
  };
  form.elements.amount.oninput = () => {
    form.dataset.salEdited = "1";
    changed = "amount";
    update();
  };
  update();
}

async function invoiceSources(invoiceId) {
  const invoice = (refs["invoice-register"] || []).find(
    (x) => x.id === invoiceId,
  );
  if (!invoice) return notice("Riapri il registro fatture", true);
  $("detail")?.remove();
  const pane = el("section", undefined, "panel");
  pane.id = "detail";
  pane.append(
    el(
      "h3",
      `Fattura ${invoice.number}: scegli DDT o SAL di ${invoice.customer_name}`,
    ),
    el(
      "p",
      `Imponibile € ${displayIt(invoice.taxable)} · IVA € ${displayIt(invoice.vat_amount)} · Totale € ${displayIt(invoice.total)}`,
    ),
  );
  try {
    const sources = await api(`/invoice-register/${invoiceId}/sources`);
    for (const source of sources) {
      const row = el("div", undefined, "record"),
        actions = el("div", undefined, "actions");
      row.append(
        el(
          "span",
          `${source.delivery_id ? "DDT " + source.delivery_number : "SAL " + source.sal_number} · Imponibile € ${displayIt(source.taxable)} · IVA € ${displayIt(source.vat_amount)}`,
        ),
      );
      if (hasAccess("invoices", true))
        actions.append(
          btn(
            "Rimuovi",
            async () => {
              if (!confirm("Rimuovere la fonte dalla fattura?")) return;
              try {
                await api(
                  `/invoice-register/${invoiceId}/sources/${source.id}`,
                  "DELETE",
                );
                await render("invoices");
                await invoiceSources(invoiceId);
                notice("Fonte rimossa, totale aggiornato");
              } catch (error) {
                notice(error.message, true);
              }
            },
            "danger",
          ),
        );
      row.append(actions);
      pane.append(row);
    }
  } catch (error) {
    notice(error.message, true);
  }
  if (hasAccess("invoices", true)) {
    const controls = el("div", undefined, "grid no-print");
    const modeLabel = el("label", "Periodo documenti"),
      mode = el("select");
    for (const [value, label] of [
      ["MONTH", "Un mese"],
      ["RANGE", "Da data a data"],
      ["ALL", "Tutto lo storico"],
    ]) {
      const option = el("option", label);
      option.value = value;
      mode.append(option);
    }
    modeLabel.append(mode);
    const monthLabel = el("label", "Mese DDT / SAL"),
      month = el("input");
    month.type = "month";
    month.value = invoice.issue_date.slice(0, 7);
    monthLabel.append(month);
    const fromLabel = el("label", "Dal"),
      from = el("input");
    from.type = "date";
    fromLabel.append(from);
    const toLabel = el("label", "Al"),
      to = el("input");
    to.type = "date";
    toLabel.append(to);
    const result = el("div");
    function toggle() {
      monthLabel.classList.toggle("hidden", mode.value !== "MONTH");
      fromLabel.classList.toggle("hidden", mode.value !== "RANGE");
      toLabel.classList.toggle("hidden", mode.value !== "RANGE");
    }
    mode.onchange = toggle;
    toggle();
    async function search() {
      result.replaceChildren();
      const params = new URLSearchParams({
        customer_id: String(invoice.customer_id),
      });
      if (mode.value === "MONTH") {
        if (!month.value) return notice("Scegli un mese", true);
        params.set("month", month.value);
      }
      if (mode.value === "RANGE") {
        if (from.value) params.set("date_from", from.value);
        if (to.value) params.set("date_to", to.value);
      }
      try {
        const candidates = await api(
          "/invoice-sources/candidates?" + params.toString(),
        );
        for (const item of [...candidates.ddt, ...candidates.sal]) {
          const row = el("div", undefined, "record"),
            actions = el("div", undefined, "actions");
          row.append(
            el(
              "span",
              `${item.kind} ${item.number} · ${item.issued_on} · disponibile € ${displayIt(item.available)}`,
            ),
          );
          const amount = el("input");
          amount.inputMode = "decimal";
          amount.value = item.available;
          amount.style.width = "130px";
          if (item.kind === "SAL") actions.append(amount);
          actions.append(
            btn("Collega alla fattura", async () => {
              try {
                await api(`/invoice-register/${invoiceId}/sources`, "POST", {
                  kind: item.kind,
                  source_id: item.id,
                  amount: item.kind === "SAL" ? amount.value : null,
                });
                await render("invoices");
                await invoiceSources(invoiceId);
                notice("Documento collegato e totale ricalcolato");
              } catch (error) {
                notice(error.message, true);
              }
            }),
          );
          row.append(actions);
          result.append(row);
        }
        if (!result.childElementCount)
          result.append(
            el(
              "p",
              "Nessun documento disponibile: prova “Tutto lo storico” o un altro periodo.",
              "muted",
            ),
          );
      } catch (error) {
        notice(error.message, true);
      }
    }
    controls.append(
      modeLabel,
      monthLabel,
      fromLabel,
      toLabel,
      btn("Cerca DDT e SAL", search),
    );
    pane.append(
      el(
        "p",
        "Mostra solo DDT confermati e SAL del cliente scelto. Il SAL può essere fatturato anche parzialmente.",
        "muted",
      ),
      controls,
      result,
    );
    view.append(pane);
    pane.scrollIntoView({ behavior: "smooth" });
    await search();
  } else {
    view.append(pane);
    pane.scrollIntoView({ behavior: "smooth" });
  }
}

async function printInvoiceDraft(invoice) {
  const win = window.open("", "_blank");
  if (!win) return notice("Consenti le finestre popup per stampare", true);
  try {
    const [sources, dues] = await Promise.all([
      api(`/invoice-register/${invoice.id}/sources`),
      api(`/payment-due?invoice_id=${invoice.id}`),
    ]);
    const doc = win.document;
    doc.title = `Bozza fattura ${invoice.number}`;
    const css = doc.createElement("style");
    css.textContent =
      "body{font:14px Arial,sans-serif;margin:28px;color:#15334d}table{border-collapse:collapse;width:100%;margin:18px 0}td,th{border-bottom:1px solid #aaa;text-align:left;padding:9px}h1,h2{color:#155280}@page{margin:15mm}";
    doc.head.append(css);
    appendCompanyBrand(doc);
    doc.body.append(
      el("h1", `Bozza gestionale · Fattura ${invoice.number}`),
      el(
        "p",
        `Cliente: ${invoice.customer_name} · Data: ${invoice.issue_date}`,
      ),
    );
    const table = el("table"),
      head = el("tr");
    for (const col of ["Origine", "Imponibile €", "IVA €"])
      head.append(el("th", col));
    table.append(head);
    for (const source of sources) {
      const row = el("tr");
      for (const value of [
        source.delivery_id
          ? "DDT " + source.delivery_number
          : "SAL " + source.sal_number,
        source.taxable,
        source.vat_amount,
      ])
        row.append(el("td", value));
      table.append(row);
    }
    doc.body.append(
      table,
      el(
        "p",
        `Imponibile € ${displayIt(invoice.taxable)} · IVA € ${displayIt(invoice.vat_amount)} · TOTALE € ${displayIt(invoice.total)}`,
      ),
      el("h2", "Scadenze"),
    );
    for (const due of dues)
      doc.body.append(
        el(
          "p",
          `${due.due_date} · € ${due.amount} · ${due.payment_method_name || ""} · ${statusText(due.status)}`,
        ),
      );
    const method = (refs["payment-methods"] || []).find(
      (x) => x.id === invoice.payment_method_id,
    );
    doc.body.append(
      el("h2", "Pagamento"),
      el("p", `Modalità: ${method?.name || "Non indicata"}`),
    );
    if (invoice.bank_iban)
      doc.body.append(
        el(
          "p",
          `Conto aziendale: ${invoice.bank_holder || ""} · ${invoice.bank_name || ""} · IBAN ${invoice.bank_iban}`,
        ),
      );
    if (invoice.payment_type === "RIBA")
      doc.body.append(
        el(
          "p",
          invoice.customer_iban
            ? `Banca di appoggio cliente (Ri.Ba.): ${invoice.customer_bank_name || ""} · IBAN ${invoice.customer_iban}`
            : "IBAN di appoggio cliente non indicato per la Ri.Ba.",
        ),
      );
    doc.body.append(
      el(
        "p",
        "Documento riepilogativo gestionale. Non è una fattura elettronica emessa.",
      ),
    );
    win.print();
  } catch (e) {
    win.close();
    notice(e.message, true);
  }
}

async function printDelivery(doc) {
  const win = window.open("", "_blank");
  if (!win) return notice("Consenti le finestre popup per stampare", true);
  const paper = win.document;
  paper.title = `DDT ${doc.number}`;
  appendCompanyBrand(paper);
  paper.body.append(
    el("h1", `${companyState?.name || "Azienda"} · DDT ${doc.number}`),
    el(
      "p",
      `Data: ${doc.issued_on} · Cliente: ${doc.customer_name} · Consegna: ${doc.shipping_address}`,
    ),
  );
  for (const line of doc.lines)
    paper.body.append(
      el(
        "p",
        `${line.product_code} · ${line.description} · ${displayIt(line.quantity, 4)} ${line.unit_code} · Prezzo € ${displayIt(line.unit_price, 3)} · Sconto ${displayIt(line.discount_percent)}% · Netto € ${displayIt(line.total)}`,
      ),
    );
  paper.body.append(el("p", doc.notes || ""));
  win.print();
}
