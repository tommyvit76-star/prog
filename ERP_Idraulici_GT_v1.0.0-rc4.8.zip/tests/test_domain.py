import pytest
from decimal import Decimal
from app.domain import quantity, projected


def test_decimal_transfer_and_consumption():
    central, job = projected(Decimal('100'), Decimal('0'), quantity('32.50'))
    assert (central, job) == (Decimal('67.50'), Decimal('32.50'))
    job, used = projected(job, Decimal('0'), quantity('27.80'))
    assert job == Decimal('4.70')
    job, central = projected(job, central, quantity('4.70'))
    assert (job, central) == (Decimal('0'), Decimal('72.20'))


@pytest.mark.parametrize('bad', ['0', '-1', '1.12345', 'NaN', 'Infinity', '999999999999', '12,75.1', 2.5])
def test_invalid_quantity(bad):
    with pytest.raises(ValueError):
        quantity(bad)


def test_no_negative_stock():
    with pytest.raises(ValueError, match='insufficient'):
        projected(Decimal('1'), Decimal('0'), Decimal('2'))


def test_comma_decimal_quantity_for_load_and_return():
    assert quantity('1,5') == Decimal('1.5')
    assert quantity('2,8') == Decimal('2.8')
