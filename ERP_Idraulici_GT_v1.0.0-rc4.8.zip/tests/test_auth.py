import pytest
from fastapi import HTTPException
from starlette.requests import Request
from app.api import app
from app.auth import hash_password, verify_password, current_user, allowed, has_module, module_for


def request(path='/auth/me', method='GET'):
    return Request({'type':'http','path':path,'method':method,'headers':[],'query_string':b''})


def test_password_hash_is_salted_and_verified():
    first = hash_password('long-password-123')
    second = hash_password('long-password-123')
    assert first != second
    assert verify_password('long-password-123', first)
    assert not verify_password('incorrect-password', first)


def test_api_requires_login_before_database_access():
    for route in ('/products', '/customers', '/suppliers', '/balances', '/movements'):
        endpoint = next(r for r in app.routes if getattr(r, 'path', None) == route and 'GET' in r.methods)
        assert endpoint.dependant.dependencies
    with pytest.raises(HTTPException) as error:
        current_user(request(),None)
    assert error.value.status_code == 401
    with pytest.raises(HTTPException) as error:
        allowed('ADMIN')(request('/admin/users'),{'role': 'TECHNICIAN'})
    assert error.value.status_code == 403


def test_explicit_module_permissions_are_enforced_for_view_and_edit():
    u={'role':'OFFICE','permissions':{'quotes':{'view':True,'edit':True},'reports':{'view':True,'edit':False}}}
    assert module_for('/quotes/12/lines')=='quotes'
    assert has_module(u,'quotes',True)
    assert has_module(u,'customers')  # Needed to choose a client in a quote.
    assert has_module(u,'movements')  # Report data can be read.
    assert not has_module(u,'movements',True)
    assert has_module(u,'warehouses')  # Warehouse names appear on the inventory report.
    assert not has_module(u,'warehouses',True)
    assert not has_module(u,'payment-due',True)


def test_quote_users_can_see_payment_methods_but_not_due_dates():
    user={'role':'OFFICE','permissions':{'quotes':{'view':True,'edit':True}}}
    assert module_for('/payment-methods')=='payment-methods'
    assert has_module(user,'payment-methods')
    assert not has_module(user,'payments')
    assert not has_module(user,'payment-methods',True)
    assert module_for('/delivery-notes/12/confirm')=='ddt'


def test_module_edit_can_be_granted_to_a_standard_user_without_admin_access():
    user={'role':'TECHNICIAN','permissions':{'ddt':{'view':True,'edit':True},'sal':{'view':False,'edit':False}}}
    assert has_module(user,'ddt',True)
    assert not has_module(user,'sal')
    with pytest.raises(HTTPException):
        allowed('ADMIN')(request('/admin/users','POST'),user)


def test_interface_is_available_without_login():
    from pathlib import Path
    assert 'Accesso' in (Path(__file__).resolve().parent.parent / 'web' / 'index.html').read_text()
