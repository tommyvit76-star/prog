from datetime import date
from decimal import Decimal
from types import SimpleNamespace

import pytest
from fastapi import HTTPException

from app.numbering import proposed_number, formatted_number
from app.professional import ConfigIn, CreditCreate, ProjectIn
from app.workflow import DeliveryIn, DeliveryLineIn, SalIn, delivery_line_total, delivery_line_values, sal_values


class Result:
    def __init__(self, one=None):
        self.one = one

    def fetchone(self):
        return self.one


class NumberDB:
    def execute(self, query, args):
        if "last_number FROM document_sequences" in query:
            return Result({"last_number": 8})
        return Result()


def test_credit_note_has_its_own_automatic_sequence():
    assert proposed_number(NumberDB(), "NC", date(2026, 9, 23)) == "NC-000009-2026"


def test_configurable_document_number_format():
    settings={"prefix":"FT","separator":"-","sequence_digits":6,"year_position":"SUFFIX"}
    assert formatted_number(settings,2026,1)=="FT-000001-2026"
    assert formatted_number({**settings,"year_position":"PREFIX"},2026,1)=="2026-FT-000001"


def test_professional_document_models_accept_complete_business_data():
    reason = ConfigIn(name="Vendita", invoiceable=True, stock_action="CONSUME")
    assert reason.invoiceable and reason.stock_action == "CONSUME"
    project = ProjectIn(code="C-1", name="Cantiere prova", customer_id=2, contract_value="12.500,00")
    assert project.status == "PLANNED"
    note = CreditCreate(original_invoice_id=4, issue_date=date(2026, 9, 23), cause="Reso parziale")
    assert note.cause == "Reso parziale"
    ddt = DeliveryIn(
        customer_id=2,
        warehouse_id=1,
        issued_on=date(2026, 9, 23),
        transport_reason_id=3,
        goods_appearance_id=1,
        port_term_id=1,
        transport_mode_id=1,
        package_count=2,
        gross_weight="25,500",
        net_weight="24,750",
    )
    assert ddt.package_count == 2 and ddt.transport_reason_id == 3


def test_sal_rejects_retention_and_advance_above_current_work():
    class DB:
        def execute(self, query, args):
            if "FROM quotes" in query:
                return Result({"customer_id": 2})
            return Result()

    data = SalIn(
        customer_id=2,
        issued_on=date(2026, 9, 23),
        description="Impianto termico",
        quote_id=3,
        percent="10",
        amount="100",
        vat_rate="22",
        retention_amount="60",
        advance_recovery="50",
    )
    with pytest.raises(HTTPException, match="Ritenuta"):
        sal_values(DB(), data)


def test_ddt_rows_calculate_material_labor_travel_and_discount():
    class DB:
        def execute(self, query, args):
            if "FROM products" in query:
                return Result({"code": "LAV-01", "description": "Lavabo", "unit_code": "PZ"})
            if "SELECT quote_id FROM delivery_notes" in query:
                return Result({"quote_id": None})
            return Result()

    db = DB()
    material = delivery_line_values(db, 1, DeliveryLineIn(product_id=4, quantity="1,5", unit_price="100", discount_percent="10"))
    labor = delivery_line_values(db, 1, DeliveryLineIn(kind="SERVICE", calculation_mode="LABOR", description="Posa", work_minutes="90", workers=2, hourly_rate="40"))
    travel = delivery_line_values(db, 1, DeliveryLineIn(kind="TRAVEL", calculation_mode="TRAVEL", description="Trasferta", kilometers="125,5", kilometer_rate="0,68"))
    discount = delivery_line_values(db, 1, DeliveryLineIn(kind="DISCOUNT", description="Sconto extra", unit_price="20"))

    assert delivery_line_total(material) == Decimal("135.00")
    assert labor["unit_price"] == Decimal("120.00")
    assert travel["unit_price"] == Decimal("85.34")
    assert delivery_line_total(discount) == Decimal("-20.00")
