import pytest
from fastapi import HTTPException
from app.admin import UserEdit, Grant, validate_user, disable_user, LogoEdit
from app.workflow import check_name, candidate_period
from app.workflow import delivery_line_total, delivery_amount
from decimal import Decimal
from datetime import date
from app.numbering import next_document_number


def test_user_admin_requires_password_and_rejects_duplicate_modules():
    with pytest.raises(HTTPException):
        validate_user(UserEdit(username='pippo',password=None),creating=True)
    with pytest.raises(HTTPException):
        validate_user(UserEdit(username='pippo',password='twelve-or-more',permissions=[Grant(module='ddt'),Grant(module='ddt')]),creating=True)
    assert validate_user(UserEdit(username='pluto',password='twelve-or-more',permissions=[Grant(module='reports',view=True)]),creating=True).startswith('pbkdf2_sha256$')


def test_admin_cannot_disable_own_account_even_before_database_access():
    with pytest.raises(HTTPException) as exc:
        disable_user(42,{'id':42,'role':'ADMIN'})
    assert exc.value.status_code==409


def test_ddt_document_number_must_be_present():
    with pytest.raises(HTTPException):
        check_name('  ')


def test_ddt_discount_reduces_line_and_invoice_source_amount():
    line={'quantity':Decimal('1.5'),'unit_price':Decimal('2.358'),
          'discount_percent':Decimal('20.00')}
    assert delivery_line_total(line)==Decimal('2.83')
    assert delivery_line_total({**line,'discount_percent':Decimal('0')})==Decimal('3.54')
    class DeliveryRows:
        def execute(self, sql, params):
            assert 'discount_percent' in sql
            return self
        def fetchall(self):
            return [{**line,'vat_rate':Decimal('22')}]
    assert delivery_amount(DeliveryRows(),7)==(Decimal('2.83'),Decimal('0.62'))


def test_invoice_candidates_can_cover_one_month_or_all_history():
    assert candidate_period('2026-02')==(date(2026,2,1),date(2026,2,28))
    assert candidate_period()==(None,None)
    assert candidate_period(date_from=date(2025,1,1),date_to=date(2026,1,1))==(date(2025,1,1),date(2026,1,1))
    with pytest.raises(HTTPException):
        candidate_period(date_from=date(2026,2,1),date_to=date(2026,1,1))


def test_document_counter_skips_an_existing_number_and_never_reuses_it():
    class Connection:
        def __init__(self):self.counter=0
        def execute(self,sql,args):
            if 'INSERT INTO document_sequences' in sql:
                self.counter+=1;return type('R',(),{'fetchone':lambda _: {'last_number':self.counter}})()
            return type('R',(),{'fetchone':lambda _: {'exists':True} if '-000001-' in str(args[0]) else None})()
    db=Connection()
    assert next_document_number(db,'FT',date(2026,9,21))=='FT-000002-2026'
    assert next_document_number(db,'FT',date(2026,9,21))=='FT-000003-2026'


def test_product_in_ddt_cannot_be_archived(monkeypatch):
    from app import catalog
    class Db:
        def __enter__(self):return self
        def __exit__(self,*args):return False
        def execute(self,sql,args):
            if sql.startswith('UPDATE products'):raise AssertionError('product archived despite DDT')
            found=sql.startswith('SELECT id FROM products') or 'FROM delivery_lines' in sql
            return type('Rows',(),{'fetchone':lambda _: {'id':1} if found else None})()
    monkeypatch.setattr(catalog,'connect',lambda:Db())
    with pytest.raises(HTTPException) as error:
        catalog.archive_product(1,{'id':1,'role':'ADMIN'})
    assert error.value.status_code==409
