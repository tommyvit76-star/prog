from datetime import date

from app.payments import suggested_due_date


def test_end_of_month_plus_ten_days():
    assert suggested_due_date(date(2026, 9, 15), end_of_month=True, extra_days=10) == date(2026, 10, 10)


def test_base_days_then_month_end_and_leap_year():
    assert suggested_due_date(date(2024, 1, 30), default_days=5, end_of_month=True, extra_days=10) == date(2024, 3, 10)


def test_existing_payment_terms_unchanged():
    assert suggested_due_date(date(2026, 9, 15), default_days=30) == date(2026, 10, 15)
