import pytest
from fastapi import HTTPException

from app.import_export import parse_csv
from app.reports_pdf import pdf_response


def test_csv_import_rejects_missing_article_columns_and_accepts_semicolon():
    with pytest.raises(HTTPException):
        parse_csv('codice;descrizione\nA;Valvola')
    assert parse_csv('codice;descrizione;unita\nA;Valvola;PZ')[0]['codice']=='A'


def test_pdf_export_starts_with_pdf_header(monkeypatch):
    class Conn:
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def execute(self,*args):return self
        def fetchone(self):return {'name':'Azienda test','vat_number':'123','address':'Via Roma',
            'postal_code':'24000','city':'Bergamo','province':'BG','phone':'','email':'','logo_data':None}
    monkeypatch.setattr('app.reports_pdf.connect',lambda:Conn())
    response=pdf_response('DDT prova',['Articolo','Quantità'],[('Valvola','2,5')])
    assert response.body.startswith(b'%PDF-')
    assert response.media_type=='application/pdf'
