"""Regression checks for the risky links in the update."""
from decimal import Decimal
from types import SimpleNamespace

import pytest
from fastapi import HTTPException

from app.catalog import number, sequential_discounts
from app.domain import quantity
from app.import_export import workbook_csv
from app.numbering import assert_free_number, proposed_number
from app.workflow import sal_values


def test_italian_decimal_input_and_sequential_purchase_discounts():
    assert number('1.234,500', 3) == Decimal('1234.500')
    assert quantity('1.234,5') == Decimal('1234.5')
    assert sequential_discounts(Decimal('100'), [Decimal('40'), Decimal('20'), Decimal('40')]) == Decimal('28.8000')


def test_invalid_excel_is_rejected_before_database_write():
    with pytest.raises(HTTPException, match='File Excel non valido'):
        workbook_csv('non è base64')


class NumberConnection:
    def __init__(self):
        self.calls=[]

    def execute(self, statement, params):
        self.calls.append((statement, params))
        if 'last_number FROM document_sequences' in statement:
            return SimpleNamespace(fetchone=lambda: {'last_number': 4})
        if 'SELECT id FROM quotes' in statement:
            return SimpleNamespace(fetchone=lambda: {'id': 13})
        return SimpleNamespace(fetchone=lambda: None)


def test_forced_number_collision_is_rejected_in_transaction():
    connection=NumberConnection()
    with pytest.raises(HTTPException) as error:
        assert_free_number(connection, 'PRE', 'PRE-000005-2026')
    assert error.value.status_code == 409
    assert any('pg_advisory_xact_lock' in query for query, _ in connection.calls)


def test_sal_without_explicit_amount_uses_quote_taxable(monkeypatch):
    import app.workflow as workflow
    monkeypatch.setattr(workflow, 'quote_details', lambda connection, quote_id: {'subtotal': '1500.00'})
    class Conn:
        def execute(self, query, args):
            return SimpleNamespace(fetchone=lambda: {'customer_id': 3})
    data=SimpleNamespace(description='Impianto',status='PARTIAL',quote_id=4,customer_id=3,
                         percent='25',amount='',vat_rate='22',model_dump=lambda: {})
    result=sal_values(Conn(),data)
    assert result['amount']==Decimal('375.00')
    assert result['percent']==Decimal('25')
