from datetime import date
from app import movement_reports


class Cursor:
    def __init__(self):
        self.sql = ''
        self.args = ()
    def execute(self, sql, args):
        self.sql, self.args = sql, args
        return self
    def fetchall(self):
        return []
    def __enter__(self):
        return self
    def __exit__(self, *args):
        pass


def test_combined_report_filters_remain_parameterized(monkeypatch):
    cursor = Cursor()
    monkeypatch.setattr(movement_reports, 'connect', lambda: cursor)
    assert movement_reports.query_movements(product_id=7,warehouse_id=2,kind='LOAD',
           actor="O'Brien",reason='prelievo',date_from=date(2026,1,1),date_to=date(2026,1,31)) == []
    assert "O'Brien" not in cursor.sql
    assert cursor.args == (7, 'LOAD', 2, 2, "%O'Brien%", '%prelievo%', date(2026,1,1), date(2026,1,31), 501)
