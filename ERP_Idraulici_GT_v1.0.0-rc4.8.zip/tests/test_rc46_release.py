from datetime import date
from decimal import Decimal
from pathlib import Path

from app.billing import LineIn, line_values
from app.workflow import DeliveryIn, SalIn, sal_values
from app.admin import TestResetIn as ResetInput
from app.document_editor import InvoiceDocument, QuoteDocument
from app.payments import InvoiceIn
from app.quotes import QuoteIn
from app.professional import ProjectIn, save_project
from fastapi import HTTPException
import pytest


class NoQueryDb:
    def execute(self, query, args):
        raise AssertionError(query)


def test_service_line_discards_hidden_product_and_warehouse_values():
    values = line_values(LineIn(
        kind='SERVICE', product_id=12, warehouse_id=4,
        description='', quantity='1', unit_price='80', vat_rate='22'
    ))
    assert values['product_id'] is None
    assert values['warehouse_id'] is None
    assert values['taxable'] == Decimal('80.00')


def test_discount_line_discards_hidden_catalog_values():
    values = line_values(LineIn(
        kind='DISCOUNT', product_id=12, warehouse_id=4,
        description='', quantity='1', unit_price='10', vat_rate='22'
    ))
    assert values['product_id'] is None
    assert values['warehouse_id'] is None
    assert values['taxable'] == Decimal('-10.00')


def test_empty_sal_draft_gets_zero_economic_defaults():
    data = SalIn(customer_id=2, issued_on=date(2026, 9, 26), percent='', amount='')
    values = sal_values(NoQueryDb(), data)
    assert values['percent'] == Decimal('0.00')
    assert values['amount'] == Decimal('0.00')
    assert values['vat_rate'] == Decimal('22.00')


def test_all_ddt_fixed_vat_defaults_are_22_percent():
    data = DeliveryIn(customer_id=2, issued_on=date(2026, 9, 26))
    assert {data.global_labor_vat, data.global_travel_vat,
            data.global_service_vat, data.global_discount_vat} == {'22'}


def test_reset_has_safe_standard_scope_and_explicit_full_scope():
    assert ResetInput(password='x', confirmation='AZZERA DATI DI PROVA').scope == 'OPERATIONS'
    assert ResetInput(password='x', confirmation='AZZERA TUTTO', scope='ALL_MASTER').scope == 'ALL_MASTER'


def test_browser_normalizes_every_optional_date_family_and_filters_placeholder_rows():
    source = (Path(__file__).parents[1] / 'web' / 'app.js').read_text(encoding='utf-8')
    documents = (Path(__file__).parents[1] / 'web' / 'documents.js').read_text(encoding='utf-8')
    for suffix in ("endsWith('_date')", "endsWith('_on')", "endsWith('_from')", "endsWith('_to')"):
        assert suffix in source
    assert "filter(d=>d.id||d.product_id" in documents
    assert "global_labor_vat:'22'" in documents


def test_customer_code_migration_is_unique_and_backfills_existing_records():
    sql = (Path(__file__).parents[1] / 'migrations' / '0026_release_rc4_6.sql').read_text(encoding='utf-8')
    assert "UPDATE customers SET code='CLI-'" in sql
    assert 'CREATE UNIQUE INDEX' in sql


def test_invoice_and_quote_drafts_accept_no_rows_until_confirmation():
    invoice = InvoiceDocument(header=InvoiceIn(customer_id=1, issue_date=date(2026, 9, 26)))
    quote = QuoteDocument(header=QuoteIn(customer_id=1, issue_date=date(2026, 9, 26), title='Bozza'))
    assert invoice.lines == []
    assert quote.lines == []


def test_project_contract_number_is_unique_case_insensitively(monkeypatch):
    class Result:
        def __init__(self, row=None): self.row = row
        def fetchone(self): return self.row
    class Db:
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def execute(self, query, args=None):
            if 'lower(trim(contract_number))' in query: return Result({'exists': True})
            return Result()
    monkeypatch.setattr('app.professional.connect', lambda: Db())
    data = ProjectIn(code='C-1', name='Cantiere', customer_id=1, contract_number=' contratto-7 ')
    with pytest.raises(HTTPException, match='Numero di contratto già presente'):
        save_project(data, {'id': 1, 'role': 'ADMIN'})
