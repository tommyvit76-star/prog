import os
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import HTTPException

from app import backups
from app.api import ContactIn
from app.catalog import PriceListIn, price_list_values, number
from app.domain import quantity
from app.payments import MethodIn
from app.pdf_layout import render_document
from app.quotes import decimal
from app.workflow import first_movement_id, validate_project_sal


def test_backup_rotation_keeps_only_seven_newest(tmp_path, monkeypatch):
    folder=tmp_path/'erp';folder.mkdir()
    for index in range(8):
        item=folder/f'erp_20260101_00000{index}_aaaaaa.dump'
        item.write_bytes(b'PGDMP'+b'x'*100)
        os.utime(item,(index,index))
    monkeypatch.setattr(backups,'ROOT',tmp_path)
    monkeypatch.setattr(backups,'settings',lambda: ({},'erp'))
    monkeypatch.setattr(backups,'validate_archive',lambda *args: None)
    def command(args,*_args,**_kwargs):
        Path(args[args.index('--file')+1]).write_bytes(b'PGDMP'+b'x'*100)
        return SimpleNamespace(stdout=b'')
    monkeypatch.setattr(backups,'command',command)
    backups.create_backup()
    assert len(list(folder.glob('erp_*.dump')))==7


def test_customer_and_price_list_support_payment_and_sequential_discounts():
    customer=ContactIn(name='Cliente',payment_method_id=4,discount_mode='SEQUENTIAL',discount_1='40',discount_2='20',discount_3='20')
    assert customer.payment_method_id==4
    assert customer.discount_mode=='SEQUENTIAL'
    values=price_list_values(PriceListIn(code='L1',name='Listino',discount_mode='SEQUENTIAL',discount_1='40',discount_2='20',discount_3='20'))
    assert values[1]=='SEQUENTIAL'
    assert values[2:]==(Decimal('40.00'),Decimal('20.00'),Decimal('20.00'))


def test_payment_method_controls_iban_visibility():
    assert MethodIn(name='Bonifico').show_iban is True
    assert MethodIn(name='Contanti',show_iban=False).show_iban is False


def test_zero_project_sal_is_allowed_only_as_draft():
    validate_project_sal(Decimal('0'),Decimal('0'),Decimal('100'),'DRAFT')
    with pytest.raises(HTTPException,match='residuo'):
        validate_project_sal(Decimal('0'),Decimal('0'),Decimal('100'),'ISSUED')


def test_missing_ddt_stock_movement_is_a_controlled_error():
    with pytest.raises(HTTPException,match='magazzino'):
        first_movement_id([])
    assert first_movement_id([{'id':17}])==17


def test_professional_pdf_accepts_recipient_payment_and_logistics():
    payload=render_document('DDT-000001-2026',['Descrizione','Totale €'],[('Materiale','10,00')],
        company={'name':'G&T','vat_number':'123'},recipient={'name':'Cliente','address':'Via Roma'},
        payment=('Bonifico','IBAN IT00'),logistics=(('Causale','Vendita'),('Colli','2')),
        footer=('TOTALE € 10,00',))
    assert payload.startswith(b'%PDF')
    assert len(payload)>1500


def test_rc47_ui_keeps_login_enter_and_review_confirmation_buttons():
    root=Path(__file__).parents[1]
    app=(root/'web'/'app.js').read_text('utf-8')
    documents=(root/'web'/'documents.js').read_text('utf-8')
    assert "form?.id==='loginForm'" in app and 'form.requestSubmit()' in app
    assert "['+ Prestazione'" not in documents
    assert "['+ Sconto'" not in documents
    assert "document-number-value" in (root/'web'/'documents.css').read_text('utf-8')


def test_rc47_migration_is_additive_and_preserves_operational_data():
    sql=(Path(__file__).parents[1]/'migrations'/'0028_release_rc4_7.sql').read_text('utf-8').upper()
    assert 'SHOW_IBAN' in sql and 'DISCOUNT_MODE' in sql
    assert 'TRUNCATE' not in sql and 'DELETE FROM' not in sql


def test_document_numbers_remove_harmless_javascript_float_tails():
    assert decimal('3.0000000000000027', places=4) == Decimal('3.0000')
    assert quantity('3.0000000000000027') == Decimal('3.0000')
    assert number('22.000000000000004', places=2) == Decimal('22.00')
    with pytest.raises(HTTPException, match='Numero non valido'):
        decimal('3.00001', places=4)
    with pytest.raises(ValueError, match='four decimal'):
        quantity('3.00001')


def test_all_shared_document_rows_use_compact_canonical_fields():
    root=Path(__file__).parents[1]
    formatting=(root/'web'/'format.js').read_text('utf-8')
    documents=(root/'web'/'documents.js').read_text('utf-8')
    css=(root/'web'/'documents.css').read_text('utf-8')
    assert 'function canonicalDecimal' in formatting
    assert "v=canonicalDecimal(v,k)" in documents
    assert "quantity:canonicalDecimal(l.remaining_quantity,'quantity')" in documents
    assert 'repeat(8,minmax(0,1fr))' in css
    assert '.document-line textarea{height:31px' in css
