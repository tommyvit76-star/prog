from decimal import Decimal
from datetime import date
import pytest
from fastapi import HTTPException
from app.quotes import QuoteIn, line_price, decimal, serialize, validated


def test_excel_sequential_supplier_discounts_labor_and_technical_cost():
    line = dict(kind='MATERIAL', quantity=Decimal('1.5'), purchase_gross=Decimal('100'),
                discount_1=Decimal('40'), discount_2=Decimal('20'), discount_3=Decimal('40'),
                markup_percent=Decimal('25'), labor_minutes=Decimal('30'),
                technician_hours=Decimal('0.5'), unit_price=Decimal('0'), fixed_adjustment=Decimal('0'))
    # 100 * .6 * .8 * .6 = 28.8; +25% => 36; +16 labor +20 technician = 72/unit.
    assert line_price(line, dict(labor_rate=Decimal('32'), technician_rate=Decimal('40'))) == Decimal('108.00')


def test_extra_discount_and_kilometers_are_visible_in_totals():
    header = dict(kilometers=Decimal('100'), kilometer_rate=Decimal('0.68'), working_days=Decimal('2'))
    lines = [dict(kind='DISCOUNT', fixed_adjustment=Decimal('-10'), quantity=Decimal('1.5'),
                  vat_rate=Decimal('22'))]
    result = serialize(header, lines)
    assert result['lines'][0]['total'] == '-15.00'
    assert result['kilometer_total'] == '136.00'
    assert result['subtotal'] == '121.00'
    assert result['total'] == '147.62'


def test_decimal_inputs_reject_unsafe_precision_and_accept_comma():
    assert decimal('2,358') == Decimal('2.358')
    with pytest.raises(HTTPException):
        decimal('1.00001')


def test_three_decimal_price_is_retained_on_print_and_cent_total():
    header = dict(kilometers=Decimal('0'), kilometer_rate=Decimal('0.68'), working_days=Decimal('1'))
    line = dict(kind='SERVICE', quantity=Decimal('1'), purchase_gross=Decimal('0'),
                discount_1=Decimal('0'), discount_2=Decimal('0'), discount_3=Decimal('0'),
                markup_percent=Decimal('0'), labor_minutes=Decimal('0'),
                technician_hours=Decimal('0'), unit_price=Decimal('2.358'),
                fixed_adjustment=Decimal('0'), vat_rate=Decimal('22'))
    result = serialize(header, [line])
    assert result['lines'][0]['display_unit_price'] == '2.358'
    assert result['lines'][0]['total'] == '2.36'


def test_optional_labor_band_and_workdays_derived_from_minutes():
    header=dict(labor_rate=Decimal('32'),labor_rate_1=Decimal('25'),labor_rate_2=Decimal('28'),
                labor_rate_3=Decimal('35'),technician_rate=Decimal('40'),workers=2,
                minutes_per_day=Decimal('600'),auto_working_days=True,working_days=Decimal('3'),
                kilometers=Decimal('100'),kilometer_rate=Decimal('0.68'))
    line=dict(kind='MATERIAL',quantity=Decimal('2'),purchase_gross=Decimal('0'),
              discount_1=Decimal('0'),discount_2=Decimal('0'),discount_3=Decimal('0'),
              markup_percent=Decimal('0'),labor_minutes=Decimal('300'),labor_band=1,
              technician_hours=Decimal('0'),unit_price=Decimal('0'),fixed_adjustment=Decimal('0'),
              vat_rate=Decimal('22'))
    result=serialize(header,[line])
    assert result['working_days_effective']=='0.500'
    assert result['kilometer_total']=='34.00'
    assert result['lines'][0]['total']=='250.00'
    assert result['total_without_km']=='305.00'


def test_customer_discounts_are_sequential_and_separate_from_supplier_discounts():
    header=dict(kilometers=Decimal('0'),kilometer_rate=Decimal('0.68'),working_days=Decimal('1'),
                manual_labor_cost=Decimal('50'))
    line=dict(kind='MATERIAL',quantity=Decimal('2'),purchase_gross=Decimal('100'),
              discount_1=Decimal('50'),discount_2=Decimal('0'),discount_3=Decimal('0'),
              pricing_mode='MANUAL',sale_discount_1=Decimal('10'),sale_discount_2=Decimal('20'),
              sale_discount_3=Decimal('0'),markup_percent=Decimal('0'),labor_minutes=Decimal('0'),
              technician_hours=Decimal('0'),unit_price=Decimal('100'),fixed_adjustment=Decimal('0'),
              vat_rate=Decimal('22'))
    result=serialize(header,[line])
    assert result['lines'][0]['display_unit_price']=='72.000'
    assert result['lines'][0]['total']=='144.00'
    assert result['manual_labor_cost']=='50.00'
    assert result['subtotal']=='194.00'
    assert result['total']=='236.68'


def test_quote_accepts_exactly_one_customer_or_supplier():
    supplier = validated(QuoteIn(issue_date=date(2026, 9, 24), title='Acquisto materiali',
                                 party_type='SUPPLIER', supplier_id=7))
    assert supplier['supplier_id'] == 7
    assert supplier['customer_id'] is None
    with pytest.raises(HTTPException):
        validated(QuoteIn(issue_date=date(2026, 9, 24), title='Non valido',
                          party_type='SUPPLIER', supplier_id=7, customer_id=1))
