from contextlib import contextmanager
from pathlib import Path

import pytest

from app.admin import TestResetIn as ResetInput, reset_test_data
from app.api import app
from app.reports_pdf import titled


class _Result:
    def __init__(self, row=None):
        self._row = row

    def fetchone(self):
        return self._row


class _ResetDb:
    def __init__(self):
        self.queries = []

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def execute(self, query, args=None):
        self.queries.append((query, args))
        if query.startswith('SELECT password_hash FROM users'):
            return _Result({'password_hash': 'valid'})
        if query.startswith('SELECT count(*) AS n FROM'):
            return _Result({'n': 2})
        return _Result()


@contextmanager
def _exclusive():
    yield


@pytest.mark.parametrize(
    ('scope', 'confirmation', 'must_include', 'must_exclude'),
    [
        ('OPERATIONS', 'AZZERA DATI DI PROVA', 'invoice_register', 'customers'),
        ('ALL_MASTER', 'AZZERA TUTTO', 'customers', None),
    ],
)
def test_reset_executes_one_atomic_truncate_and_returns_backup(
    monkeypatch, scope, confirmation, must_include, must_exclude
):
    database = _ResetDb()
    monkeypatch.setattr('app.admin.connect', lambda: database)
    monkeypatch.setattr('app.admin.verify_password', lambda password, hashed: password == 'segreta')
    monkeypatch.setattr('app.backups.exclusive', _exclusive)
    monkeypatch.setattr('app.backups.create_backup', lambda: Path('backup-prima-del-reset.dump'))

    result = reset_test_data(
        ResetInput(password='segreta', confirmation=confirmation, scope=scope),
        {'id': 1, 'role': 'ADMIN'},
    )

    truncates = [query for query, _ in database.queries if query.startswith('TRUNCATE TABLE')]
    assert len(truncates) == 1
    assert must_include in truncates[0]
    if must_exclude:
        assert must_exclude not in truncates[0]
    assert 'RESTART IDENTITY' in truncates[0]
    assert result['ok'] is True
    assert result['backup'] == 'backup-prima-del-reset.dump'


def test_clean_start_migration_clears_operations_and_preserves_master_data():
    sql = (Path(__file__).parents[1] / 'migrations' / '0027_user_requested_clean_start.sql').read_text('utf-8')
    for table in ('quotes', 'delivery_notes', 'progress_certificates', 'invoice_register',
                  'credit_notes', 'payment_due', 'movements', 'balances',
                  'document_sequences', 'audit_events'):
        assert table in sql
    for preserved in ('users', 'company_settings', 'customers', 'suppliers', 'products', 'warehouses'):
        assert preserved not in sql.split('TRUNCATE TABLE', 1)[1]
    assert 'RESTART IDENTITY' in sql


@pytest.mark.parametrize(
    ('label', 'number', 'expected'),
    [
        ('Preventivo', 'Preventivo 7', 'Preventivo 7'),
        ('DDT', 'DDT-000001-2026', 'DDT-000001-2026'),
        ('SAL', 'SAL-000001-2026', 'SAL-000001-2026'),
        ('Fattura', 'FT-000001-2026', 'Fattura FT-000001-2026'),
        ('Nota di credito', 'NC-000001-2026', 'Nota di credito NC-000001-2026'),
    ],
)
def test_pdf_titles_never_repeat_the_document_label(label, number, expected):
    assert titled(label, number) == expected


def test_every_api_method_has_one_unique_route_and_core_document_routes_exist():
    schema = app.openapi()
    operations = []
    for path, methods in schema['paths'].items():
        for method in methods:
            if method.lower() in {'get', 'post', 'put', 'patch', 'delete'}:
                operations.append((path, method.lower()))
    assert len(operations) == len(set(operations))
    for path in ('/quotes', '/delivery-notes', '/projects', '/progress-certificates',
                 '/invoice-register', '/credit-notes', '/admin/reset-test-data'):
        assert path in schema['paths']


def test_home_is_the_first_explicit_menu_entry():
    source = (Path(__file__).parents[1] / 'web' / 'app.js').read_text('utf-8')
    marker = "nav.replaceChildren();nav.append(btn('🏠 HOME',openHome"
    assert marker in source
    assert source.index(marker) < source.index('for(const [key,group] of Object.entries(menuGroups))')
