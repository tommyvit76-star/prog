from pathlib import Path

from app.quotes import linked_invoice_for_quote
from app.reports_pdf import status_name


ROOT = Path(__file__).parents[1]


class InvoiceLookupConnection:
    def __init__(self, row=None):
        self.row = row
        self.sql = ''
        self.params = ()

    def execute(self, sql, params):
        self.sql, self.params = sql, params
        return self

    def fetchone(self):
        return self.row


def test_quote_invoice_lookup_covers_header_lines_and_references():
    conn = InvoiceLookupConnection({'id': 7, 'number': 'FT-7', 'document_status': 'CONFIRMED'})
    result = linked_invoice_for_quote(conn, 12, exclude_invoice_id=4)
    assert result['number'] == 'FT-7'
    assert 'i.quote_id=%s' in conn.sql
    assert 'invoice_lines' in conn.sql and 'source_quote_id=%s' in conn.sql
    assert 'invoice_references' in conn.sql and 'r.quote_id=%s' in conn.sql
    assert conn.params == (4, 12, 12, 12)


def test_statuses_are_translated_for_interface_and_pdfs():
    assert status_name('DRAFT') == 'Bozza'
    assert status_name('INVOICED') == 'Fatturato'
    formatting = (ROOT / 'web' / 'format.js').read_text('utf-8')
    css = (ROOT / 'web' / 'documents.css').read_text('utf-8')
    assert "DRAFT:'Bozza'" in formatting and "INVOICED:'Fatturato'" in formatting
    assert '.status-badge' in css and '.status-positive' in css and '.status-danger' in css


def test_compact_article_and_dual_customer_search_are_shared_by_documents():
    app = (ROOT / 'web' / 'app.js').read_text('utf-8')
    documents = (ROOT / 'web' / 'documents.js').read_text('utf-8')
    assert 'function attachProductSearch' in app
    assert "select.hidden=true;select.required=false" in app
    assert 'clean(row.code).startsWith(q)||clean(row.description).startsWith(q)' in app
    assert "btn('🔭 Cerca',openDetailed" in app
    assert 'function attachCustomerSearch' in documents
    assert "code.placeholder='Inizia a scrivere il codice'" in documents
    assert "name.placeholder='Inizia a scrivere il nome'" in documents
    assert "clean(row[field]).startsWith(query)" in documents


def test_invoice_notes_and_optional_globals_follow_document_rows():
    documents = (ROOT / 'web' / 'documents.js').read_text('utf-8')
    start = documents.index('invoiceDocumentPage=async function')
    end = documents.index('const previousQuoteDetail', start)
    invoice = documents[start:end]
    assert invoice.index("lines=commercialRows") < invoice.index("Note e valori globali facoltativi")
    assert "notesLabel.remove()" in invoice


def test_confirmation_returns_to_list_and_credit_note_opens_visible_loading_state():
    documents = (ROOT / 'web' / 'documents.js').read_text('utf-8')
    assert 'await confirmAction();if(form.isConnected)await render(module)' in documents
    assert "creditDocumentPage=async function(id=null){clear(id?'Nota di credito':'Nuova nota di credito')" in documents
    assert 'Impossibile aprire la nota di credito' in documents


def test_invoiced_quotes_are_filtered_and_rejected_server_side():
    documents = (ROOT / 'web' / 'documents.js').read_text('utf-8')
    professional_ui = (ROOT / 'web' / 'professional.js').read_text('utf-8')
    professional_api = (ROOT / 'app' / 'professional.py').read_text('utf-8')
    workflow = (ROOT / 'app' / 'workflow.py').read_text('utf-8')
    billing = (ROOT / 'app' / 'billing.py').read_text('utf-8')
    assert '!q.linked_invoice' in documents
    assert '!q.linked_invoice' in professional_ui
    assert 'linked_invoice_for_quote(conn,quote_id)' in professional_api
    assert 'linked_invoice_for_quote(conn,data.quote_id)' in workflow
    assert 'linked_invoice_for_quote(conn,quote_id,invoice_id)' in billing
