import pytest
from fastapi import HTTPException

from app.banking import clean_iban


def test_iban_normalizes_spaces_and_checks_digits():
    assert clean_iban('it60 x054 2811 1010 0000 0123 456') == 'IT60X0542811101000000123456'
    assert clean_iban('') == ''


def test_iban_rejects_wrong_check_digits():
    with pytest.raises(HTTPException):
        clean_iban('IT61X0542811101000000123456')
