import pytest
from fastapi import HTTPException
from app import api


class FakeCursor:
    def __init__(self, code, in_use):
        self.code, self.in_use, self.last = code, in_use, ''
        self.statements = []

    def execute(self, statement, args):
        self.last = statement
        self.statements.append(statement)

    def fetchone(self):
        if self.last.startswith('SELECT code'):
            return {'code': self.code} if self.code else None
        if self.last.startswith('SELECT 1'):
            return {'?column?': 1} if self.in_use else None
        return None


class FakeConnection:
    def __init__(self, cursor):
        self.current = cursor

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def cursor(self):
        return FakeConnectionCursor(self.current)


class FakeConnectionCursor(FakeConnection):
    def __enter__(self):
        return self.current


@pytest.mark.parametrize('code,in_use,expected', [('MT', False, 409), ('CUSTOM', True, 409), (None, False, 404)])
def test_unit_delete_rejects_protected_or_used(monkeypatch, code, in_use, expected):
    cur = FakeCursor(code, in_use)
    monkeypatch.setattr(api, 'connect', lambda: FakeConnection(cur))
    with pytest.raises(HTTPException) as exc:
        api.delete_unit(7, {'id': 1})
    assert exc.value.status_code == expected
    assert not any(s.startswith('DELETE FROM units') for s in cur.statements)


def test_unit_delete_records_audit(monkeypatch):
    cur = FakeCursor('CUSTOM', False)
    monkeypatch.setattr(api, 'connect', lambda: FakeConnection(cur))
    assert api.delete_unit(7, {'id': 1}) == {'ok': True}
    assert any(s.startswith('DELETE FROM units') for s in cur.statements)
    assert any(s.startswith('INSERT INTO audit_events') for s in cur.statements)
