from pathlib import Path
from types import SimpleNamespace

import pytest

from app import backups


def test_bad_archive_cannot_reach_database_swap(tmp_path, monkeypatch):
    archive = tmp_path / 'foreign.dump'
    archive.write_bytes(b'not a PostgreSQL backup')
    monkeypatch.setattr(backups, 'settings', lambda: ({}, 'erp'))
    monkeypatch.setattr(backups.psycopg, 'connect', lambda *a, **kw: pytest.fail('Database opened for invalid archive'))
    with pytest.raises(ValueError, match='PostgreSQL'):
        backups.restore_archive(archive)


def test_failed_dump_does_not_leave_backup_file(tmp_path, monkeypatch):
    monkeypatch.setattr(backups, 'ROOT', tmp_path)
    monkeypatch.setattr(backups, 'settings', lambda: ({}, 'erp'))
    def fail(*args, **kwargs):
        raise RuntimeError('pg_dump failed')
    monkeypatch.setattr(backups, 'command', fail)
    with pytest.raises(RuntimeError):
        backups.create_backup()
    assert list((tmp_path / 'erp').iterdir()) == []


def test_archive_requires_erp_tables(tmp_path, monkeypatch):
    archive = tmp_path / 'another_app.dump'
    archive.write_bytes(b'PGDMP' + b'0' * 100)
    monkeypatch.setattr(backups, 'command', lambda *a, **kw: SimpleNamespace(stdout=b'123; 1259 19 TABLE public something erp\n'))
    with pytest.raises(ValueError, match='gestionale'):
        backups.validate_archive(archive, {})
