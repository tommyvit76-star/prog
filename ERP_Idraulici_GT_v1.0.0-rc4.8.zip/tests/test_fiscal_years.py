from datetime import date
from types import SimpleNamespace

import pytest
from fastapi import HTTPException

from app.fiscal_years import assert_open, year_checks


class Result:
    def __init__(self, one): self.one=one
    def fetchone(self): return self.one


class FiscalDB:
    def __init__(self,status='OPEN'): self.status=status
    def execute(self,sql,args=None):
        if 'FROM fiscal_years' in sql:return Result({'year':2026,'starts_on':date(2026,1,1),'ends_on':date(2026,12,31),'status':self.status})
        return Result({'n':0})


def test_open_year_accepts_document_date_and_closed_year_blocks_it():
    assert assert_open(FiscalDB(),date(2026,9,23))['status']=='OPEN'
    with pytest.raises(HTTPException,match='sola lettura'):
        assert_open(FiscalDB('CLOSED'),date(2026,9,23))


def test_clean_year_precheck_has_no_blockers_or_warnings():
    assert year_checks(FiscalDB(),2026)==([],[])
