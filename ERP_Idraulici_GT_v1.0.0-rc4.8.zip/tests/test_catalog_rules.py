from decimal import Decimal
import pytest
from fastapi import HTTPException
from app.catalog import number, discounted_price, sequential_discounts
from app.stock import move


def test_customer_list_price_and_discount_use_decimal():
    assert discounted_price(number('129.90'), number('17.50', 2, Decimal('100'))) == Decimal('107.1675')
    assert discounted_price(number('0'), number('100', 2, Decimal('100'))) == Decimal('0.0000')


@pytest.mark.parametrize('value', ['-1', '1.00001', 'NaN', 'Infinity', '1,25.0'])
def test_bad_prices_are_rejected(value):
    with pytest.raises(HTTPException):
        number(value)


def test_stock_cannot_be_manipulated_with_wrong_movement_kind():
    common=dict(product_id=1, amount='2.50', actor='admin', reason='test')
    with pytest.raises(ValueError, match='annullare un movimento'):
        move(None, source_id=None, destination_id=1, kind='REVERSAL', **common)
    with pytest.raises(ValueError, match='partenza e destinazione'):
        move(None, source_id=1, destination_id=None, kind='TRANSFER', **common)
    with pytest.raises(ValueError, match='destinazione'):
        move(None, source_id=1, destination_id=2, kind='LOAD', **common)
    with pytest.raises(ValueError, match='reso scegli'):
        move(None, source_id=1, destination_id=None, kind='SUPPLIER_RETURN', **common)
    with pytest.raises(ValueError, match='solo per un reso'):
        move(None, source_id=1, destination_id=None, kind='CONSUME', supplier_id=4, **common)


def test_three_independent_supplier_discounts_and_three_decimal_price():
    assert number('2,358') == Decimal('2.358')
    assert sequential_discounts(Decimal('100.0000'), [Decimal('40'), Decimal('20'), Decimal('40')]) == Decimal('28.8000')
    assert sequential_discounts(Decimal('100.0000'), [Decimal('10'), Decimal('5'), Decimal('0')]) == Decimal('85.5000')
