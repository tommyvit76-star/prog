from decimal import Decimal
from types import SimpleNamespace

import pytest
from fastapi import HTTPException

from app.workflow import delivery_amount, delivery_detail, sal_values


class Result:
    def __init__(self, *, rows=None, row=None):
        self.rows = rows or []
        self.row = row

    def fetchall(self):
        return self.rows

    def fetchone(self):
        return self.row


def test_delivery_amount_includes_each_fixed_value_once():
    class Conn:
        def execute(self, query, args):
            if 'FROM delivery_lines' in query:
                return Result(rows=[{'quantity': Decimal('2'), 'unit_price': Decimal('10'),
                                     'discount_percent': Decimal('0'), 'vat_rate': Decimal('22')}])
            return Result(row={'global_labor': Decimal('30'), 'global_labor_vat': Decimal('22'),
                               'global_travel': Decimal('10'), 'global_travel_vat': Decimal('22'),
                               'global_service': Decimal('5'), 'global_service_vat': Decimal('22'),
                               'global_discount': Decimal('5'), 'global_discount_vat': Decimal('22')})

    assert delivery_amount(Conn(), 1) == (Decimal('60.00'), Decimal('13.20'))


def test_delivery_detail_accepts_zero_fixed_values():
    document={'id': 1, 'global_labor': Decimal('0'), 'global_labor_vat': Decimal('22'),
              'global_travel': Decimal('0'), 'global_travel_vat': Decimal('22'),
              'global_service': Decimal('0'), 'global_service_vat': Decimal('22'),
              'global_discount': Decimal('0'), 'global_discount_vat': Decimal('22')}

    class Conn:
        def execute(self, query, args):
            if 'FROM delivery_notes d JOIN warehouses' in query:
                return Result(row=document)
            if 'FROM delivery_lines' in query:
                return Result(rows=[])
            if 'FROM invoice_sources' in query:
                return Result(row=None)
            raise AssertionError(query)

    detail=delivery_detail(Conn(),1)
    assert detail['totals']['total']=='0.00'


def test_project_quote_requires_project_on_sal():
    class Conn:
        def execute(self, query, args):
            if 'FROM quotes' in query:
                return Result(row={'customer_id': 7})
            if 'AS linked' in query:
                return Result(row={'linked': True})
            raise AssertionError(query)

    data = SimpleNamespace(status='PARTIAL', quote_id=2, project_id=None, customer_id=7,
                           percent='10', amount='100', vat_rate='22', model_dump=lambda: {})
    with pytest.raises(HTTPException) as error:
        sal_values(Conn(), data)
    assert error.value.status_code == 409
