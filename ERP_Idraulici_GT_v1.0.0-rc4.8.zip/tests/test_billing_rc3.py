from datetime import date
from decimal import Decimal
from xml.etree import ElementTree as ET

import pytest
from fastapi import HTTPException

from app.billing import LineIn, installments, line_values, invoice_totals
from app.fiscal_xml import create_xml, NS


def invoice_line(**overrides):
    data=dict(kind='PRODUCT',description='Lavabo',product_id=1,warehouse_id=1,
              quantity='2',unit_price='100',discount_percent='10',discount_amount='0',vat_rate='22')
    data.update(overrides)
    return LineIn(**data)


def test_invoice_lines_material_labor_and_extra_discount():
    material=line_values(invoice_line())
    labor=line_values(invoice_line(kind='SERVICE',description='Posa',product_id=None,warehouse_id=None,
                                    quantity='3',unit_price='40',discount_percent='0'))
    discount=line_values(invoice_line(kind='DISCOUNT',description='Sconto extra',product_id=None,warehouse_id=None,
                                       quantity='1',unit_price='20',discount_percent='0'))
    other=line_values(invoice_line(kind='SERVICE',description='Collaudo',product_id=None,warehouse_id=None,
                                    quantity='1',unit_price='50',discount_percent='0',vat_rate='10'))
    assert [r['taxable'] for r in (material,labor,discount,other)]==list(map(Decimal,['180','120','-20','50']))
    assert material['vat_amount']==Decimal('39.60')
    assert discount['vat_amount']==Decimal('-4.40')


def test_bidirectional_labor_and_travel_values_are_persistable():
    labor=line_values(invoice_line(kind='SERVICE',product_id=None,warehouse_id=None,description='Manodopera',
                                   calculation_mode='LABOR',work_minutes='90',workers=2,hourly_rate='40',discount_percent='0'))
    travel=line_values(invoice_line(kind='SERVICE',product_id=None,warehouse_id=None,description='Trasferta',
                                    calculation_mode='TRAVEL',kilometers='125,5',kilometer_rate='0,68',discount_percent='0'))
    assert labor['unit_price']==Decimal('120.0000') and labor['taxable']==Decimal('120.00')
    assert travel['unit_price']==Decimal('85.3400') and travel['taxable']==Decimal('85.34')


def test_warehouse_is_automatic_and_tax_nature_is_still_validated():
    assert line_values(invoice_line(warehouse_id=None))['warehouse_id'] is None
    with pytest.raises(HTTPException,match='natura fiscale'):
        line_values(invoice_line(kind='SERVICE',product_id=None,warehouse_id=None,vat_rate='0'))
    assert line_values(invoice_line(kind='SERVICE',product_id=None,warehouse_id=None,vat_rate='0',vat_nature='N4'))['vat_amount']==0


def test_due_split_and_month_end_plus_ten():
    rules=[dict(percent='33',base_days=0,end_of_month=True,extra_days=10),
           dict(percent='67',base_days=30,end_of_month=False,extra_days=0)]
    result=installments(Decimal('396.60'),date(2026,9,21),rules)
    assert result==[(date(2026,10,10),Decimal('130.88')),(date(2026,10,21),Decimal('265.72'))]
    with pytest.raises(HTTPException,match='100%'):
        installments(Decimal('100'),date(2026,9,21),rules[:1])


class TotalsDB:
    def execute(self,query,args):
        class Row:
            def __init__(self,rows):self.rows=rows
            def fetchall(self):return self.rows
        if 'FROM invoice_lines' in query:return Row([dict(vat_rate=Decimal('22'),vat_nature='',taxable=Decimal('180'),vat_amount=Decimal('39.6')),
                                                      dict(vat_rate=Decimal('22'),vat_nature='',taxable=Decimal('120'),vat_amount=Decimal('26.4')),
                                                      dict(vat_rate=Decimal('22'),vat_nature='',taxable=Decimal('-20'),vat_amount=Decimal('-4.4')),
                                                      dict(vat_rate=Decimal('10'),vat_nature='',taxable=Decimal('50'),vat_amount=Decimal('5'))])
        return Row([])


def test_invoice_groups_reconcile_with_due_total():
    net,vat=invoice_totals(TotalsDB(),1)
    assert (net,vat,net+vat)==(Decimal('330.00'),Decimal('66.60'),Decimal('396.60'))


def test_xml_preview_contains_balanced_lines_and_payment_dates():
    invoice=dict(id=7,number='FT-2026-000007',issue_date=date(2026,9,21),customer_id=3,
                 document_status='CONFIRMED',fiscal_document_type='TD01',total=Decimal('122.00'),payment_type='TRANSFER',bank_iban='')
    company=dict(name='G T Esempio SNC',vat_number='12345678901',address='Via Roma 1',postal_code='24064',city='Grumello del Monte',
                 province='BG',fiscal_regime='RF01',tax_code='')
    customer=dict(id=3,name='Cliente Esempio SRL',vat_number='10987654321',address='Via Verdi 5',postal_code='24060',city='Bergamo',
                  province='BG',tax_code='',sdi_code='ABC1234',pec='')
    lines=[dict(description='Prestazione esempio',quantity=Decimal('1'),unit_code='ORE',taxable=Decimal('100'),vat_rate=Decimal('22'),
                vat_nature='',discount_percent=Decimal('0'),discount_amount=Decimal('0'))]
    due=[dict(amount=Decimal('122'),due_date=date(2026,10,10))]
    root=ET.fromstring(create_xml(invoice,company,customer,lines,[],{}, {},due))
    tag=lambda name:root.find('.//{'+NS+'}'+name)
    assert tag('Numero').text==invoice['number']
    assert tag('ImponibileImporto').text=='100.00'
    assert tag('Imposta').text=='22.00'
    assert tag('DataScadenzaPagamento').text=='2026-10-10'
    with pytest.raises(HTTPException,match='Partita IVA azienda'):
        create_xml(invoice,{**company,'vat_number':''},customer,lines,[],{}, {},due)
    with pytest.raises(HTTPException,match='scadenze'):
        create_xml(invoice,company,customer,lines,[],{}, {},[{**due[0],'amount':Decimal('100')}])


def test_confirm_creates_dues_and_single_stock_movement_atomically(monkeypatch):
    import app.billing as billing
    class Result:
        def __init__(self,one=None,many=None):self.one=one;self.many=many or []
        def fetchone(self):return self.one
        def fetchall(self):return self.many
    class DB:
        def __init__(self):self.due=[];self.stock=[];self.confirmed=False
        def __enter__(self):return self
        def __exit__(self,*args):return False
        def execute(self,sql,args=None):
            if 'UNION ALL SELECT 1 FROM invoice_sources' in sql:return Result(one={'found':1})
            if 'SELECT 1 FROM invoice_lines WHERE invoice_id' in sql:return Result(one={'found':1})
            if 'SELECT 1 FROM payment_due' in sql:return Result(one=self.due[0] if self.due else None)
            if 'FROM payment_method_installments' in sql:return Result(many=[dict(percent=Decimal('50'),base_days=0,end_of_month=False,extra_days=0),
                                                                         dict(percent=Decimal('50'),base_days=30,end_of_month=False,extra_days=0)])
            if 'FROM company_settings' in sql:return Result(one={'name':'Example','logo_data':None})
            if 'FROM customers' in sql:return Result(one={'id':3,'name':'Customer'})
            if 'SELECT id,product_id,warehouse_id,quantity FROM invoice_lines' in sql:
                return Result(many=[dict(id=8,product_id=3,warehouse_id=2,quantity=Decimal('1.5'))])
            if 'INSERT INTO payment_due' in sql:self.due.append(args);return Result()
            if 'UPDATE invoice_lines SET movement_id' in sql:self.stock.append(args);return Result()
            if "SET document_status='CONFIRMED'" in sql:self.confirmed=True;return Result()
            return Result()
    db=DB()
    monkeypatch.setattr(billing,'connect',lambda:db)
    monkeypatch.setattr(billing,'editable',lambda conn,id: (_ for _ in ()).throw(HTTPException(409,'Confermata')) if db.confirmed else
                        dict(id=id,customer_id=3,issue_date=date(2026,9,21),payment_method_id=2))
    monkeypatch.setattr(billing,'refresh',lambda conn,id:Decimal('122.00'))
    monkeypatch.setattr(billing,'consume_any',lambda conn,**kw: [{'id':88}])
    monkeypatch.setattr(billing,'audit',lambda *args,**kwargs:None)
    response=billing.confirm_invoice(7,{'id':1,'username':'admin'})
    assert response['total']=='122.00'
    assert [args[3] for args in db.due]==[Decimal('61.00'),Decimal('61.00')]
    assert db.stock==[(88,8)] and db.confirmed
    with pytest.raises(HTTPException):billing.confirm_invoice(7,{'id':1,'username':'admin'})
