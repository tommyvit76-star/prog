# Specifica stabile e registro delle decisioni

## Obiettivo

ERP installabile per imprese idrauliche e termoidrauliche italiane, con configurazione aziendale e possibilità di installazioni separate per clienti G&T. Le sei fasi funzionali definite con Tommy restano: base e magazzino; commesse e magazzini multipli; preventivi; SAL; DDT/fatture/pagamenti; FatturaPA e finalizzazione.

## Contratto di integrità

- PostgreSQL è la fonte dei dati. Quantità `NUMERIC(15,4)` e importi economici futuri `NUMERIC`, mai float.
- Ogni variazione di giacenza genera un movimento immutabile. Trasferimenti e consumi avvengono nella stessa transazione delle variazioni di giacenza.
- Blocco delle righe di giacenza in ordine di magazzino per serializzare movimenti concorrenti. Mai giacenza negativa.
- Errori correggibili con movimento inverso motivato, verificando che la giacenza di origine della correzione sia sufficiente.
- I documenti emessi conserveranno snapshot fiscali e riferimenti alle origini; nessun preventivo movimenta automaticamente il magazzino.
- Schema tramite migrazioni numerate e test sui percorsi critici. Prima di modifiche rilevanti: analisi delle dipendenze, checkpoint Git, modifica locale, test interessati e regressione.

## Confini della v0.1.0

Implementati: unità configurabili, articoli essenziali, magazzini centrale/furgone/cantiere/altro, giacenze decimali, carico/scarico/trasferimento/reso/rettifica tramite movimenti generici, storicità e inversione, API locale e Docker Compose.

La v0.2 aggiunge autenticazione base, ruoli, anagrafiche clienti e fornitori e interfaccia responsive. Da fare prima dell'uso operativo: cambio password self-service, difesa da tentativi di login ripetuti, HTTPS, associazione formale magazzino-cantiere, validazione semantica dei tipi movimento, audit completo, backup programmati e ripristino testato, test d'integrazione PostgreSQL in CI. Solo dopo: preventivi, SAL, DDT, fatture e XML conforme alle specifiche ufficiali vigenti.

La v0.3 aggiunge scheda articoli estesa, distinta base, foto in PostgreSQL, listini e sconto cliente, indirizzi di consegna, ricerca combinabile dei movimenti e stampa. La giacenza deriva sempre dal registro immutabile. La percentuale di sconto cliente viene applicata al prezzo del listino scelto, con quattro decimali nel prezzo netto. Un articolo composto non scarica automaticamente i componenti quando viene visualizzato o inserito in una bozza. Il modello Excel del preventivo va esaminato prima di implementarne campi, formule e layout.

La v0.4 introduce preventivi modificabili modellati sul file GIMANI KM_BREVE.xlsx: tre sconti acquisto successivi, ricarico, minuti di manodopera, ore tecnico e trasferta chilometrica per giornate. Il prezzo manuale prevale sul calcolo da costi e tempi; scegliendo un articolo viene proposto il netto del listino cliente. Il cliente e i valori delle righe sono copiati nel preventivo al momento del salvataggio; modifiche successive alle anagrafiche non cambiano la stampa già registrata. La stampa delle giacenze comprende solo quantità positive del filtro/selezione corrente. Non è prevista importazione automatica delle righe dal modello Excel.

La v0.5 separa i diritti di lettura e modifica per modulo, conservando gli account esistenti e la password admin. I DDT in bozza sono modificabili/archiviabili; la conferma registra nello stesso commit i movimenti di consumo e blocca modifiche dirette al DDT. I SAL in bozza gestionale possono essere parziali o completati, con avanzamento cumulativo limitato al 100% se riferiti a un preventivo. Le fatture sono registrazioni di documenti già emessi altrove o bozze gestionali: le fonti DDT/SAL del cliente vengono collegate per mese, gli importi SAL sono frazionabili e un DDT può essere fatturato una sola volta. Il totale delle scadenze non supera il totale fattura. L'emissione fiscale elettronica rimane una fase successiva.

## Fase successiva: gestione impianti e manutenzioni

Realizzare un'anagrafica impianti collegata al cliente e alla sede di installazione (esempio: caldaia), con tipo, marca, modello, matricola, data di installazione, note tecniche e storico degli interventi. Ogni impianto deve avere una o più scadenze di manutenzione pianificabili, con ricorrenza configurabile, data dell'ultimo intervento, prossima data, stato e assegnazione al tecnico. Mostrare un calendario settimanale e mensile e segnalare le manutenzioni scadute con un indicatore rosso molto evidente, anche lampeggiante se l'interfaccia lo consente senza compromettere la leggibilità; distinguere le scadenze prossime da quelle già scadute. Per ogni intervento registrare parti di ricambio necessarie, verificare quantità disponibili per magazzino e indicare quelle da acquistare, senza alterare le giacenze prima del prelievo effettivo. Prevedere modifica, annullamento tracciato degli interventi e filtri per cliente, impianto, tecnico, stato e intervallo di date. Integrare i permessi di questo modulo nel pannello Amministrazione. Questa voce è **da sviluppare**: non è inclusa nella patch v0.5.0.

Accettare virgola e punto come separatore decimale nell'interfaccia di quantità e prezzi, senza arrotondamenti silenziosi. Prezzi persistiti con quattro decimali, quindi anche `2,358`. Gli sconti fornitore 1/2/3 sono percentuali indipendenti e applicate in sequenza; un cambio degli sconti non modifica retroattivamente i movimenti o il prezzo acquisto già registrato. Un reso a fornitore scarica atomicamente il magazzino e conserva il fornitore sul movimento. Il preventivo in bozza dovrà consentire una riga generica negativa per lo sconto extra, con calcoli e imposte definiti dopo l'esame del modello Excel.

## Modifiche

1. Elencare moduli, tabelle, API e dipendenze.
2. Salvare checkpoint Git. Aggiungere una migrazione, senza cambiare quelle già applicate.
3. Modificare il minimo indispensabile e aggiungere test che coprano il comportamento alterato.
4. Eseguire test del nuovo comportamento, regressione dei moduli coinvolti e verifica sul database.
5. Documentare file modificati, risultati e limiti prima di assegnare una nuova versione.
