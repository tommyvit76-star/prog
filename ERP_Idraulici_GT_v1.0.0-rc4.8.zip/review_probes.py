from decimal import Decimal as D
from types import SimpleNamespace
from unittest.mock import patch
from app.quotes import serialize
from app.billing import LineIn, line_values
from app import professional as p

header=dict(kilometers=D(0), kilometer_rate=D(0), working_days=D(1))
line=dict(kind='SERVICE',quantity=D(100),purchase_gross=D(0),discount_1=D(0),
          discount_2=D(0),discount_3=D(0),markup_percent=D(0),labor_minutes=D(0),
          technician_hours=D(0),unit_price=D('1.2345'),fixed_adjustment=D(0),vat_rate=D(22))
q=serialize(header,[line])['lines'][0]
inv=line_values(LineIn(kind='SERVICE',description='Prova',quantity=str(q['quantity']),unit_price=str(line['unit_price'])))
assert q['total']=='123.45' and inv['taxable']==D('123.45')
print('PREVENTIVO -> FATTURA:',q['total'],'->',inv['taxable'])

class DB:
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def execute(self,sql,args):
        if 'SELECT c.status' in sql: row={'status':'DRAFT','fiscal_status':'OPEN'}
        elif 'SELECT * FROM credit_note_lines' in sql:
            row={'quantity':D(1),'original_invoice_line_id':7,'kind':'PRODUCT','product_id':1}
        elif 'SELECT quantity,unit_price' in sql:
            row={'quantity':D(1),'unit_price':D(100),'discount_percent':D(0),'vat_rate':D(22),'discount_amount':D(20),'taxable':D(80)}
        elif sql.startswith('UPDATE credit_note_lines'):
            self.taxable=args[3]; row=None
        else: raise AssertionError(sql)
        return SimpleNamespace(fetchone=lambda:row)
db=DB()
with patch.object(p,'connect',lambda:db),patch.object(p,'audit',lambda *a:None),patch.object(p,'credit_detail',lambda *a:{}):
    p.credit_line(1,1,p.CreditLineEdit(quantity='1'),{'id':1})
assert db.taxable==D('80.00')
print('NOTA CREDITO SCONTO FISSO: imponibile originale 80.00 ->',db.taxable)
