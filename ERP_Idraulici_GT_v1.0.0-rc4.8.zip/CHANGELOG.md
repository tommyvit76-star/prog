# Changelog

## v1.0.0-rc4.8 - ricerche documentali e ciclo commerciale protetto

- Ricerca articoli in una sola riga: digitazione per iniziale di codice o nome, scelta immediata e ricerca dettagliata tramite binocolo.
- Ricerca cliente uniforme in tutti i documenti con campi separati per codice e ragione sociale.
- Note e valori globali facoltativi spostati in fondo alla fattura; conferma di ogni documento con ritorno garantito all'elenco.
- Ripristinata l'apertura della nuova nota di credito con stato di caricamento ed errore leggibile.
- Preventivi già fatturati esclusi da cantieri, DDT, SAL e nuove fatture, con controllo anche lato server; i collegamenti storici restano visibili.
- Stati tecnici tradotti in italiano, con badge colorati negli elenchi e diciture italiane nei PDF.
- Modalità di pagamento e sconti del cliente resi più leggibili nell'anagrafica e validati al salvataggio.
- Nessuna nuova migrazione e nessuna cancellazione dei dati. Verificati 110 test automatici, sintassi JavaScript e compilazione Python.

## v1.0.0-rc4.7.1 — precisione numerica e righe documentali compatte

- Corretta l'importazione Preventivo → DDT che poteva inviare valori come `3.0000000000000027` e impedire il salvataggio.
- Normalizzazione numerica condivisa per preventivi, DDT, SAL, fatture, note di credito e relative righe.
- Il server elimina soltanto le code infinitesimali prodotte dai calcoli del browser e continua a rifiutare una precisione realmente superiore a quella ammessa.
- Righe dei documenti ristrette a una fascia per i dati principali e massimo due fasce per i parametri estesi; descrizione e campi avanzati non occupano più spazio verticale superfluo.
- Aggiunti test di regressione per quantità, prezzi, percentuali e precisione del database; verificati 104 test.

## v1.0.0-rc4.7 — impostazioni commerciali, documenti compatti e stampa professionale

- Il tasto Invio nella schermata iniziale esegue il login; il pulsante Accedi resta disponibile.
- Separata **Amministrazione** dalle impostazioni operative, con accessi diretti a DDT/trasporto, pagamenti, conti correnti, progressivi, listini e anagrafiche.
- La pagina backup conserva e mostra gli ultimi sette archivi, eliminando automaticamente i più vecchi.
- Il riordino da sottoscorta riporta nella scheda articolo la quantità già indicata.
- Clienti e listini supportano uno sconto semplice oppure tre sconti sequenziali; il cliente può avere una modalità di pagamento predefinita, sempre modificabile nel documento.
- Ogni modalità di pagamento può stabilire se mostrare l'IBAN nella fattura.
- Righe documentali compattate; prestazione e sconto sono campi integrati nella riga e non pulsanti duplicabili.
- Le bozze mostrano **Conferma** negli elenchi e si aprono nella maschera completa per controllo e modifica.
- Corrette la conferma DDT senza movimento valido e la gestione delle bozze SAL a importo zero con errori controllati.
- PDF A4 riorganizzati con dati azienda a sinistra, cliente a destra, pagamento e banca, totali e dati logistici dopo i totali.
- Migrazione additiva `0028_release_rc4_7.sql`; nessun dato aziendale viene eliminato.
- Verificati 102 test automatici, sintassi JavaScript/Python e rendering PDF anche multipagina.

## v1.0.0-rc4.6.1 — reset affidabile, avvio pulito e menu Home

- Corretto **Azzera dati di prova**: backup obbligatorio e una sola operazione PostgreSQL atomica per documenti, registri, movimenti, giacenze e progressivi.
- Aggiunta la scelta separata per eliminare anche le anagrafiche operative; utenti, azienda e impostazioni restano conservati.
- La migrazione una tantum `0027_user_requested_clean_start.sql` azzera i dati operativi presenti all'installazione, come richiesto per ricominciare i test con contatori puliti.
- Aggiunta **HOME** come prima voce esplicita del menu, con cruscotto, scorciatoie, ultime attività e sottoscorta.
- Estesi i controlli automatici a reset, migrazione, rotte dei documenti, titoli PDF e menu Home; verificati 94 test.
- Generati e renderizzati esempi multipagina A4 per preventivo, DDT, SAL, fattura e nota di credito.

## v1.0.0-rc4.6 — documenti nuovamente salvabili e flussi completi

- Corrette le bozze DDT: IVA dei quattro valori globali preimpostata al 22%, righe guida vuote escluse dal salvataggio e magazzino scelto automaticamente.
- Corrette fatture e righe prestazione: articolo e magazzino nascosti vengono rimossi automaticamente; prestazione, manodopera, trasferta e sconto sono campi globali facoltativi e non duplicabili.
- Le fatture propongono i documenti del cliente, li ordinano per DDT, cantiere/SAL e preventivo e mostrano le righe sotto il relativo riferimento.
- Le bozze di preventivo, DDT, SAL e fattura possono essere salvate con i soli dati essenziali; la conferma mantiene i controlli più rigorosi.
- Le date facoltative vuote, compresa `certificate_date`, sono inviate come valori nulli e non generano più errori tecnici.
- Aggiunto codice cliente automatico `CLI-000001`, modificabile e univoco; migliorata la ricerca incrementale con conferma a binocolo per clienti e articoli.
- Numero contratto cantiere univoco senza distinzione tra maiuscole e minuscole; messaggi chiari per la dissociazione di preventivi e SAL.
- L’azzeramento dati crea prima un backup, cancella documenti, movimenti, giacenze, registri e progressivi; su scelta esplicita elimina anche le anagrafiche operative.
- Aggiunti test di regressione RC4.6.

## v1.0.0-rc4.5.2 — numero documento sempre visibile

- Preventivi, DDT, SAL, fatture e note di credito mostrano direttamente il numero reale proposto, in grassetto.
- Rimossa la scritta dominante `Progressivo automatico`; resta soltanto una breve nota sotto al numero prima del salvataggio.
- L'amministratore può usare **Modifica numero** per forzare un valore diverso.

## v1.0.0-rc4.5.1 — correzione apertura DDT

- Corretto l'errore `500 Internal Server Error` nell'elenco DDT quando manodopera, trasferta, prestazione o sconto globali valgono zero.
- Aggiunto un test di regressione per i DDT esistenti migrati con i valori globali predefiniti.

## v1.0.0-rc4.5 — ciclo cantiere, documenti uniformi e ricerca guidata

- Ricerca cliente, fornitore e articolo con risultati mentre si digita, pulsante binocolo, selezione esplicita e messaggio quando non trova corrispondenze.
- Liste Magazzini, Articoli con giacenza e Sottoscorta sempre aperte, ciascuna con ricerca propria.
- Maschere documentali più compatte, progressivo effettivo in grassetto e navigazione laterale tra SAL, Cantieri, DDT, Fatture, Note di credito e Scadenze.
- DDT con campi globali unici e facoltativi per manodopera, trasferta, prestazione e sconto; importazione dei soli valori realmente presenti nel preventivo.
- Preventivi del cantiere importati nel DDT in gruppi ordinati; ogni riferimento precede le proprie righe anche nel PDF.
- Preventivi e SAL associati a un cantiere esclusi dalle selezioni dirette; dissociazione ammessa solo finché non esistono documenti dipendenti.
- Fattura guidata per cliente e cantiere: selezione automatica dei SAL approvati e degli eventuali DDT esplicitamente destinati alla vendita diretta.
- SAL con campi per certificato di pagamento, direzione lavori e RUP; i DDT del cantiere sono mostrati come documenti di supporto senza duplicarne il valore.
- Cantieri con tipo contratto, CUP/CIG, regime IVA, oneri sicurezza, ribasso, anticipo, ritenuta e responsabili tecnici.
- Migrazione additiva `0025_release_rc4_5.sql`; nessun dato aziendale viene cancellato.

## v1.0.0-rc4.4 — flusso documenti compatto e correzioni operative

- Ricerca cliente, fornitore e articolo anche per iniziali nelle maschere operative.
- Dopo il salvataggio di preventivi, DDT, SAL, fatture e note di credito si torna automaticamente all'elenco.
- Fattura con selettore dei preventivi, DDT e SAL aperti del cliente e possibilità di aggiungere righe o riferimenti manuali.
- Magazzino scelto automaticamente nei documenti; gli scarichi usano la giacenza complessiva disponibile in tutti i magazzini.
- Descrizione riga facoltativa, progressivi più evidenti e impaginazione più compatta.
- Cantieri modificabili con collegamento di più preventivi, creazione SAL e associazione di SAL esistenti.
- Correzione conferma DDT, azzeramento dati di prova, messaggio backup e titoli duplicati nei PDF.
- Il menu `Registro fatture` è stato rinominato `Fatture`.

## v1.0.0-rc4.3 — maschere uniche, richiami multipli e PDF A4

- Fatture, preventivi, DDT e note di credito salvano intestazione e righe con un solo comando e una sola transazione.
- Una fattura può richiamare contemporaneamente più preventivi, DDT, SAL e cantieri, con importi opzionali e totale aggiornato in anteprima.
- Ogni documento collegato viene presentato con la dicitura `Riferimento a:` prima delle righe di conteggio, anche nei PDF.
- Il DDT importa da preventivo o dal preventivo del cantiere materiali, manodopera e trasporto; gli importi restano modificabili prima del salvataggio.
- Il preventivo accetta un cliente oppure un fornitore, mostra in evidenza il progressivo e rende visibili manodopera e calcolo chilometrico bidirezionale.
- I suggerimenti `?` sono isolati in un fumetto sopra il campo e compaiono solo al puntamento, al focus da tastiera o al tocco.
- Esportazioni PDF uniformate a un layout A4 con intestazione aziendale, tabelle ripetute, totali, firme e numerazione pagina.
- Migrazione additiva `0023_document_links`; i dati esistenti vengono collegati alla nuova struttura senza cancellazioni.

## v1.0.0-rc4.2 — collegamenti, progressivi e collaudo dati di prova

- Fattura in un'unica pagina con origine visibile dopo il cliente: immediata, DDT, preventivo o SAL; le righe manuali restano sempre disponibili.
- Importazione diretta del preventivo in fattura con materiali, manodopera e trasferta; dissociazione della bozza rimuove solo le righe importate e conserva quelle manuali.
- SAL e DDT mostrano la fattura collegata; eliminazione bloccata in presenza di documenti successivi e SAL precedenti protetti quando esiste un SAL successivo.
- Progressivi amministrabili per esercizio e tipo documento, formato predefinito `FT-000001-2026`, senza riutilizzo dei numeri già assegnati.
- Manutenzione amministrativa “Azzera dati di prova” con backup obbligatorio, password e frase di conferma; conserva utenti, password, anagrafiche, articoli e impostazioni.
- Giacenze con Magazzini come primo blocco, ricerche dedicate, dettaglio per magazzino e pulsante “Vai al riordino” senza invio automatico.
- Un solo messaggio vicino al primo campo mancante; aiuti `?` al passaggio del mouse e al tocco sui dispositivi mobili.
- Migrazione additiva `0022_numbering_maintenance`; nessuna cancellazione automatica durante l'aggiornamento.

## v1.0.0-rc4.1 — DDT unica, home operativa e PDF verticali

- DDT realmente unificata: intestazione, origine, trasporto, destinazione, righe, calcoli e totali vengono salvati insieme in un'unica transazione.
- Collegamento preventivo → DDT con importazione delle sole quantità residue; dopo il primo DDT il preventivo non può essere fatturato direttamente e la fattura deve richiamare il DDT.
- Righe DDT per materiali, manodopera, trasferta e sconto; calcoli minuti × persone × tariffa e chilometri × coefficiente, con totali distinti.
- Home con quattro sole aree principali, ultime attività con operatore e pannello sottoscorta.
- Tipografia più leggibile, aiuti contestuali in italiano accessibili con mouse, tastiera e tocco, e campi obbligatori segnalati nell'ordine da completare.
- Tutti i PDF generati dal server sono A4 verticali con caratteri compatti; stampa ed esportazione usano lo stesso documento.
- Migrazione additiva `0021_ddt_quote_single_editor`: conserva utenti, password, anagrafiche, quantità e documenti esistenti.

## v1.0.0-rc4 — documenti separati ed esercizi annuali

- Selettore dell'esercizio in testata, consultazione degli anni precedenti in sola lettura e chiusura annuale amministrativa con controllo bozze, avvisi sulle partite aperte, backup preventivo e apertura dell'anno successivo.
- Fatture, DDT, SAL e note di credito aperti in una pagina dedicata: intestazione, righe, totali e azioni restano nella stessa maschera; l'uscita richiede Salva o Annulla.
- Fattura immediata con cliente registrato oppure occasionale, articoli di magazzino, righe libere, manodopera e trasferta; minuti/persone/tariffa e chilometri/coefficiente ricalcolano l'importo anche in senso inverso.
- PDF A4 professionali con intestazione azienda, destinatario, riquadri, righe e totali. Il comando Stampa apre lo stesso PDF prodotto da Esporta PDF anche per movimenti e scadenze.
- Movimenti di magazzino filtrati per esercizio e scadenze aperte degli anni precedenti mantenute nello scadenziario dell'anno corrente.
- Migrazione additiva `0020_fiscal_years_invoice_calculators`: non cancella utenti, password, anagrafiche o documenti esistenti.

## v1.0.0-rc1 — candidato da provare su NAS

- Backup completi PostgreSQL in `backup/erp`, download e ripristino dalla scheda Amministrazione; orario giornaliero Europe/Rome configurabile. Ripristino prima provato su database temporaneo con copia preventiva del database attuale.
- Importazione ed esportazione CSV articoli, PDF di DDT, SAL, bozze fattura, movimenti e scadenze.
- Listini con percentuali di sconto, preventivi su una maschera, ricarico per categoria e fasce di manodopera, report inventario e adattamento alle schermate mobili.
- Ancora da realizzare: database separato per ogni azienda e selettore azienda; XML FatturaPA convalidato. Il ripristino e la pianificazione richiedono prova con PostgreSQL reale su NAS.

## v0.5.6 — 2026-09-21

- Categorie articolo gestibili nella schermata Articoli; le categorie già inserite vengono recuperate e una rinomina aggiorna gli articoli associati.
- Scelta degli articoli con ricerca per codice o descrizione e filtro per categoria in preventivi, DDT e movimenti; ricerca sul server fino a 100 risultati per richiesta.
- Filtro per categoria nella schermata Articoli. Le categorie in uso non possono essere archiviate.

## v0.5.5 — 2026-09-21

- Conti correnti aziendali modificabili e archiviabili da Amministrazione; IBAN e banca di appoggio nelle anagrafiche clienti e fornitori.
- Modalità bonifico, Ri.Ba. o altra, con conto aziendale predefinito selezionabile nella fattura. Dati bancari copiati nella bozza fattura e stampati, inclusi quelli del cliente per la Ri.Ba.
- IBAN verificato con checksum; il file interbancario Ri.Ba. non è ancora generato.

## v0.5.4 — 2026-09-21

- Modalità di pagamento con giorni base, opzione fine mese e giorni aggiuntivi: 15 settembre, fine mese +10 giorni propone il 10 ottobre.
- La scadenza proposta si aggiorna scegliendo fattura o modalità; la data della singola scadenza rimane modificabile. Le modalità esistenti mantengono le impostazioni precedenti.

## v0.5.3 — 2026-09-21

- Pulsante **Crea fattura (bozza)** visibile nel Registro fatture, con ricerca immediata dei DDT/SAL dello stesso cliente per mese, intervallo di date o tutto lo storico.
- Modalità di pagamento e scadenziario con filtri, importi aperti e scaduti, stampa, cambio rapido della data e registrazione del pagamento.
- Numeri automatici FT-AAAA-NNNNNN, DDT-AAAA-NNNNNN e SAL-AAAA-NNNNNN, separati per tipo e anno; non riutilizzati dopo archiviazioni.
- Blocco dell'archiviazione di articoli presenti in DDT o preventivi: la catena documentale non viene cancellata.

## v0.5.2 — 2026-09-21

- Nelle righe DDT il prezzo unitario lordo e lo sconto cliente percentuale sono distinti, visibili e modificabili in bozza.
- La scelta dell'articolo propone il prezzo del listino assegnato al cliente e la percentuale di sconto cliente; il totale riga e l'imponibile trasferito alla fattura applicano lo sconto.
- La migrazione 0007 aggiunge uno sconto 0% alle righe DDT già esistenti, conservando i totali e i DDT confermati.

## v0.5.1 — 2026-09-21

- Pulsanti per selezionare o deselezionare tutti i permessi nella scheda utente.
- Salvataggio utente con stato visibile vicino al pulsante, gestione degli errori anche nella lettura dei permessi e controllo esplicito della lunghezza password.
- Patch solo web: nessuna migrazione e nessuna modifica a database o credenziali.

## v0.5.0 — 2026-09-21

- Pannello Amministrazione con account modificabili/disattivabili/riattivabili, password indipendenti e diritti di consultazione/modifica per modulo controllati anche sul server.
- Anagrafica azienda e logo caricabile nel database; marchio G&T giallo e blu nell'intestazione e dati aziendali nelle stampe.
- Modalità di pagamento e scadenze modificabili collegate alle fatture registrate, con controllo che la somma delle scadenze non superi il totale.
- DDT con righe modificabili in bozza e conferma atomica che registra scarichi di magazzino; SAL parziali o completati.
- Registro fatture con importazione per cliente/mese di DDT confermati o importi SAL parziali; collegamenti antifatturazione doppia, calcolo imponibile/IVA e stampa di bozza con scadenze.
- Migrazione additiva 0006; nessuna modifica a `.env` o ai volumi esistenti.

## v0.4.0 — 2026-09-21

- Preventivi con intestazione, cliente, intervento, validità, termini, esclusioni, righe modificabili/eliminabili e stampa dell'offerta.
- Calcolo da modello GIMANI: tre sconti sequenziali sul prezzo di acquisto, ricarico, minuti posa, ore tecnico, costo trasferta per km e giornate, IVA per riga e sconto extra negativo.
- Inserimento da catalogo con prezzo netto del listino cliente e sconti del fornitore; prezzo manuale o calcolato, quantità decimali e prezzi unitari visualizzati a tre decimali.
- Stampa delle giacenze con filtri per magazzino, prodotto, ricerca, scorta minima e selezione di più righe.
- Migrazione 0005 additiva: nessuna modifica delle credenziali o dei dati di magazzino.

## v0.3.1 — 2026-09-21

- Schede di modifica raggruppate per anagrafica, prezzi e scorte.
- Ricerca rapida nelle anagrafiche, riepilogo articoli e prodotti sotto scorta.
- Giacenze con filtri per articolo e magazzino e comandi di carico, scarico e trasferimento.
- Scheda magazzino con materiali presenti e trasferimenti contestuali.
- Dettaglio articolo con informazioni principali e quantità in ciascun magazzino.

## v0.3.0 — 2026-09-21

- Scheda articoli con fornitore, codici, barcode, categoria, marca, prezzi, IVA, magazzino preferito, scorta minima e giacenza totale.
- Modifica/archiviazione protetta di articoli e magazzini, scelta leggibile delle unità, foto degli articoli e distinta base con controllo dei cicli.
- Listini e prezzo articolo per listino, sconto percentuale per cliente e calcolo del netto.
- Più sedi di consegna per clienti e fornitori, modificabili e archiviabili.
- Movimenti filtrabili per tutte le combinazioni dei campi disponibili e stampa del risultato filtrato.
- Interfaccia rivista con azioni visibili vicino ai record e carico iniziale registrato nello storico.
- Quantità con virgola o punto nei carichi e rientri; prezzi con almeno tre decimali.
- Tre sconti configurabili per fornitore, applicati in sequenza, con calcolo di anteprima.
- Reso a fornitore tracciato come movimento con origine, articolo, quantità, causale e fornitore.
- Riga generica di sconto extra con importo negativo prevista per il modulo preventivi su Excel.
- Struttura del preventivo da definire sul modello Excel dell'utente.

## v0.2.1 — 2026-09-21

- Eliminazione di unità personalizzate non utilizzate, riservata all'amministratore.
- Protezione delle unità predefinite e di quelle associate ad articoli; audit dell'eliminazione.

## v0.2.0 — 2026-09-21

- Login con password derivata PBKDF2, sessioni revocabili e ruoli base.
- Anagrafiche clienti e fornitori, modifiche e archiviazione con audit.
- Prima interfaccia web responsive con viste per articoli, unità, magazzini, giacenze e movimenti.
- Protezione delle API esistenti; l'autore dei movimenti deriva dalla sessione.

## v0.1.0 — 2026-09-21

- Prima migrazione PostgreSQL: unità, prodotti, magazzini, giacenze e movimenti immutabili.
- API locale per anagrafiche essenziali, movimenti, saldi e inversioni.
- Transazioni con blocco delle giacenze e controlli sulle quantità decimali.
- Docker Compose e test di dominio.

