# ERP Idraulici G&T — v1.0.0-rc4.8

Interfaccia web con login, permessi per modulo, anagrafiche, catalogo dettagliato, distinte base, listini, magazzino, preventivi, DDT, cantieri, SAL, fatture, note di credito e scadenziario. PostgreSQL conserva i dati. La RC4.8 unifica la ricerca di articoli e clienti nelle maschere documentali, completa il flusso delle note di credito, traduce gli stati e impedisce di riutilizzare un preventivo già fatturato. Mantiene la precisione numerica e le righe compatte introdotte nella RC4.7.1, oltre alle impostazioni commerciali, ai sette backup e ai PDF A4 professionali. L'XML FatturaPA resta una funzione da collaudare con il canale fiscale scelto prima dell'uso reale. Non pubblicare direttamente la porta su Internet: il collegamento HTTP locale non cifra la password.

## Avvio

Richiede Docker Compose. Copiare `.env.example` in `.env`; impostare `POSTGRES_PASSWORD`, riportare la stessa password nell'URL `DATABASE_URL` e scegliere `ADMIN_PASSWORD` di almeno 6 caratteri (consigliata una password lunga e unica). Se la password database contiene caratteri riservati negli URL (`@`, `:`, `/`, `#`, `%`), codificarli nell'URL. Avviare:

```sh
docker compose up --build -d
curl http://localhost:8000/health
```

Sul NAS stesso aprire `http://localhost:8000/` e accedere con `admin` e la password `ADMIN_PASSWORD`. Da un PC puoi usare un tunnel SSH: `ssh -L 8000:127.0.0.1:8000 utente@IP_DEL_NAS`, poi aprire `http://localhost:8000/` sul PC. La porta è legata a `127.0.0.1`; lasciare questa impostazione finché non ci sono HTTPS e protezioni di rete. Le migrazioni vengono applicate all'avvio; il volume `postgres_data` conserva i dati. `docker compose down` non elimina il volume; evitare `down -v` con dati importanti.

## Backup e ripristino

Da **Amministrazione → Backup del database aziendale** si può impostare un orario giornaliero Europe/Rome, creare un backup subito, scaricare file `.dump` e ripristinarne uno caricato. Il container deve essere acceso all'ora scelta: se è spento in quel momento il backup della giornata viene saltato. La cartella `backup/erp` del progetto conserva gli archivi grazie al volume in `docker-compose.override.yml`; il file `.gitkeep` tiene la cartella nel pacchetto. Il ripristino verifica il file su un database temporaneo, crea un backup preventivo, sostituisce il database aziendale e chiude le sessioni. Eseguirlo quando nessun utente lavora; scaricare regolarmente i backup su un dispositivo separato. Il backup include i dati salvati nel database, compreso il logo, ma **non** le configurazioni `.env` e `docker-compose.yml`. La gestione di database distinti per più aziende non è ancora disponibile; il selettore RC4 riguarda gli esercizi annuali della stessa azienda.

## Prova guidata

La schermata iniziale presenta quattro aree: Impostazioni, Anagrafiche, Magazzino e Documenti. Nella parte inferiore mostra ultime attività, operatore e sottoscorta. Per il primo movimento, crea due magazzini e un articolo; le unità predefinite sono già disponibili. Puoi anche usare `http://localhost:8000/docs` per le API. Carica 100 MT nel centrale, trasferisci 32,50 MT al cantiere, consuma 27,80 MT e restituisci 4,70 MT. La giacenza finale nel centrale è 72,20 MT.

## Sicurezza dei dati

Ogni variazione è una scrittura atomica di movimento e giacenze. I movimenti registrati sono immutabili; gli errori si compensano con un movimento inverso motivato. Il database impedisce giacenze negative e quantità non positive. La prima migrazione crea `schema_migrations`, il cui numero rimane registrato. Il comando `docker compose exec db pg_dump -U erp erp > backup.sql` produce un backup logico; verificarne il ripristino su un database separato prima dell'utilizzo reale. La pianificazione del backup giornaliero è disponibile in Amministrazione. Conservare sempre anche una copia esterna al NAS.

## Sviluppo

`pip install -r requirements.txt && pytest -q` esegue test di dominio, password e protezione delle API. I test PostgreSQL richiedono un'istanza reale: non sono inclusi nel controllo locale. Le regole e le milestone sono in `SPECIFICA.md`; ogni cambiamento di schema richiede un nuovo file numerato in `migrations/`. I checkpoint Git v0.1.0 e v0.2.0 sono inclusi nel bundle Git dello ZIP.




