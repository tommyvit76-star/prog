# ERP G&T v1.0.0-rc4.8 - aggiornamento NAS

La RC4.8 aggiorna le maschere documentali senza cancellare documenti, anagrafiche, impostazioni o registri. Non introduce nuove migrazioni: riusa lo schema RC4.7 già installato.

## 1. Backup prima dell'aggiornamento

```sh
cd /volume1/docker/erp-idraulici
mkdir -p backup
sudo docker-compose exec -T db pg_dump -U erp -Fc erp > backup/erp_prima_rc4_8.dump
ls -lh backup/erp_prima_rc4_8.dump
```

Il file deve avere dimensione maggiore di zero.

## 2. Copia e riavvio

1. Estrai `ERP_Idraulici_GT_v1.0.0-rc4.8.zip`.
2. Copia il contenuto estratto in `/volume1/docker/erp-idraulici`, sovrascrivendo i sorgenti.
3. Conserva `.env`, `docker-compose.yml`, la cartella `backup` e i volumi Docker.
4. Ricostruisci il servizio:

```sh
cd /volume1/docker/erp-idraulici
sudo docker-compose up -d --build api
sudo docker-compose ps
sudo docker-compose logs --tail=200 api
curl -i http://192.168.1.30:8000/health
```

Nel browser premi `Ctrl+F5`. L'intestazione deve mostrare `v1.0.0-rc4.8`.

## 3. Collaudo guidato dopo l'installazione

1. Apri un nuovo preventivo: cerca cliente per codice e nome, poi cerca un articolo digitandone le iniziali e con il binocolo.
2. Salva la bozza e verifica il ritorno all'elenco.
3. Crea un cantiere e associa il preventivo; crea DDT e SAL collegati.
4. Crea la fattura dal cliente, seleziona i documenti aperti e conferma; verifica il ritorno all'elenco e le scadenze.
5. Controlla che il preventivo fatturato non sia più proponibile in nuovi cantieri, DDT, SAL o fatture.
6. Crea una nota di credito dalla fattura confermata, salva e conferma.
7. Apri i PDF di preventivo, DDT, SAL, fattura e nota di credito; controlla dati cliente, pagamento, totali, logistica e stati in italiano.

## Ripristino

In caso di necessità, ricopia i sorgenti RC4.7.1, ricostruisci il servizio e, soltanto se necessario, ripristina `backup/erp_prima_rc4_8.dump` dalla funzione di ripristino dell'ERP. La RC4.8 non modifica lo schema e non elimina dati.
