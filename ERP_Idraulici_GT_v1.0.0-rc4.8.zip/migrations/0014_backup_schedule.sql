CREATE TABLE IF NOT EXISTS backup_schedule (
    id integer PRIMARY KEY CHECK (id = 1),
    enabled boolean NOT NULL DEFAULT false,
    backup_time time NOT NULL DEFAULT '02:00',
    timezone text NOT NULL DEFAULT 'Europe/Rome',
    last_success_day date,
    last_success_at timestamptz,
    last_error text
);
INSERT INTO backup_schedule(id) VALUES (1) ON CONFLICT DO NOTHING;
