-- One-time clean start explicitly requested for the RC4.6.1 test cycle.
-- Master data, users, company settings and configuration are preserved.
TRUNCATE TABLE
 customer_credits,
 credit_note_lines,
 credit_notes,
 payment_due,
 invoice_references,
 invoice_sources,
 invoice_lines,
 invoice_register,
 delivery_lines,
 delivery_notes,
 progress_certificates,
 project_quote_links,
 project_sites,
 quote_lines,
 quotes,
 balances,
 movements,
 document_sequences,
 audit_events
RESTART IDENTITY;
