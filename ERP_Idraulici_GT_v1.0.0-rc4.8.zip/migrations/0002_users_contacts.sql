CREATE TABLE users (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  username varchar(80) NOT NULL UNIQUE,
  password_hash text NOT NULL,
  role varchar(16) NOT NULL CHECK (role IN ('ADMIN','OFFICE','WAREHOUSE','TECHNICIAN')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE sessions (
  token_hash char(64) PRIMARY KEY,
  user_id bigint NOT NULL REFERENCES users(id),
  expires_at timestamptz NOT NULL
);
CREATE INDEX sessions_user_idx ON sessions(user_id);
CREATE TABLE customers (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name text NOT NULL CHECK (length(trim(name)) > 0),
  person_type varchar(10) NOT NULL DEFAULT 'COMPANY' CHECK (person_type IN ('PERSON','COMPANY')),
  address text NOT NULL DEFAULT '',
  postal_code varchar(12) NOT NULL DEFAULT '',
  city text NOT NULL DEFAULT '',
  province varchar(4) NOT NULL DEFAULT '',
  tax_code varchar(24) NOT NULL DEFAULT '',
  vat_number varchar(24) NOT NULL DEFAULT '',
  sdi_code varchar(12) NOT NULL DEFAULT '',
  pec text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  mobile text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  contact_name text NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT '',
  active boolean NOT NULL DEFAULT true
);
CREATE INDEX customers_name_idx ON customers(name);
CREATE TABLE suppliers (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name text NOT NULL CHECK (length(trim(name)) > 0),
  vat_number varchar(24) NOT NULL DEFAULT '',
  address text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  contact_name text NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT '',
  active boolean NOT NULL DEFAULT true
);
CREATE INDEX suppliers_name_idx ON suppliers(name);
CREATE TABLE audit_events (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now(),
  user_id bigint REFERENCES users(id),
  action text NOT NULL,
  entity text NOT NULL,
  entity_id bigint NOT NULL,
  details jsonb NOT NULL DEFAULT '{}'::jsonb
);
