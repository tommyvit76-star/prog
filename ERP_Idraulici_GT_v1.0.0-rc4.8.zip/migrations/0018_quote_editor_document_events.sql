ALTER TABLE quotes
  ADD COLUMN IF NOT EXISTS manual_labor_cost numeric(15,4) NOT NULL DEFAULT 0 CHECK(manual_labor_cost >= 0);

ALTER TABLE quote_lines
  ADD COLUMN IF NOT EXISTS pricing_mode text NOT NULL DEFAULT 'COST'
    CHECK(pricing_mode IN ('COST','LIST','MANUAL')),
  ADD COLUMN IF NOT EXISTS sale_discount_1 numeric(5,2) NOT NULL DEFAULT 0 CHECK(sale_discount_1 BETWEEN 0 AND 100),
  ADD COLUMN IF NOT EXISTS sale_discount_2 numeric(5,2) NOT NULL DEFAULT 0 CHECK(sale_discount_2 BETWEEN 0 AND 100),
  ADD COLUMN IF NOT EXISTS sale_discount_3 numeric(5,2) NOT NULL DEFAULT 0 CHECK(sale_discount_3 BETWEEN 0 AND 100);

UPDATE quote_lines SET pricing_mode='MANUAL' WHERE unit_price>0 AND pricing_mode='COST';

CREATE INDEX IF NOT EXISTS audit_events_documents_idx
  ON audit_events(created_at DESC, entity, action);
