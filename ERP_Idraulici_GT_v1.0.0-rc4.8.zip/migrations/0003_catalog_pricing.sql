ALTER TABLE products
  ADD COLUMN supplier_id bigint REFERENCES suppliers(id),
  ADD COLUMN supplier_code text NOT NULL DEFAULT '',
  ADD COLUMN barcode text NOT NULL DEFAULT '',
  ADD COLUMN category text NOT NULL DEFAULT '',
  ADD COLUMN brand text NOT NULL DEFAULT '',
  ADD COLUMN location text NOT NULL DEFAULT '',
  ADD COLUMN notes text NOT NULL DEFAULT '',
  ADD COLUMN purchase_price numeric(15,4) NOT NULL DEFAULT 0 CHECK (purchase_price >= 0),
  ADD COLUMN list_price numeric(15,4) NOT NULL DEFAULT 0 CHECK (list_price >= 0),
  ADD COLUMN vat_rate numeric(5,2) NOT NULL DEFAULT 22 CHECK (vat_rate >= 0 AND vat_rate <= 100),
  ADD COLUMN default_warehouse_id bigint REFERENCES warehouses(id),
  ADD COLUMN kind varchar(8) NOT NULL DEFAULT 'SIMPLE' CHECK (kind IN ('SIMPLE','KIT'));
ALTER TABLE warehouses ADD COLUMN active boolean NOT NULL DEFAULT true;
CREATE TABLE product_photos (
  product_id bigint PRIMARY KEY REFERENCES products(id) ON DELETE CASCADE,
  mime_type varchar(16) NOT NULL CHECK (mime_type IN ('image/jpeg','image/png','image/webp')),
  data bytea NOT NULL CHECK (octet_length(data) <= 2097152)
);
CREATE TABLE bom_lines (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  parent_id bigint NOT NULL REFERENCES products(id),
  component_id bigint NOT NULL REFERENCES products(id),
  quantity numeric(15,4) NOT NULL CHECK (quantity > 0),
  UNIQUE(parent_id,component_id), CHECK (parent_id <> component_id)
);
CREATE INDEX bom_component_idx ON bom_lines(component_id);
CREATE TABLE price_lists (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  code varchar(32) NOT NULL UNIQUE,
  name text NOT NULL,
  active boolean NOT NULL DEFAULT true
);
INSERT INTO price_lists(code,name) VALUES ('BASE','Listino base');
CREATE TABLE product_list_prices (
  product_id bigint NOT NULL REFERENCES products(id),
  price_list_id bigint NOT NULL REFERENCES price_lists(id),
  price numeric(15,4) NOT NULL CHECK (price >= 0),
  PRIMARY KEY(product_id,price_list_id)
);
ALTER TABLE customers ADD COLUMN price_list_id bigint REFERENCES price_lists(id);
ALTER TABLE customers ADD COLUMN discount_percent numeric(5,2) NOT NULL DEFAULT 0 CHECK (discount_percent >= 0 AND discount_percent <= 100);
UPDATE customers SET price_list_id=(SELECT id FROM price_lists WHERE code='BASE');
ALTER TABLE customers ALTER COLUMN price_list_id SET NOT NULL;
CREATE TABLE customer_addresses (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  customer_id bigint NOT NULL REFERENCES customers(id),
  label text NOT NULL,
  address text NOT NULL,
  postal_code varchar(12) NOT NULL DEFAULT '',
  city text NOT NULL DEFAULT '',
  province varchar(4) NOT NULL DEFAULT '',
  contact_name text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  active boolean NOT NULL DEFAULT true
);
CREATE INDEX customer_addresses_owner_idx ON customer_addresses(customer_id);
CREATE TABLE supplier_addresses (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  supplier_id bigint NOT NULL REFERENCES suppliers(id),
  label text NOT NULL,
  address text NOT NULL,
  postal_code varchar(12) NOT NULL DEFAULT '',
  city text NOT NULL DEFAULT '',
  province varchar(4) NOT NULL DEFAULT '',
  contact_name text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  active boolean NOT NULL DEFAULT true
);
CREATE INDEX supplier_addresses_owner_idx ON supplier_addresses(supplier_id);
