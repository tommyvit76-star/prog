ALTER TABLE document_sequences DROP CONSTRAINT document_sequences_document_type_check;
ALTER TABLE document_sequences ADD CONSTRAINT document_sequences_document_type_check
 CHECK(document_type IN ('FT','DDT','SAL','PRE'));
ALTER TABLE quotes ADD COLUMN number text;
UPDATE quotes SET number='PRE-'||extract(year FROM issue_date)::integer||'-'||lpad(id::text,greatest(6,length(id::text)),'0');
ALTER TABLE quotes ALTER COLUMN number SET NOT NULL;
CREATE UNIQUE INDEX quotes_number_unique ON quotes(number);
INSERT INTO document_sequences(document_type,document_year,last_number)
 SELECT 'PRE',extract(year FROM issue_date)::integer,max(id) FROM quotes GROUP BY extract(year FROM issue_date)::integer
 ON CONFLICT(document_type,document_year) DO UPDATE SET last_number=greatest(document_sequences.last_number,EXCLUDED.last_number);
