ALTER TABLE invoice_register ADD COLUMN document_status text NOT NULL DEFAULT 'DRAFT'
 CHECK(document_status IN ('DRAFT','CONFIRMED'));
ALTER TABLE invoice_register ADD COLUMN invoice_kind text NOT NULL DEFAULT 'SUMMARY'
 CHECK(invoice_kind IN ('IMMEDIATE','SUMMARY','MIXED'));
ALTER TABLE invoice_register ADD COLUMN fiscal_document_type varchar(4) NOT NULL DEFAULT 'TD01'
 CHECK(fiscal_document_type IN ('TD01','TD24'));
ALTER TABLE invoice_register ADD COLUMN company_snapshot jsonb;
ALTER TABLE invoice_register ADD COLUMN customer_snapshot jsonb;
ALTER TABLE invoice_register ADD COLUMN logo_snapshot bytea;
ALTER TABLE company_settings ADD COLUMN fiscal_regime varchar(8) NOT NULL DEFAULT '';
ALTER TABLE company_settings ADD COLUMN tax_code varchar(16) NOT NULL DEFAULT '';
ALTER TABLE company_settings ADD COLUMN country varchar(2) NOT NULL DEFAULT 'IT';

CREATE TABLE invoice_lines (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 invoice_id bigint NOT NULL REFERENCES invoice_register(id),
 position integer NOT NULL DEFAULT 0,
 kind varchar(12) NOT NULL CHECK(kind IN ('PRODUCT','SERVICE','DISCOUNT')),
 product_id bigint REFERENCES products(id),
 warehouse_id bigint REFERENCES warehouses(id),
 movement_id bigint UNIQUE REFERENCES movements(id),
 code text NOT NULL DEFAULT '',
 description text NOT NULL CHECK(length(trim(description))>0),
 duplicate_reason text NOT NULL DEFAULT '',
 unit_code text NOT NULL DEFAULT 'PZ',
 quantity numeric(15,4) NOT NULL CHECK(quantity>0),
 unit_price numeric(15,4) NOT NULL CHECK(unit_price>=0),
 discount_percent numeric(5,2) NOT NULL DEFAULT 0 CHECK(discount_percent BETWEEN 0 AND 100),
 discount_amount numeric(15,2) NOT NULL DEFAULT 0 CHECK(discount_amount>=0),
 vat_rate numeric(5,2) NOT NULL CHECK(vat_rate BETWEEN 0 AND 100),
 vat_nature varchar(4) NOT NULL DEFAULT '',
 taxable numeric(15,2) NOT NULL,
 vat_amount numeric(15,2) NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(),
 CHECK ((vat_rate=0 AND vat_nature<>'') OR (vat_rate>0 AND vat_nature='')),
 CHECK ((kind='DISCOUNT' AND taxable<0) OR (kind<>'DISCOUNT' AND taxable>=0))
);
CREATE INDEX invoice_lines_invoice_position ON invoice_lines(invoice_id,position,id);

CREATE TABLE payment_method_installments (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 payment_method_id bigint NOT NULL REFERENCES payment_methods(id),
 position integer NOT NULL CHECK(position>0),
 percent numeric(5,2) NOT NULL CHECK(percent>0 AND percent<=100),
 base_days integer NOT NULL DEFAULT 0 CHECK(base_days BETWEEN 0 AND 3650),
 end_of_month boolean NOT NULL DEFAULT false,
 extra_days integer NOT NULL DEFAULT 0 CHECK(extra_days BETWEEN 0 AND 3650),
 UNIQUE(payment_method_id,position)
);
ALTER TABLE payment_due ADD COLUMN generated boolean NOT NULL DEFAULT false;
ALTER TABLE payment_due ADD COLUMN date_overridden boolean NOT NULL DEFAULT false;
