-- RC4.4: multiple quote links for projects and optional document descriptions.
CREATE TABLE project_quote_links (
 project_id bigint NOT NULL REFERENCES project_sites(id) ON DELETE CASCADE,
 quote_id bigint NOT NULL REFERENCES quotes(id),
 created_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(project_id,quote_id)
);
INSERT INTO project_quote_links(project_id,quote_id)
 SELECT id,quote_id FROM project_sites WHERE quote_id IS NOT NULL
 ON CONFLICT DO NOTHING;

ALTER TABLE invoice_lines DROP CONSTRAINT IF EXISTS invoice_lines_description_check;
