CREATE TABLE user_modules (
 user_id bigint NOT NULL REFERENCES users(id),
 module text NOT NULL CHECK(module IN ('customers','suppliers','units','products','warehouses','balances','movements','reports','price-lists','quotes','payments','jobs','sal','ddt','invoices')),
 can_view boolean NOT NULL DEFAULT false,
 can_edit boolean NOT NULL DEFAULT false,
 PRIMARY KEY(user_id,module)
);
INSERT INTO user_modules(user_id,module,can_view,can_edit)
SELECT u.id,m.module,true,m.can_edit FROM users u CROSS JOIN LATERAL (
 SELECT 'customers' AS module,true AS can_edit WHERE u.role='OFFICE' UNION ALL
 SELECT 'suppliers',true WHERE u.role='OFFICE' UNION ALL
 SELECT 'price-lists',true WHERE u.role='OFFICE' UNION ALL
 SELECT 'quotes',true WHERE u.role='OFFICE' UNION ALL
 SELECT 'products',true WHERE u.role IN ('OFFICE','WAREHOUSE') UNION ALL
 SELECT 'products',false WHERE u.role='TECHNICIAN' UNION ALL
 SELECT 'units',false WHERE u.role IN ('OFFICE','WAREHOUSE','TECHNICIAN') UNION ALL
 SELECT 'warehouses',true WHERE u.role='WAREHOUSE' UNION ALL
 SELECT 'warehouses',false WHERE u.role='TECHNICIAN' UNION ALL
 SELECT 'balances',false WHERE u.role IN ('OFFICE','WAREHOUSE','TECHNICIAN') UNION ALL
 SELECT 'movements',true WHERE u.role='WAREHOUSE' UNION ALL
 SELECT 'movements',false WHERE u.role='OFFICE' UNION ALL
 SELECT 'reports',false WHERE u.role IN ('OFFICE','WAREHOUSE')
) m WHERE u.role<>'ADMIN';
INSERT INTO user_modules(user_id,module,can_view,can_edit)
SELECT id,'payments',true,true FROM users WHERE role='OFFICE';
CREATE TABLE company_settings (
 id integer PRIMARY KEY DEFAULT 1 CHECK(id=1),
 name text NOT NULL DEFAULT 'La tua azienda',
 vat_number text NOT NULL DEFAULT '', address text NOT NULL DEFAULT '',
 postal_code text NOT NULL DEFAULT '',city text NOT NULL DEFAULT '',province text NOT NULL DEFAULT '',
 phone text NOT NULL DEFAULT '', email text NOT NULL DEFAULT '',
 logo_mime varchar(16) CHECK(logo_mime IN ('image/png','image/jpeg','image/webp')),
 logo_data bytea CHECK(logo_data IS NULL OR octet_length(logo_data)<=2097152),
 updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO company_settings(id,name) VALUES (1,'La tua azienda');
CREATE TABLE payment_methods (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 name text NOT NULL UNIQUE,
 description text NOT NULL DEFAULT '',
 default_days integer NOT NULL DEFAULT 0 CHECK(default_days BETWEEN 0 AND 3650),
 active boolean NOT NULL DEFAULT true
);
CREATE TABLE invoice_register (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 customer_id bigint NOT NULL REFERENCES customers(id),
 customer_name text NOT NULL,
 number text NOT NULL,
 issue_date date NOT NULL,
 taxable numeric(15,2) NOT NULL DEFAULT 0 CHECK(taxable>=0),
 vat_amount numeric(15,2) NOT NULL DEFAULT 0 CHECK(vat_amount>=0),
 total numeric(15,2) NOT NULL CHECK(total>=0),
 payment_method_id bigint REFERENCES payment_methods(id),
 quote_id bigint REFERENCES quotes(id),
 status text NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','PAID','CANCELLED')),
 notes text NOT NULL DEFAULT '',
 active boolean NOT NULL DEFAULT true,
 UNIQUE(number,issue_date)
);
CREATE TABLE delivery_notes (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 customer_id bigint NOT NULL REFERENCES customers(id), customer_name text NOT NULL,
 number text NOT NULL, issued_on date NOT NULL,
 warehouse_id bigint NOT NULL REFERENCES warehouses(id),
 shipping_address text NOT NULL DEFAULT '', status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','CONFIRMED')),
 notes text NOT NULL DEFAULT '', active boolean NOT NULL DEFAULT true,
 UNIQUE(number,issued_on)
);
CREATE TABLE delivery_lines (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 delivery_id bigint NOT NULL REFERENCES delivery_notes(id),
 product_id bigint NOT NULL REFERENCES products(id), product_code text NOT NULL,
 description text NOT NULL, unit_code text NOT NULL,
 quantity numeric(15,4) NOT NULL CHECK(quantity>0),
 unit_price numeric(15,4) NOT NULL CHECK(unit_price>=0),
 vat_rate numeric(5,2) NOT NULL CHECK(vat_rate BETWEEN 0 AND 100),
 movement_id bigint UNIQUE REFERENCES movements(id)
);
CREATE TABLE progress_certificates (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 customer_id bigint NOT NULL REFERENCES customers(id),customer_name text NOT NULL,
 quote_id bigint REFERENCES quotes(id),number text NOT NULL,issued_on date NOT NULL,
 description text NOT NULL,percent numeric(5,2) NOT NULL CHECK(percent>0 AND percent<=100),
 amount numeric(15,2) NOT NULL CHECK(amount>0),vat_rate numeric(5,2) NOT NULL DEFAULT 22 CHECK(vat_rate BETWEEN 0 AND 100),
 status text NOT NULL DEFAULT 'PARTIAL' CHECK(status IN ('PARTIAL','COMPLETED')),
 notes text NOT NULL DEFAULT '',active boolean NOT NULL DEFAULT true,
 UNIQUE(number,issued_on)
);
CREATE TABLE invoice_sources (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 invoice_id bigint NOT NULL REFERENCES invoice_register(id),
 delivery_id bigint REFERENCES delivery_notes(id),sal_id bigint REFERENCES progress_certificates(id),
 taxable numeric(15,2) NOT NULL CHECK(taxable>0),vat_amount numeric(15,2) NOT NULL CHECK(vat_amount>=0),
 CHECK ((delivery_id IS NULL) <> (sal_id IS NULL)),
 UNIQUE(invoice_id,delivery_id),UNIQUE(invoice_id,sal_id)
);
CREATE UNIQUE INDEX invoice_delivery_once ON invoice_sources(delivery_id) WHERE delivery_id IS NOT NULL;
CREATE TABLE payment_due (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 invoice_id bigint NOT NULL REFERENCES invoice_register(id),
 payment_method_id bigint REFERENCES payment_methods(id),
 due_date date NOT NULL,
 amount numeric(15,2) NOT NULL CHECK(amount>0),
 status text NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','PAID','CANCELLED')),
 paid_at date,
 notes text NOT NULL DEFAULT '',
 active boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX payment_due_invoice_idx ON payment_due(invoice_id,due_date);
ALTER TABLE quotes ADD COLUMN payment_method_id bigint REFERENCES payment_methods(id);
INSERT INTO user_modules(user_id,module,can_view,can_edit)
SELECT id,'invoices',true,true FROM users WHERE role='OFFICE';
INSERT INTO user_modules(user_id,module,can_view,can_edit)
SELECT u.id,m.module,true,true FROM users u CROSS JOIN (VALUES ('ddt'),('sal')) AS m(module) WHERE u.role='OFFICE';
