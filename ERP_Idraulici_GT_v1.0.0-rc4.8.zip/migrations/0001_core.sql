CREATE TABLE units (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  code varchar(12) NOT NULL UNIQUE,
  description text NOT NULL
);
INSERT INTO units(code, description) VALUES
 ('PZ','Pezzi'),('MT','Metri'),('KG','Chilogrammi'),('LT','Litri'),
 ('MQ','Metri quadrati'),('MC','Metri cubi'),('CF','Confezioni'),('ROT','Rotoli');
CREATE TABLE products (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  code varchar(64) NOT NULL UNIQUE,
  description text NOT NULL,
  unit_id bigint NOT NULL REFERENCES units(id),
  active boolean NOT NULL DEFAULT true,
  min_stock numeric(15,4) NOT NULL DEFAULT 0 CHECK (min_stock >= 0)
);
CREATE TABLE warehouses (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  code varchar(64) NOT NULL UNIQUE,
  name text NOT NULL,
  kind varchar(16) NOT NULL CHECK (kind IN ('CENTRAL','VAN','JOB','OTHER'))
);
CREATE TABLE balances (
  product_id bigint NOT NULL REFERENCES products(id),
  warehouse_id bigint NOT NULL REFERENCES warehouses(id),
  quantity numeric(15,4) NOT NULL DEFAULT 0 CHECK (quantity >= 0),
  PRIMARY KEY (product_id, warehouse_id)
);
CREATE TABLE movements (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now(),
  product_id bigint NOT NULL REFERENCES products(id),
  source_id bigint REFERENCES warehouses(id),
  destination_id bigint REFERENCES warehouses(id),
  quantity numeric(15,4) NOT NULL CHECK (quantity > 0),
  kind varchar(16) NOT NULL CHECK (kind IN ('LOAD','TRANSFER','CONSUME','RETURN','ADJUST','REVERSAL')),
  actor text NOT NULL CHECK (length(trim(actor)) > 0),
  reason text NOT NULL CHECK (length(trim(reason)) > 0),
  reverses_id bigint UNIQUE REFERENCES movements(id),
  CHECK (source_id IS NOT NULL OR destination_id IS NOT NULL),
  CHECK (source_id IS DISTINCT FROM destination_id)
);
CREATE INDEX movements_product_time_idx ON movements(product_id, created_at DESC);
CREATE INDEX movements_source_idx ON movements(source_id);
CREATE INDEX movements_destination_idx ON movements(destination_id);
CREATE FUNCTION forbid_movement_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'movements are immutable; create a reversal'; END $$;
CREATE TRIGGER movements_immutable BEFORE UPDATE OR DELETE ON movements
FOR EACH ROW EXECUTE FUNCTION forbid_movement_change();
