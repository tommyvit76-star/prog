ALTER TABLE delivery_notes
 ADD COLUMN quote_id bigint REFERENCES quotes(id);

ALTER TABLE delivery_lines
 ALTER COLUMN product_id DROP NOT NULL,
 ADD COLUMN quote_line_id bigint REFERENCES quote_lines(id),
 ADD COLUMN kind text NOT NULL DEFAULT 'PRODUCT' CHECK(kind IN ('PRODUCT','SERVICE','TRAVEL','DISCOUNT')),
 ADD COLUMN calculation_mode text NOT NULL DEFAULT 'MANUAL' CHECK(calculation_mode IN ('MANUAL','LABOR','TRAVEL')),
 ADD COLUMN work_minutes numeric(15,2) NOT NULL DEFAULT 0 CHECK(work_minutes>=0),
 ADD COLUMN workers integer NOT NULL DEFAULT 1 CHECK(workers>0 AND workers<=1000),
 ADD COLUMN hourly_rate numeric(15,4) NOT NULL DEFAULT 0 CHECK(hourly_rate>=0),
 ADD COLUMN kilometers numeric(15,3) NOT NULL DEFAULT 0 CHECK(kilometers>=0),
 ADD COLUMN kilometer_rate numeric(15,4) NOT NULL DEFAULT 0 CHECK(kilometer_rate>=0);

CREATE INDEX delivery_notes_quote_idx ON delivery_notes(quote_id,id);
CREATE INDEX delivery_lines_quote_line_idx ON delivery_lines(quote_line_id,id);
