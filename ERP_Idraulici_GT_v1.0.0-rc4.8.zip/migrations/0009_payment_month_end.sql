ALTER TABLE payment_methods
 ADD COLUMN end_of_month boolean NOT NULL DEFAULT false,
 ADD COLUMN extra_days integer NOT NULL DEFAULT 0 CHECK(extra_days BETWEEN 0 AND 3650);
