CREATE TABLE quotes (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 customer_id bigint NOT NULL REFERENCES customers(id),
 customer_name text NOT NULL, customer_address text NOT NULL DEFAULT '',
 customer_city text NOT NULL DEFAULT '', customer_vat text NOT NULL DEFAULT '',
 title text NOT NULL DEFAULT '', intervention text NOT NULL DEFAULT '',
 issue_date date NOT NULL DEFAULT current_date, valid_days integer NOT NULL DEFAULT 10 CHECK(valid_days BETWEEN 0 AND 3650),
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','SENT','ACCEPTED','REJECTED')),
 introduction text NOT NULL DEFAULT '', exclusions text NOT NULL DEFAULT '', payment_terms text NOT NULL DEFAULT '',
 labor_rate numeric(15,4) NOT NULL DEFAULT 32 CHECK(labor_rate>=0),
 technician_rate numeric(15,4) NOT NULL DEFAULT 40 CHECK(technician_rate>=0),
 kilometers numeric(15,4) NOT NULL DEFAULT 0 CHECK(kilometers>=0),
 kilometer_rate numeric(15,4) NOT NULL DEFAULT 0.68 CHECK(kilometer_rate>=0),
 working_days numeric(15,4) NOT NULL DEFAULT 1 CHECK(working_days>0),
 notes text NOT NULL DEFAULT '', active boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX quotes_customer_idx ON quotes(customer_id);
CREATE TABLE quote_lines (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 quote_id bigint NOT NULL REFERENCES quotes(id), position integer NOT NULL DEFAULT 0,
 product_id bigint REFERENCES products(id), code text NOT NULL DEFAULT '',
 description text NOT NULL, unit_code text NOT NULL DEFAULT 'PZ',
 quantity numeric(15,4) NOT NULL CHECK(quantity>0),
 purchase_gross numeric(15,4) NOT NULL DEFAULT 0 CHECK(purchase_gross>=0),
 discount_1 numeric(5,2) NOT NULL DEFAULT 0 CHECK(discount_1 BETWEEN 0 AND 100),
 discount_2 numeric(5,2) NOT NULL DEFAULT 0 CHECK(discount_2 BETWEEN 0 AND 100),
 discount_3 numeric(5,2) NOT NULL DEFAULT 0 CHECK(discount_3 BETWEEN 0 AND 100),
 markup_percent numeric(7,2) NOT NULL DEFAULT 0 CHECK(markup_percent BETWEEN 0 AND 1000),
 labor_minutes numeric(15,4) NOT NULL DEFAULT 0 CHECK(labor_minutes>=0),
 technician_hours numeric(15,4) NOT NULL DEFAULT 0 CHECK(technician_hours>=0),
 unit_price numeric(15,4) NOT NULL DEFAULT 0 CHECK(unit_price>=0),
 fixed_adjustment numeric(15,4) NOT NULL DEFAULT 0,
 vat_rate numeric(5,2) NOT NULL DEFAULT 22 CHECK(vat_rate BETWEEN 0 AND 100),
 kind text NOT NULL DEFAULT 'MATERIAL' CHECK(kind IN ('MATERIAL','SERVICE','DISCOUNT')),
 notes text NOT NULL DEFAULT ''
);
CREATE INDEX quote_lines_quote_idx ON quote_lines(quote_id,position,id);
