ALTER TABLE delivery_lines
 ADD COLUMN discount_percent numeric(5,2) NOT NULL DEFAULT 0
 CHECK(discount_percent BETWEEN 0 AND 100);
