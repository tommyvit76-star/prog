ALTER TABLE document_sequences DROP CONSTRAINT IF EXISTS document_sequences_document_type_check;
ALTER TABLE document_sequences ADD CONSTRAINT document_sequences_document_type_check
 CHECK(document_type IN ('FT','DDT','SAL','PRE','NC'));

CREATE TABLE transport_reasons (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 name text NOT NULL UNIQUE, invoiceable boolean NOT NULL DEFAULT false,
 stock_action text NOT NULL DEFAULT 'NONE' CHECK(stock_action IN ('NONE','CONSUME','LOAD')),
 requires_return boolean NOT NULL DEFAULT false, active boolean NOT NULL DEFAULT true
);
CREATE TABLE goods_appearances (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,name text NOT NULL UNIQUE,active boolean NOT NULL DEFAULT true
);
CREATE TABLE port_terms (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,name text NOT NULL UNIQUE,active boolean NOT NULL DEFAULT true
);
CREATE TABLE transport_modes (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,name text NOT NULL UNIQUE,active boolean NOT NULL DEFAULT true
);
CREATE TABLE carriers (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,name text NOT NULL,vat_number text NOT NULL DEFAULT '',
 address text NOT NULL DEFAULT '',postal_code text NOT NULL DEFAULT '',city text NOT NULL DEFAULT '',province text NOT NULL DEFAULT '',
 driver_name text NOT NULL DEFAULT '',vehicle_plate text NOT NULL DEFAULT '',active boolean NOT NULL DEFAULT true
);
INSERT INTO transport_reasons(name,invoiceable,stock_action,requires_return) VALUES
 ('Vendita',true,'CONSUME',false),('Reso',false,'LOAD',false),('Conto lavorazione',false,'CONSUME',true),
 ('Omaggio',false,'CONSUME',false),('Visione / prova',false,'CONSUME',true)
 ON CONFLICT(name) DO NOTHING;
INSERT INTO goods_appearances(name) VALUES ('A vista'),('Scatole'),('Pallet'),('Colli') ON CONFLICT(name) DO NOTHING;
INSERT INTO port_terms(name) VALUES ('Franco'),('Assegnato') ON CONFLICT(name) DO NOTHING;
INSERT INTO transport_modes(name) VALUES ('Mittente'),('Destinatario'),('Vettore') ON CONFLICT(name) DO NOTHING;

CREATE TABLE project_sites (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,code text NOT NULL UNIQUE,name text NOT NULL,
 customer_id bigint NOT NULL REFERENCES customers(id),customer_name text NOT NULL,address text NOT NULL DEFAULT '',
 quote_id bigint REFERENCES quotes(id),contract_value numeric(15,2) NOT NULL DEFAULT 0 CHECK(contract_value>=0),
 variation_value numeric(15,2) NOT NULL DEFAULT 0,manager text NOT NULL DEFAULT '',
 planned_start date,actual_start date,planned_end date,actual_end date,
 status text NOT NULL DEFAULT 'PLANNED' CHECK(status IN ('PLANNED','OPEN','SUSPENDED','COMPLETED','INVOICED','CLOSED')),
 technical_notes text NOT NULL DEFAULT '',administrative_notes text NOT NULL DEFAULT '',active boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX project_sites_customer_idx ON project_sites(customer_id,status);

ALTER TABLE delivery_notes
 ADD COLUMN project_id bigint REFERENCES project_sites(id),
 ADD COLUMN transport_reason_id bigint REFERENCES transport_reasons(id),
 ADD COLUMN goods_appearance_id bigint REFERENCES goods_appearances(id),
 ADD COLUMN port_term_id bigint REFERENCES port_terms(id),
 ADD COLUMN transport_mode_id bigint REFERENCES transport_modes(id),
 ADD COLUMN carrier_id bigint REFERENCES carriers(id),
 ADD COLUMN transport_date date,
 ADD COLUMN transport_time time,
 ADD COLUMN package_count integer NOT NULL DEFAULT 0 CHECK(package_count>=0),
 ADD COLUMN gross_weight numeric(15,3) NOT NULL DEFAULT 0 CHECK(gross_weight>=0),
 ADD COLUMN net_weight numeric(15,3) NOT NULL DEFAULT 0 CHECK(net_weight>=0),
 ADD COLUMN weight_unit text NOT NULL DEFAULT 'kg',
 ADD COLUMN transport_snapshot jsonb,
 ADD COLUMN return_due_date date;

ALTER TABLE progress_certificates
 ADD COLUMN project_id bigint REFERENCES project_sites(id),
 ADD COLUMN sequence_no integer NOT NULL DEFAULT 1 CHECK(sequence_no>0),
 ADD COLUMN period_from date,
 ADD COLUMN period_to date,
 ADD COLUMN approval_status text NOT NULL DEFAULT 'DRAFT' CHECK(approval_status IN ('DRAFT','ISSUED','APPROVED','DISPUTED','INVOICED')),
 ADD COLUMN retention_amount numeric(15,2) NOT NULL DEFAULT 0 CHECK(retention_amount>=0),
 ADD COLUMN advance_recovery numeric(15,2) NOT NULL DEFAULT 0 CHECK(advance_recovery>=0),
 ADD COLUMN variation_amount numeric(15,2) NOT NULL DEFAULT 0,
 ADD COLUMN approved_on date;
CREATE INDEX progress_certificates_project_idx ON progress_certificates(project_id,sequence_no);

ALTER TABLE invoice_register ADD COLUMN project_id bigint REFERENCES project_sites(id);

CREATE TABLE credit_notes (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 original_invoice_id bigint NOT NULL REFERENCES invoice_register(id),customer_id bigint NOT NULL REFERENCES customers(id),
 customer_name text NOT NULL,number text NOT NULL,issue_date date NOT NULL,cause text NOT NULL,
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','CONFIRMED')),
 taxable numeric(15,2) NOT NULL DEFAULT 0 CHECK(taxable>=0),vat_amount numeric(15,2) NOT NULL DEFAULT 0 CHECK(vat_amount>=0),
 total numeric(15,2) NOT NULL DEFAULT 0 CHECK(total>=0),company_snapshot jsonb,customer_snapshot jsonb,logo_snapshot bytea,
 notes text NOT NULL DEFAULT '',active boolean NOT NULL DEFAULT true,created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(number,issue_date)
);
CREATE TABLE credit_note_lines (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,credit_note_id bigint NOT NULL REFERENCES credit_notes(id),
 original_invoice_line_id bigint REFERENCES invoice_lines(id),position integer NOT NULL DEFAULT 0,
 kind varchar(12) NOT NULL DEFAULT 'PRODUCT' CHECK(kind IN ('PRODUCT','SERVICE','DISCOUNT')),
 product_id bigint REFERENCES products(id),warehouse_id bigint REFERENCES warehouses(id),movement_id bigint UNIQUE REFERENCES movements(id),
 restock boolean NOT NULL DEFAULT false,code text NOT NULL DEFAULT '',description text NOT NULL,unit_code text NOT NULL DEFAULT 'PZ',
 quantity numeric(15,4) NOT NULL CHECK(quantity>0),unit_price numeric(15,4) NOT NULL CHECK(unit_price>=0),
 discount_percent numeric(5,2) NOT NULL DEFAULT 0 CHECK(discount_percent BETWEEN 0 AND 100),
 vat_rate numeric(5,2) NOT NULL CHECK(vat_rate BETWEEN 0 AND 100),vat_nature varchar(4) NOT NULL DEFAULT '',
 taxable numeric(15,2) NOT NULL,vat_amount numeric(15,2) NOT NULL
);
CREATE INDEX credit_notes_invoice_idx ON credit_notes(original_invoice_id,status);
CREATE INDEX credit_note_lines_note_idx ON credit_note_lines(credit_note_id,position,id);
CREATE TABLE customer_credits (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,customer_id bigint NOT NULL REFERENCES customers(id),
 credit_note_id bigint NOT NULL UNIQUE REFERENCES credit_notes(id),amount numeric(15,2) NOT NULL CHECK(amount>=0),
 remaining numeric(15,2) NOT NULL CHECK(remaining>=0),created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE user_modules DROP CONSTRAINT IF EXISTS user_modules_module_check;
ALTER TABLE user_modules ADD CONSTRAINT user_modules_module_check CHECK(module IN
 ('customers','suppliers','units','products','warehouses','balances','movements','reports','price-lists','quotes','payments','jobs','sal','ddt','invoices','credit-notes'));
INSERT INTO user_modules(user_id,module,can_view,can_edit)
 SELECT u.id,m.module,true,true FROM users u CROSS JOIN (VALUES ('jobs'),('credit-notes')) m(module)
 WHERE u.role='OFFICE' ON CONFLICT(user_id,module) DO NOTHING;
INSERT INTO user_modules(user_id,module,can_view,can_edit)
 SELECT id,'jobs',true,false FROM users WHERE role='TECHNICIAN'
 ON CONFLICT(user_id,module) DO NOTHING;
