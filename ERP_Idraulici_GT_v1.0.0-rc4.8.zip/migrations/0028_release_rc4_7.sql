-- RC4.7: condizioni commerciali ereditabili e preferenza IBAN per modalita di pagamento.
ALTER TABLE payment_methods
  ADD COLUMN IF NOT EXISTS show_iban boolean NOT NULL DEFAULT true;

ALTER TABLE invoice_register
  ADD COLUMN IF NOT EXISTS show_iban boolean NOT NULL DEFAULT true;

ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS payment_method_id bigint REFERENCES payment_methods(id),
  ADD COLUMN IF NOT EXISTS discount_mode varchar(16) NOT NULL DEFAULT 'SIMPLE',
  ADD COLUMN IF NOT EXISTS discount_1 numeric(5,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS discount_2 numeric(5,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS discount_3 numeric(5,2) NOT NULL DEFAULT 0;

ALTER TABLE customers DROP CONSTRAINT IF EXISTS customers_discount_mode_check;
ALTER TABLE customers ADD CONSTRAINT customers_discount_mode_check CHECK(discount_mode IN ('SIMPLE','SEQUENTIAL'));
ALTER TABLE customers DROP CONSTRAINT IF EXISTS customers_discount_1_check;
ALTER TABLE customers ADD CONSTRAINT customers_discount_1_check CHECK(discount_1 BETWEEN 0 AND 100);
ALTER TABLE customers DROP CONSTRAINT IF EXISTS customers_discount_2_check;
ALTER TABLE customers ADD CONSTRAINT customers_discount_2_check CHECK(discount_2 BETWEEN 0 AND 100);
ALTER TABLE customers DROP CONSTRAINT IF EXISTS customers_discount_3_check;
ALTER TABLE customers ADD CONSTRAINT customers_discount_3_check CHECK(discount_3 BETWEEN 0 AND 100);

ALTER TABLE price_lists
  ADD COLUMN IF NOT EXISTS discount_mode varchar(16) NOT NULL DEFAULT 'SIMPLE',
  ADD COLUMN IF NOT EXISTS discount_1 numeric(5,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS discount_2 numeric(5,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS discount_3 numeric(5,2) NOT NULL DEFAULT 0;

ALTER TABLE price_lists DROP CONSTRAINT IF EXISTS price_lists_discount_mode_check;
ALTER TABLE price_lists ADD CONSTRAINT price_lists_discount_mode_check CHECK(discount_mode IN ('SIMPLE','SEQUENTIAL'));
ALTER TABLE price_lists DROP CONSTRAINT IF EXISTS price_lists_discount_1_check;
ALTER TABLE price_lists ADD CONSTRAINT price_lists_discount_1_check CHECK(discount_1 BETWEEN 0 AND 100);
ALTER TABLE price_lists DROP CONSTRAINT IF EXISTS price_lists_discount_2_check;
ALTER TABLE price_lists ADD CONSTRAINT price_lists_discount_2_check CHECK(discount_2 BETWEEN 0 AND 100);
ALTER TABLE price_lists DROP CONSTRAINT IF EXISTS price_lists_discount_3_check;
ALTER TABLE price_lists ADD CONSTRAINT price_lists_discount_3_check CHECK(discount_3 BETWEEN 0 AND 100);
