CREATE TABLE IF NOT EXISTS document_number_settings (
 document_type varchar(8) PRIMARY KEY CHECK(document_type IN ('FT','DDT','PRE','SAL','NC')),
 prefix varchar(12) NOT NULL,
 separator varchar(3) NOT NULL DEFAULT '-',
 sequence_digits integer NOT NULL DEFAULT 6 CHECK(sequence_digits BETWEEN 3 AND 10),
 year_position varchar(8) NOT NULL DEFAULT 'SUFFIX' CHECK(year_position IN ('PREFIX','SUFFIX')),
 reset_yearly boolean NOT NULL DEFAULT true,
 updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO document_number_settings(document_type,prefix)
VALUES ('FT','FT'),('DDT','DDT'),('PRE','PRE'),('SAL','SAL'),('NC','NC')
ON CONFLICT (document_type) DO NOTHING;

ALTER TABLE invoice_lines
  ADD COLUMN IF NOT EXISTS source_quote_id bigint REFERENCES quotes(id);
CREATE INDEX IF NOT EXISTS invoice_lines_source_quote_idx
  ON invoice_lines(source_quote_id) WHERE source_quote_id IS NOT NULL;
