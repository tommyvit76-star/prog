ALTER TABLE quotes ALTER COLUMN customer_id DROP NOT NULL;
ALTER TABLE quotes ADD COLUMN IF NOT EXISTS supplier_id bigint REFERENCES suppliers(id);
ALTER TABLE quotes ADD COLUMN IF NOT EXISTS party_type varchar(10) NOT NULL DEFAULT 'CUSTOMER'
  CHECK(party_type IN ('CUSTOMER','SUPPLIER'));
ALTER TABLE quotes DROP CONSTRAINT IF EXISTS quotes_one_party;
ALTER TABLE quotes ADD CONSTRAINT quotes_one_party CHECK (
  (party_type='CUSTOMER' AND customer_id IS NOT NULL AND supplier_id IS NULL) OR
  (party_type='SUPPLIER' AND supplier_id IS NOT NULL AND customer_id IS NULL)
);
CREATE INDEX IF NOT EXISTS quotes_supplier_idx ON quotes(supplier_id);

CREATE TABLE IF NOT EXISTS invoice_references (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 invoice_id bigint NOT NULL REFERENCES invoice_register(id) ON DELETE CASCADE,
 reference_type varchar(12) NOT NULL CHECK(reference_type IN ('QUOTE','DDT','SAL','PROJECT')),
 quote_id bigint REFERENCES quotes(id),
 delivery_id bigint REFERENCES delivery_notes(id),
 sal_id bigint REFERENCES progress_certificates(id),
 project_id bigint REFERENCES project_sites(id),
 include_amounts boolean NOT NULL DEFAULT false,
 created_at timestamptz NOT NULL DEFAULT now(),
 CHECK (num_nonnulls(quote_id,delivery_id,sal_id,project_id)=1)
);
CREATE UNIQUE INDEX IF NOT EXISTS invoice_reference_quote_once ON invoice_references(invoice_id,quote_id) WHERE quote_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS invoice_reference_ddt_once ON invoice_references(invoice_id,delivery_id) WHERE delivery_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS invoice_reference_sal_once ON invoice_references(invoice_id,sal_id) WHERE sal_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS invoice_reference_project_once ON invoice_references(invoice_id,project_id) WHERE project_id IS NOT NULL;

INSERT INTO invoice_references(invoice_id,reference_type,quote_id,include_amounts)
SELECT id,'QUOTE',quote_id,true FROM invoice_register WHERE quote_id IS NOT NULL
ON CONFLICT DO NOTHING;
INSERT INTO invoice_references(invoice_id,reference_type,project_id,include_amounts)
SELECT id,'PROJECT',project_id,false FROM invoice_register WHERE project_id IS NOT NULL
ON CONFLICT DO NOTHING;
INSERT INTO invoice_references(invoice_id,reference_type,delivery_id,include_amounts)
SELECT invoice_id,'DDT',delivery_id,true FROM invoice_sources WHERE delivery_id IS NOT NULL
ON CONFLICT DO NOTHING;
INSERT INTO invoice_references(invoice_id,reference_type,sal_id,include_amounts)
SELECT invoice_id,'SAL',sal_id,true FROM invoice_sources WHERE sal_id IS NOT NULL
ON CONFLICT DO NOTHING;
