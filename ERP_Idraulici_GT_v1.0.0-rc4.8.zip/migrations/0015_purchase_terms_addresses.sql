CREATE TABLE purchase_discount_profiles (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 name text NOT NULL UNIQUE,
 supplier_id bigint REFERENCES suppliers(id),
 discount_1 numeric(5,2) NOT NULL DEFAULT 0 CHECK(discount_1 BETWEEN 0 AND 100),
 discount_2 numeric(5,2) NOT NULL DEFAULT 0 CHECK(discount_2 BETWEEN 0 AND 100),
 discount_3 numeric(5,2) NOT NULL DEFAULT 0 CHECK(discount_3 BETWEEN 0 AND 100),
 active boolean NOT NULL DEFAULT true
);
ALTER TABLE products ADD COLUMN purchase_profile_id bigint REFERENCES purchase_discount_profiles(id);
ALTER TABLE customer_addresses ADD COLUMN is_default boolean NOT NULL DEFAULT false;
ALTER TABLE supplier_addresses ADD COLUMN is_default boolean NOT NULL DEFAULT false;
CREATE UNIQUE INDEX customer_default_delivery ON customer_addresses(customer_id) WHERE is_default AND active;
CREATE UNIQUE INDEX supplier_default_delivery ON supplier_addresses(supplier_id) WHERE is_default AND active;
