CREATE TABLE product_categories (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 name varchar(120) NOT NULL,
 active boolean NOT NULL DEFAULT true
);
CREATE UNIQUE INDEX product_categories_active_name_idx ON product_categories(lower(name)) WHERE active=true;
INSERT INTO product_categories(name)
SELECT DISTINCT ON (lower(trim(category))) trim(category)
FROM products WHERE trim(category)<>''
ORDER BY lower(trim(category)),trim(category);
UPDATE products SET category=c.name FROM product_categories c
WHERE lower(trim(products.category))=lower(c.name) AND products.category<>c.name;
