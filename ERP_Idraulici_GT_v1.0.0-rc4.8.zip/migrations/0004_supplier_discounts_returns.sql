ALTER TABLE suppliers
  ADD COLUMN discount_1 numeric(5,2) NOT NULL DEFAULT 0 CHECK (discount_1 BETWEEN 0 AND 100),
  ADD COLUMN discount_2 numeric(5,2) NOT NULL DEFAULT 0 CHECK (discount_2 BETWEEN 0 AND 100),
  ADD COLUMN discount_3 numeric(5,2) NOT NULL DEFAULT 0 CHECK (discount_3 BETWEEN 0 AND 100);
ALTER TABLE movements ADD COLUMN supplier_id bigint REFERENCES suppliers(id);
ALTER TABLE movements DROP CONSTRAINT movements_kind_check;
ALTER TABLE movements ADD CONSTRAINT movements_kind_check
  CHECK (kind IN ('LOAD','TRANSFER','CONSUME','RETURN','ADJUST','REVERSAL','SUPPLIER_RETURN'));
CREATE INDEX movements_supplier_idx ON movements(supplier_id);
