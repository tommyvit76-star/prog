-- RC4.5: fixed DDT totals, project fiscal data and traceable document flow.
ALTER TABLE delivery_notes
 ADD COLUMN billing_destination varchar(16) NOT NULL DEFAULT 'DIRECT_INVOICE'
   CHECK (billing_destination IN ('DIRECT_INVOICE','PROJECT_COST','NON_BILLABLE')),
 ADD COLUMN global_labor numeric(15,2) NOT NULL DEFAULT 0 CHECK(global_labor>=0),
 ADD COLUMN global_labor_vat numeric(5,2) NOT NULL DEFAULT 22 CHECK(global_labor_vat BETWEEN 0 AND 100),
 ADD COLUMN global_travel numeric(15,2) NOT NULL DEFAULT 0 CHECK(global_travel>=0),
 ADD COLUMN global_travel_vat numeric(5,2) NOT NULL DEFAULT 22 CHECK(global_travel_vat BETWEEN 0 AND 100),
 ADD COLUMN global_service numeric(15,2) NOT NULL DEFAULT 0 CHECK(global_service>=0),
 ADD COLUMN global_service_vat numeric(5,2) NOT NULL DEFAULT 22 CHECK(global_service_vat BETWEEN 0 AND 100),
 ADD COLUMN global_discount numeric(15,2) NOT NULL DEFAULT 0 CHECK(global_discount>=0),
 ADD COLUMN global_discount_vat numeric(5,2) NOT NULL DEFAULT 22 CHECK(global_discount_vat BETWEEN 0 AND 100);

UPDATE delivery_notes SET billing_destination='PROJECT_COST' WHERE project_id IS NOT NULL;

ALTER TABLE project_sites
 ADD COLUMN contract_type varchar(10) NOT NULL DEFAULT 'PRIVATE' CHECK(contract_type IN ('PRIVATE','PUBLIC')),
 ADD COLUMN contract_number text NOT NULL DEFAULT '',
 ADD COLUMN contract_date date,
 ADD COLUMN cup text NOT NULL DEFAULT '',
 ADD COLUMN cig text NOT NULL DEFAULT '',
 ADD COLUMN vat_regime varchar(18) NOT NULL DEFAULT 'ORDINARY'
   CHECK(vat_regime IN ('ORDINARY','REVERSE_CHARGE','SPLIT_PAYMENT')),
 ADD COLUMN safety_costs numeric(15,2) NOT NULL DEFAULT 0 CHECK(safety_costs>=0),
 ADD COLUMN contract_discount_percent numeric(5,2) NOT NULL DEFAULT 0 CHECK(contract_discount_percent BETWEEN 0 AND 100),
 ADD COLUMN advance_amount numeric(15,2) NOT NULL DEFAULT 0 CHECK(advance_amount>=0),
 ADD COLUMN retention_percent numeric(5,2) NOT NULL DEFAULT 0 CHECK(retention_percent BETWEEN 0 AND 100),
 ADD COLUMN works_director text NOT NULL DEFAULT '',
 ADD COLUMN rup text NOT NULL DEFAULT '';

ALTER TABLE progress_certificates
 ADD COLUMN certificate_number text NOT NULL DEFAULT '',
 ADD COLUMN certificate_date date,
 ADD COLUMN works_director text NOT NULL DEFAULT '',
 ADD COLUMN rup text NOT NULL DEFAULT '';

CREATE INDEX delivery_notes_billing_destination_idx
 ON delivery_notes(customer_id,billing_destination,status) WHERE active=true;
