CREATE TABLE document_sequences (
 document_type varchar(3) NOT NULL CHECK(document_type IN ('FT','DDT','SAL')),
 document_year integer NOT NULL CHECK(document_year BETWEEN 2000 AND 2100),
 last_number bigint NOT NULL CHECK(last_number>=0),
 PRIMARY KEY(document_type,document_year)
);
