-- RC4.6: stable, user-visible customer code.
ALTER TABLE customers ADD COLUMN IF NOT EXISTS code text;
UPDATE customers SET code='CLI-' || lpad(id::text,6,'0') WHERE code IS NULL OR trim(code)='';
ALTER TABLE customers ALTER COLUMN code SET NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS customers_code_unique_idx ON customers(lower(trim(code)));
CREATE INDEX IF NOT EXISTS customers_code_search_idx ON customers(lower(code));

ALTER TABLE progress_certificates DROP CONSTRAINT IF EXISTS progress_certificates_percent_check;
ALTER TABLE progress_certificates DROP CONSTRAINT IF EXISTS progress_certificates_amount_check;
ALTER TABLE progress_certificates ADD CONSTRAINT progress_certificates_percent_check CHECK(percent>=0 AND percent<=100);
ALTER TABLE progress_certificates ADD CONSTRAINT progress_certificates_amount_check CHECK(amount>=0);
