ALTER TABLE product_categories ADD COLUMN default_markup numeric(7,2) NOT NULL DEFAULT 22
 CHECK (default_markup BETWEEN 0 AND 1000);
ALTER TABLE quotes ADD COLUMN labor_rate_1 numeric(15,4) NOT NULL DEFAULT 25,
 ADD COLUMN labor_rate_2 numeric(15,4) NOT NULL DEFAULT 28,
 ADD COLUMN labor_rate_3 numeric(15,4) NOT NULL DEFAULT 35,
 ADD COLUMN workers integer NOT NULL DEFAULT 2 CHECK (workers BETWEEN 1 AND 100),
 ADD COLUMN minutes_per_day numeric(15,4) NOT NULL DEFAULT 600 CHECK(minutes_per_day>0),
 ADD COLUMN auto_working_days boolean NOT NULL DEFAULT false;
ALTER TABLE quote_lines ADD COLUMN labor_band integer NOT NULL DEFAULT 0 CHECK(labor_band BETWEEN 0 AND 3);
