ALTER TABLE customers ADD COLUMN iban varchar(34) NOT NULL DEFAULT '', ADD COLUMN bank_name text NOT NULL DEFAULT '';
ALTER TABLE suppliers ADD COLUMN iban varchar(34) NOT NULL DEFAULT '', ADD COLUMN bank_name text NOT NULL DEFAULT '';
CREATE TABLE company_bank_accounts (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 label text NOT NULL CHECK(length(trim(label))>0),
 bank_name text NOT NULL DEFAULT '',
 holder text NOT NULL DEFAULT '',
 iban varchar(34) NOT NULL,
 active boolean NOT NULL DEFAULT true
);
CREATE UNIQUE INDEX company_bank_accounts_active_iban_idx ON company_bank_accounts(iban) WHERE active=true;
ALTER TABLE payment_methods ADD COLUMN payment_type varchar(16) NOT NULL DEFAULT 'OTHER'
 CHECK(payment_type IN ('OTHER','TRANSFER','RIBA'));
ALTER TABLE payment_methods ADD COLUMN bank_account_id bigint REFERENCES company_bank_accounts(id);
ALTER TABLE invoice_register ADD COLUMN bank_account_id bigint REFERENCES company_bank_accounts(id),
 ADD COLUMN bank_name text NOT NULL DEFAULT '', ADD COLUMN bank_holder text NOT NULL DEFAULT '',
 ADD COLUMN bank_iban varchar(34) NOT NULL DEFAULT '',
 ADD COLUMN customer_bank_name text NOT NULL DEFAULT '', ADD COLUMN customer_iban varchar(34) NOT NULL DEFAULT '',
 ADD COLUMN payment_type varchar(16) NOT NULL DEFAULT 'OTHER';
