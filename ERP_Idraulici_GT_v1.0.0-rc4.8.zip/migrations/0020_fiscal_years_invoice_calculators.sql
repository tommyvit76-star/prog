CREATE TABLE fiscal_years (
 year integer PRIMARY KEY CHECK(year BETWEEN 2000 AND 2100),
 starts_on date NOT NULL,
 ends_on date NOT NULL,
 status text NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','CLOSED')),
 closed_at timestamptz,
 closed_by bigint REFERENCES users(id),
 backup_name text NOT NULL DEFAULT '',
 closing_notes text NOT NULL DEFAULT '',
 created_at timestamptz NOT NULL DEFAULT now(),
 CHECK(starts_on<=ends_on)
);

INSERT INTO fiscal_years(year,starts_on,ends_on)
SELECT y,make_date(y,1,1),make_date(y,12,31)
FROM (
 SELECT extract(year FROM current_date)::integer y
 UNION SELECT extract(year FROM issue_date)::integer FROM quotes
 UNION SELECT extract(year FROM issued_on)::integer FROM delivery_notes
 UNION SELECT extract(year FROM issued_on)::integer FROM progress_certificates
 UNION SELECT extract(year FROM issue_date)::integer FROM invoice_register
 UNION SELECT extract(year FROM issue_date)::integer FROM credit_notes
) years ON CONFLICT(year) DO NOTHING;

ALTER TABLE users ADD COLUMN selected_fiscal_year integer;
UPDATE users SET selected_fiscal_year=extract(year FROM current_date)::integer WHERE selected_fiscal_year IS NULL;
ALTER TABLE users ALTER COLUMN selected_fiscal_year SET NOT NULL;

ALTER TABLE quotes ADD COLUMN fiscal_year integer;
UPDATE quotes SET fiscal_year=extract(year FROM issue_date)::integer;
ALTER TABLE quotes ALTER COLUMN fiscal_year SET NOT NULL;
ALTER TABLE quotes ADD CONSTRAINT quotes_fiscal_year_fk FOREIGN KEY(fiscal_year) REFERENCES fiscal_years(year);

ALTER TABLE delivery_notes ADD COLUMN fiscal_year integer;
UPDATE delivery_notes SET fiscal_year=extract(year FROM issued_on)::integer;
ALTER TABLE delivery_notes ALTER COLUMN fiscal_year SET NOT NULL;
ALTER TABLE delivery_notes ADD CONSTRAINT delivery_notes_fiscal_year_fk FOREIGN KEY(fiscal_year) REFERENCES fiscal_years(year);

ALTER TABLE progress_certificates ADD COLUMN fiscal_year integer;
UPDATE progress_certificates SET fiscal_year=extract(year FROM issued_on)::integer;
ALTER TABLE progress_certificates ALTER COLUMN fiscal_year SET NOT NULL;
ALTER TABLE progress_certificates ADD CONSTRAINT progress_certificates_fiscal_year_fk FOREIGN KEY(fiscal_year) REFERENCES fiscal_years(year);

ALTER TABLE invoice_register ADD COLUMN fiscal_year integer;
UPDATE invoice_register SET fiscal_year=extract(year FROM issue_date)::integer;
ALTER TABLE invoice_register ALTER COLUMN fiscal_year SET NOT NULL;
ALTER TABLE invoice_register ADD CONSTRAINT invoice_register_fiscal_year_fk FOREIGN KEY(fiscal_year) REFERENCES fiscal_years(year);

ALTER TABLE credit_notes ADD COLUMN fiscal_year integer;
UPDATE credit_notes SET fiscal_year=extract(year FROM issue_date)::integer;
ALTER TABLE credit_notes ALTER COLUMN fiscal_year SET NOT NULL;
ALTER TABLE credit_notes ADD CONSTRAINT credit_notes_fiscal_year_fk FOREIGN KEY(fiscal_year) REFERENCES fiscal_years(year);

ALTER TABLE invoice_register ALTER COLUMN customer_id DROP NOT NULL;
ALTER TABLE invoice_register ADD COLUMN casual_customer jsonb;
ALTER TABLE invoice_register ADD CONSTRAINT invoice_customer_source_check
 CHECK ((customer_id IS NOT NULL) <> (casual_customer IS NOT NULL));
ALTER TABLE credit_notes ALTER COLUMN customer_id DROP NOT NULL;
ALTER TABLE customer_credits ALTER COLUMN customer_id DROP NOT NULL;

ALTER TABLE invoice_lines
 ADD COLUMN calculation_mode text NOT NULL DEFAULT 'MANUAL' CHECK(calculation_mode IN ('MANUAL','LABOR','TRAVEL')),
 ADD COLUMN work_minutes numeric(15,2) NOT NULL DEFAULT 0 CHECK(work_minutes>=0),
 ADD COLUMN workers integer NOT NULL DEFAULT 1 CHECK(workers>0 AND workers<=1000),
 ADD COLUMN hourly_rate numeric(15,4) NOT NULL DEFAULT 0 CHECK(hourly_rate>=0),
 ADD COLUMN kilometers numeric(15,3) NOT NULL DEFAULT 0 CHECK(kilometers>=0),
 ADD COLUMN kilometer_rate numeric(15,4) NOT NULL DEFAULT 0 CHECK(kilometer_rate>=0);

CREATE INDEX quotes_fiscal_year_idx ON quotes(fiscal_year,id DESC);
CREATE INDEX delivery_notes_fiscal_year_idx ON delivery_notes(fiscal_year,issued_on DESC);
CREATE INDEX progress_certificates_fiscal_year_idx ON progress_certificates(fiscal_year,issued_on DESC);
CREATE INDEX invoice_register_fiscal_year_idx ON invoice_register(fiscal_year,issue_date DESC);
CREATE INDEX credit_notes_fiscal_year_idx ON credit_notes(fiscal_year,issue_date DESC);
