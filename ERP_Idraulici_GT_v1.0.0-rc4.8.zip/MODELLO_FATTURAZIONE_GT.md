# ERP G&T — modello di fatturazione da implementare

Versione di progetto: 22 settembre 2026. Documento funzionale e piano di collaudo; **non è una patch installabile né un certificato di conformità fiscale**.

## 1. Un'unica scheda fattura

Testata: azienda selezionata, tipo documento (fattura immediata o riepilogativa), cliente, indirizzo e identificativi fiscali fotografati alla conferma, data, numero progressivo visibile, riferimento preventivo facoltativo, modalità di pagamento, IBAN aziendale o dati Ri.Ba., note. Nella scheda compaiono contemporaneamente **righe manuali** e **documenti disponibili del medesimo cliente**. La ricerca dei DDT permette mese/intervallo/tutto lo storico; i SAL mostrano l'importo ancora fatturabile. Il riepilogo IVA, il totale, le rate e le scadenze sono visibili prima del salvataggio.

Ogni riga manuale ha: ordine, tipo (articolo, prestazione/manodopera, sconto), codice articolo eventuale, descrizione obbligatoria, unità, quantità fino a quattro decimali, prezzo unitario fino a tre/quattro decimali, sconti percentuali in sequenza e/o importo negativo, aliquota IVA oppure natura/esenzione e riferimenti richiesti dal caso fiscale. Articoli e prestazioni si possono mescolare. Le righe collegate a DDT e SAL conservano riferimento e importi di origine e non sono modificabili indirettamente cambiando l'anagrafica articolo.

L'utente sceglie esplicitamente se la fattura è immediata (righe manuali), riepilogativa (DDT/SAL) oppure mista. L'interfaccia segnala quando una riga manuale sembra ripetere una voce già inclusa in un DDT/SAL collegato e chiede una conferma motivata; il server impedisce che lo stesso DDT sia collegato a due fatture e che il SAL superi il residuo.

## 2. Calcolo unico e riproducibile

Si usano `Decimal` sul server e arrotondamento commerciale a due centesimi (`ROUND_HALF_UP`); mai `float` per i totali. Input italiano come `1.234,50`, visualizzazione italiana, serializzazione interna normalizzata e XML con separatore decimale richiesto dal tracciato. Il totale della riga è quantità × prezzo, poi sconti applicati **in sequenza**; una riga di sconto extra ha importo negativo e aliquota/natura coerente con ciò che sconta. Non si permette un imponibile o totale fattura negativo. La strategia di arrotondamento per riga e per raggruppamento IVA è documentata e verificata contro il tracciato XML; nessuna modifica silenziosa di un importo inserito.

Totali = somma delle righe manuali + porzioni fatturabili di DDT/SAL, aggregati per aliquota IVA e, se presente, natura. Per ogni gruppo si calcolano imponibile, imposta e totale. Lo sconto documento distribuito su più aliquote richiede ripartizione esplicita e verificabile. La differenza tra calcolo mostrato e calcolo salvato deve essere zero centesimi.

**Esempio riproducibile:** 2 articoli a € 100,00 con 10% di sconto = € 180,00; manodopera 3 ore × € 40,00 = € 120,00; sconto extra di € 20,00 riferito al gruppo IVA 22% → imponibile 22% € 280,00 e IVA € 61,60; altra prestazione € 50,00 al 10% → IVA € 5,00. **Totale € 396,60**. Con rate 33% e 67%, prima scadenza € 130,88 e seconda € 265,72. I centesimi residui vanno nell'ultima rata. Ho verificato questi numeri con aritmetica `Decimal`.

## 3. Pagamento e scadenziario

La modalità di pagamento è una configurazione modificabile che definisce tipo (bonifico, Ri.Ba., altro), conto, numero rate, percentuali e offset giorni per ciascuna rata, opzione **fine mese** e giorni aggiuntivi. L'ordine di calcolo è: data fattura + giorni base → eventuale fine mese → giorni aggiuntivi. Esempio: 21/09/2026 con fine mese + 10 giorni = **10/10/2026**. Le date proposte restano modificabili nella fattura o nello scadenziario.

Alla conferma della fattura, totale e rate vengono salvati **nella stessa transazione**; la somma delle rate attive deve eguagliare esattamente il totale documento. Nessuna scadenza attiva viene generata due volte in caso di doppio clic o ritentativo. Se cambia una bozza senza incassi, si ricalcolano solo le rate proposte, mantenendo le date eventualmente fissate manualmente finché l'utente decide. Se esistono rate pagate, si conservano immutate e si richiede una rettifica esplicita sulle sole rate aperte; l'importo già pagato non può superare il nuovo totale. Lo stato fattura si ricava dagli incassi (aperta, parzialmente pagata, saldata), distinguendolo dallo stato documentale (bozza, confermata).

## 4. Numeri, documenti e magazzino

Numero proposto visibile prima del salvataggio; la numerazione definitiva è assegnata e protetta in transazione. L'amministratore può forzare un numero **solo su bozza**, con controllo di unicità anche per numeri di documenti archiviati. La conferma congela testata, righe, imposte, cliente, coordinate, riferimenti e scadenze iniziali; una fattura confermata non va cancellata per riutilizzare il numero. Eventuali correzioni successive seguono un documento di rettifica appropriato da progettare e validare fiscalmente.

Il DDT confermato ha già scaricato il magazzino: collegarlo alla fattura **non scarica una seconda volta**. Un articolo aggiunto direttamente alla fattura non genera automaticamente movimenti; il sistema chiede una scelta esplicita di magazzino e registra un solo scarico tracciato alla conferma, oppure nessuno per prestazioni. L'annullamento della bozza non altera giacenze già registrate da DDT.

## 5. Stampa, PDF e XML

Un'unica vista di stampa A4 e un PDF generato dal server presentano logo non tagliato, dati aziendali, dati cliente, numero/data, righe e fonti, quantità, sconti, riepiloghi per aliquota/natura, totale, modalità di pagamento, IBAN e tutte le scadenze. Si verifica anche su pagina 2 e su telefono/tablet. Il PDF è una copia leggibile della fattura gestionale; **non sostituisce il file elettronico**.

Il pulsante **Esporta XML FatturaPA** è disponibile soltanto per documenti con i dati necessari e validati. Deve comprendere dati trasmissione, cedente e cessionario, tipo documento, numero/data, dettaglio righe, sconti, riepilogo IVA per aliquota/natura, riferimenti DDT quando pertinenti, importo totale e dati pagamento/scadenze. La generazione deve usare una versione esplicitamente identificata delle specifiche ufficiali vigenti all'implementazione; validazione XSD e controlli di coerenza del tracciato, inclusi aliquota zero/natura e campi condizionati, prima del download. Il nome file e il contenuto XML hanno regole proprie; il gestionale deve mostrare il motivo puntuale di ogni errore. Occorre poi una prova reale d'importazione su Aruba e un riscontro del commercialista sui casi fiscali utilizzati. **Non si dichiara l'XML conforme o pronto all'invio prima di questi collaudi.**

## 6. Uscita da una scheda con modifiche

Su navigazione verso altro modulo, chiusura o cambio cliente con modifiche non salvate: **Salva e continua**, **Resta**, **Esci senza salvare**. Il pulsante Salva valida campi obbligatori, importi, aliquote, fonti e scadenze; in presenza di errori lascia aperta la scheda, evidenzia il campo e preserva tutte le righe. Su chiusura scheda/browser si usa l'avviso nativo del browser e, dove possibile, un salvataggio locale della bozza da recuperare. Le operazioni concorrenti verificano la versione del documento prima di sovrascrivere le modifiche.

## 7. Struttura dati suggerita e migrazione

- `invoices`: testata, stato documento, tipo, snapshot azienda/cliente/pagamento, versione di modifica, numero, totali calcolati, collegamento ad eventuale sostituzione/rettifica.
- `invoice_lines`: righe manuali con ordine, descrizione, codice, quantità, prezzo, sconti, aliquota/natura, importi calcolati, articolo e movimento eventuali.
- `invoice_sources`: collegamenti DDT/SAL e snapshot dei gruppi IVA, quantità/importo fatturato e residuo SAL; una fonte non è una riga manuale implicita.
- `payment_installments`: date e importi generati, regola originaria, flag data modificata, stato e pagamenti registrati con audit.
- `invoice_exports`: versione XML/PDF, hash, timestamp, esito di validazione e identificazione dello schema utilizzato; nessuna password o dato bancario sensibile nei log.

Migrare le fatture esistenti senza alterare i loro importi: segnare come `legacy` quelle che hanno soli totali manuali, non inventare righe o aliquote. Le fatture esistenti con DDT/SAL mantengono i riferimenti. Qualsiasi fattura `legacy` senza dati fiscali sufficienti mostra un avviso e non offre un XML apparentemente valido. Backup del DB e migrazione reversibile/controllata prima dell'installazione.

## 8. Collaudo obbligatorio della patch futura

| Caso | Esito atteso |
| --- | --- |
| Fattura immediata con articoli, manodopera e sconto | Totale e IVA come nell'esempio € 396,60; PDF coerente con schermo e DB |
| Fattura riepilogativa, due DDT del cliente in un mese | Due fonti una volta sola; magazzino scaricato solo dal DDT |
| SAL € 1.000,00, prima fattura € 400,00, seconda € 600,00 | Residuo 600 poi zero; tentativo € 600,01 respinto |
| Cliente diverso, DDT già fatturato, doppio clic di conferma | Nessun collegamento scorretto, duplicazione o scadenza doppia |
| Rate 33%/67% su € 396,60; fine mese + 10 | € 130,88 + € 265,72; data 10/10/2026 nell'esempio |
| Cambio bozza con rata pagata | Pagamento immutato; blocco o rettifica esplicita delle rate aperte |
| Navigazione con campo obbligatorio vuoto | Resta nella scheda e conserva dati e righe |
| Più aliquote, esenzione/natura, sconto su più aliquote | Riepiloghi verificati contro XSD e casi fiscali approvati |
| PDF di due pagine con logo e indirizzi lunghi | Nessun taglio, totali e intestazione leggibili |
| XML importato da Aruba | Accettazione effettiva sui casi testati; esiti e versioni registrati |
| PostgreSQL su NAS, migrazione da RC2 e ripristino backup | Dati precedenti integri e calcoli documenti invariati |

I test di calcolo puro, database con transazioni/concorrenza, API/UI, PDF renderizzato e XML/XSD sono tutti necessari. Il solo passaggio dei test automatici non equivale alla prova fiscale o all'accettazione Aruba.

## Fonti da verificare all'implementazione

- Agenzia delle Entrate, guida alla predisposizione della fattura elettronica e specifiche SdI aggiornate.
- FatturaPA, rappresentazione tabellare del tracciato ordinario e relativo XSD della versione vigente.
- Documentazione Aruba per l'importazione e la restituzione dell'esito.
